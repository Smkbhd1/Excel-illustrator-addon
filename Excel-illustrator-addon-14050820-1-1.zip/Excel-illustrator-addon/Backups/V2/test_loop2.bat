@echo off
setlocal enabledelayedexpansion
for /d %%u in (C:\Users\*) do (
    set "USER_DEST=%%u\AppData\Roaming\Adobe\CEP\extensions\ExcelArtboardSync"
    if exist "!USER_DEST!" (
        echo Found: %%~nxu
        if not exist "!USER_DEST!" (
            echo Removed
        ) else (
            echo Locked
        )
    )
)
pause
