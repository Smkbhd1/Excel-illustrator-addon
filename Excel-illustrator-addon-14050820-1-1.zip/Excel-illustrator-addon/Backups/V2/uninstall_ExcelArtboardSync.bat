# 2>nul & set "HYBRID_PATH=%~f0" & powershell -NoProfile -ExecutionPolicy Bypass -Command "iex ((Get-Content -Raw -Path $env:HYBRID_PATH))" & exit /b

Write-Host "=======================================================================" -ForegroundColor Cyan
Write-Host "    EXCEL ARTBOARD SYNC - UNINSTALLER" -ForegroundColor Cyan
Write-Host "    (Removes CEP Panel and optional registry cleanup)" -ForegroundColor Cyan
Write-Host "=======================================================================" -ForegroundColor Cyan
Write-Host ""

# Get all user AppData CEP paths
$paths = Get-ChildItem -Path C:\Users -Directory | ForEach-Object {
    Join-Path $_.FullName "AppData\Roaming\Adobe\CEP\extensions\ExcelArtboardSync"
}
# Filter paths that exist
$activePaths = $paths | Where-Object { Test-Path $_ }

if ($activePaths.Count -eq 0) {
    Write-Host "No installations found under any C:\Users profiles." -ForegroundColor Yellow
} else {
    Write-Host "Found extension in user profile(s):" -ForegroundColor Cyan
    foreach ($p in $activePaths) {
        $user = (Split-Path $p -Parent | Split-Path -Parent | Split-Path -Parent | Split-Path -Leaf)
        Write-Host "  - $user (at $p)"
    }
    Write-Host ""
    
    $confirm = Read-Host "Type YES to confirm uninstall"
    if ($confirm -ieq 'YES' -or $confirm -ieq 'Y') {
        foreach ($p in $activePaths) {
            try {
                Remove-Item -Path $p -Recurse -Force -ErrorAction Stop
                Write-Host "[+] Successfully removed from $p" -ForegroundColor Green
            } catch {
                Write-Host "[!] FAILED to remove from $p. Close Illustrator first! Error: $($_.Exception.Message)" -ForegroundColor Red
            }
        }
    } else {
        Write-Host "Uninstall cancelled." -ForegroundColor Yellow
        Read-Host "Press Enter to exit"
        Exit
    }
}

Write-Host ""
Write-Host "[*] Registry Cleanup (PlayerDebugMode)"
Write-Host "The installer enabled PlayerDebugMode in the registry to load unsigned CEP panels."
$cleanReg = Read-Host "Remove PlayerDebugMode registry values? (YES/no)"
if ($cleanReg -ieq 'YES' -or $cleanReg -ieq 'Y') {
    7..14 | ForEach-Object {
        $regPath = "HKCU:\Software\Adobe\CSXS.$_"
        if (Test-Path $regPath) {
            try {
                Remove-ItemProperty -Path $regPath -Name PlayerDebugMode -Force -ErrorAction SilentlyContinue
                Write-Host "  [+] Removed PlayerDebugMode from CSXS.$_"
            } catch {}
        }
    }
    Write-Host "[+] Registry cleanup complete." -ForegroundColor Green
} else {
    Write-Host "[i] Registry values kept (PlayerDebugMode remains enabled)." -ForegroundColor Gray
}

Write-Host ""
Write-Host "=======================================================================" -ForegroundColor Cyan
Write-Host "                      UNINSTALL COMPLETE" -ForegroundColor Cyan
Write-Host "=======================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Excel Artboard Sync has been removed."
Write-Host "NEXT STEPS:"
Write-Host "  1. Restart Adobe Illustrator."
Write-Host "  2. The panel will no longer appear under Window -> Extensions."
Write-Host ""
Read-Host "Press Enter to exit"
