# 2>nul & set "HYBRID_PATH=%~f0" & powershell -NoProfile -ExecutionPolicy Bypass -Command "iex ((Get-Content -Raw -Path $env:HYBRID_PATH))" & exit /b

Write-Host "=======================================================================" -ForegroundColor Cyan
Write-Host "    EXCEL ARTBOARD SYNC - ADOBE ILLUSTRATOR AUTO-INSTALLER" -ForegroundColor Cyan
Write-Host "    (CEP Panel | Illustrator 2020 to 2026 Compatible)" -ForegroundColor Cyan
Write-Host "=======================================================================" -ForegroundColor Cyan
Write-Host ""

$scriptDir = Split-Path -Path $env:HYBRID_PATH -Parent
$sourceDir = Join-Path $scriptDir "ExcelArtboardSync"
$destDir = Join-Path $env:APPDATA "Adobe\CEP\extensions\ExcelArtboardSync"
$xlsxJs = Join-Path $sourceDir "js\xlsx.full.min.js"
$xlsxUrl = "https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js"

# Step 1: SheetJS check
Write-Host "[*] Step 1: Checking for SheetJS (xlsx.full.min.js) ..."
if (Test-Path $xlsxJs) {
    Write-Host "    [+] SheetJS already present. Skipping download." -ForegroundColor Green
} else {
    Write-Host "    [*] Downloading SheetJS from CDN..."
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $xlsxUrl -OutFile $xlsxJs -UseBasicParsing -ErrorAction Stop
        Write-Host "    [+] Download OK" -ForegroundColor Green
    } catch {
        Write-Host "    [!] Download FAILED: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "    Please download SheetJS manually and save it to $xlsxJs" -ForegroundColor Yellow
    }
}

# Step 2: Install CEP panel
Write-Host ""
Write-Host "[*] Step 2: Installing CEP Extension Panel ..."
if (-not (Test-Path $sourceDir)) {
    Write-Host "    [!] ERROR: Source folder not found at: $sourceDir" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    Exit
}

$cepParent = Join-Path $env:APPDATA "Adobe\CEP\extensions"
if (-not (Test-Path $cepParent)) {
    New-Item -ItemType Directory -Path $cepParent -Force | Out-Null
    Write-Host "    [+] Created CEP extensions directory." -ForegroundColor Green
}

if (Test-Path $destDir) {
    Write-Host "    [*] Removing previous installation..."
    Remove-Item -Path $destDir -Recurse -Force -ErrorAction SilentlyContinue
}

try {
    # Copy files
    Copy-Item -Path $sourceDir -Destination $destDir -Recurse -Force -ErrorAction Stop
    Write-Host "    [+] Panel files installed successfully." -ForegroundColor Green
    $panelInstalled = $true
} catch {
    Write-Host "    [!] FAILED to copy files: $($_.Exception.Message)" -ForegroundColor Red
    $panelInstalled = $false
}

# Step 3: Registry
Write-Host ""
Write-Host "[*] Step 3: Enabling Adobe CEP Debug Mode in registry ..."
Write-Host "    (Allows unsigned local extensions to load)"
7..14 | ForEach-Object {
    $regPath = "HKCU:\Software\Adobe\CSXS.$_"
    if (-not (Test-Path $regPath)) {
        try { New-Item -Path $regPath -Force | Out-Null } catch {}
    }
    try {
        Set-ItemProperty -Path $regPath -Name PlayerDebugMode -Value "1" -Type String -Force -ErrorAction Stop | Out-Null
    } catch {}
}
Write-Host "    [+] PlayerDebugMode enabled for CSXS.7 through CSXS.14!" -ForegroundColor Green

# Step 4: Verification
Write-Host ""
Write-Host "[*] Step 4: Verifying installation ..."
$requiredFiles = @(
    "CSXS\manifest.xml",
    "index.html",
    "css\style.css",
    "js\main.js",
    "js\CSInterface.js",
    "js\xlsx.full.min.js",
    "jsx\artboard.jsx"
)

$allOk = $true
foreach ($f in $requiredFiles) {
    $fullPath = Join-Path $destDir $f
    if (Test-Path $fullPath) {
        Write-Host "    [+] $f" -ForegroundColor Green
    } else {
        Write-Host "    [!] MISSING: $f" -ForegroundColor Red
        $allOk = $false
    }
}

Write-Host ""
Write-Host "=======================================================================" -ForegroundColor Cyan
Write-Host "                     INSTALLATION PROCESS COMPLETE!" -ForegroundColor Cyan
Write-Host "=======================================================================" -ForegroundColor Cyan
Write-Host ""

if ($panelInstalled) {
    Write-Host "   DOCKABLE PANEL INSTALLED SUCCESSFULLY:" -ForegroundColor Green
    Write-Host ""
    Write-Host "      1. Close Adobe Illustrator completely (if it is open)."
    Write-Host "      2. Re-launch Adobe Illustrator."
    Write-Host "      3. Go to:  Window -> Extensions -> Excel Artboard Sync"
    Write-Host "      4. The panel loads your Excel file automatically!"
    Write-Host ""
    Write-Host "   HOW TO USE:"
    Write-Host "      - Click 'Sync Now' to push artboards from Excel to Illustrator."
    Write-Host "      - Toggle 'Live Mode' to auto-sync every time you save the Excel file."
    Write-Host ""
}

if (-not $allOk) {
    Write-Host "   [!] WARNING: Some files are missing (see above)." -ForegroundColor Yellow
    Write-Host "       Re-run the installer or check the ExcelArtboardSync source folder." -ForegroundColor Yellow
    Write-Host ""
}

Write-Host "   Installed to:"
Write-Host "   $destDir"
Write-Host ""
Read-Host "Press Enter to close this window"
