/**
 * artboard.jsx  –  ExtendScript for Adobe Illustrator
 * Manages artboard creation and update from JSON data passed by CEP panel
 *
 * Coordinate convention (matching the panel's Excel format):
 *   X, Y = top-left corner of artboard in pixels (screen coords, Y=0 at top)
 *   W, H = width and height in pixels
 *
 * Illustrator internal rect = [left, top, right, bottom] in points
 *   where top > bottom (Y axis points UP in Illustrator)
 *   Ruler origin: top-left of first artboard = (0, 0)
 *   Down from origin → negative Y
 *
 * Conversion: 1 pixel = 1 point (1:1) for 72dpi documents.
 * The panel will let users choose px / pt.
 */

/* ─── JSON polyfill for ExtendScript ─── */
if (typeof JSON === 'undefined') {
    JSON = {};
}
if (typeof JSON.parse !== 'function') {
    JSON.parse = function (str) {
        return eval('(' + str + ')');
    };
}
if (typeof JSON.stringify !== 'function') {
    JSON.stringify = function (obj) {
        var t = typeof obj;
        if (t === 'undefined') return undefined;
        if (t === 'number' || t === 'boolean') return String(obj);
        if (t === 'string') return '"' + obj.replace(/\\/g,'\\\\').replace(/"/g,'\\"') + '"';
        if (obj === null) return 'null';
        if (obj instanceof Array) {
            var items = [];
            for (var i = 0; i < obj.length; i++) {
                items.push(JSON.stringify(obj[i]));
            }
            return '[' + items.join(',') + ']';
        }
        var pairs = [];
        for (var k in obj) {
            if (obj.hasOwnProperty(k)) {
                pairs.push('"' + k + '":' + JSON.stringify(obj[k]));
            }
        }
        return '{' + pairs.join(',') + '}';
    };
}

/* ─── Helpers ─── */

/**
 * Convert pixel value to Illustrator points.
 * By default 1px = 1pt (correct for 72dpi).
 * Adjust multiplier if needed.
 */
function pxToPt(px) {
    return parseFloat(px) * 1.0;
}

/**
 * Build an Illustrator Rect [left, top, right, bottom] from
 * user-supplied screen-coordinate values.
 * Y is inverted: screen Y=0 top → Illustrator Y=0 top, positive going down
 * becomes negative in Illustrator's math axis.
 */
function buildRect(x, y, w, h) {
    var left   =  pxToPt(x);
    var top    = -pxToPt(y);
    var right  =  pxToPt(x) + pxToPt(w);
    var bottom = -pxToPt(y) - pxToPt(h);
    return [left, top, right, bottom];
}

/**
 * Find an artboard by name. Returns index (0-based) or -1.
 */
function findArtboardByName(doc, name) {
    for (var i = 0; i < doc.artboards.length; i++) {
        if (doc.artboards[i].name === name) {
            return i;
        }
    }
    return -1;
}

/**
 * Collect all current artboard names into a plain object (name → index).
 */
function getArtboardMap(doc) {
    var map = {};
    for (var i = 0; i < doc.artboards.length; i++) {
        map[doc.artboards[i].name] = i;
    }
    return map;
}

/* ─── Main sync function (called from JS via evalScript) ─── */

/**
 * syncArtboards(jsonString)
 * 
 * Accepts a JSON string array of artboard definitions:
 * [{ index, name, x, y, w, h }, ...]
 * 
 * Strategy (update by name):
 *  - For each row in Excel:
 *      • If artboard with that name exists → update its rect
 *      • If not → create a new artboard
 *  - After processing all rows, delete any artboards whose names
 *    are NOT in the Excel list (they were removed).
 *    Exception: always keep at least one artboard (Illustrator requirement).
 * 
 * Returns a JSON result string: { success, synced, created, updated, deleted, error }
 */
function syncArtboards(jsonString) {
    var result = {
        success: false,
        synced: 0,
        created: 0,
        updated: 0,
        deleted: 0,
        error: ''
    };

    try {
        if (!app.documents.length) {
            result.error = 'No document open in Illustrator.';
            return JSON.stringify(result);
        }

        var doc = app.activeDocument;
        var rows;
        try {
            rows = JSON.parse(jsonString);
        } catch (e) {
            result.error = 'Failed to parse data: ' + e.message;
            return JSON.stringify(result);
        }

        if (!rows || !rows.length) {
            result.error = 'No artboard data received.';
            return JSON.stringify(result);
        }

        /* Build set of incoming names */
        var incomingNames = {};
        for (var i = 0; i < rows.length; i++) {
            incomingNames[rows[i].name] = true;
        }

        /* ── Pass 1: Update existing / create new ── */
        for (var i = 0; i < rows.length; i++) {
            var row  = rows[i];
            var rect = buildRect(row.x, row.y, row.w, row.h);
            var idx  = findArtboardByName(doc, row.name);

            if (idx !== -1) {
                /* Update existing artboard */
                doc.artboards[idx].artboardRect = rect;
                result.updated++;
            } else {
                /* Create new artboard */
                var newAB = doc.artboards.add(rect);
                newAB.name = row.name;
                result.created++;
            }
            result.synced++;
        }

        /* ── Pass 2: Delete artboards not in Excel list ── */
        /* Collect removals first to avoid index shifting */
        var toDelete = [];
        for (var j = doc.artboards.length - 1; j >= 0; j--) {
            var abName = doc.artboards[j].name;
            if (!incomingNames[abName]) {
                toDelete.push(j);
            }
        }

        /* Keep at least one artboard */
        if (toDelete.length >= doc.artboards.length) {
            toDelete.pop();
        }

        for (var k = 0; k < toDelete.length; k++) {
            doc.artboards.remove(toDelete[k]);
            result.deleted++;
        }

        result.success = true;

    } catch (e) {
        result.error = e.message || String(e);
    }

    return JSON.stringify(result);
}

/**
 * getArtboardCount()
 * Returns the number of artboards in the active document.
 */
function getArtboardCount() {
    try {
        if (!app.documents.length) return '0';
        return String(app.activeDocument.artboards.length);
    } catch (e) {
        return '0';
    }
}

/**
 * checkDocument()
 * Returns 'ok' if a document is open, 'none' otherwise.
 */
function checkDocument() {
    try {
        return app.documents.length > 0 ? 'ok' : 'none';
    } catch (e) {
        return 'error';
    }
}

/* ─── Text Sync Helpers ─── */

function findFont(family, style) {
    if (!family) return null;
    var cleanFamily = family.replace(/\s+/g, "").toLowerCase();
    var cleanStyle = style ? style.replace(/\s+/g, "").toLowerCase() : "regular";
    for (var i = 0; i < app.textFonts.length; i++) {
        var f = app.textFonts[i];
        var fFamily = f.family.replace(/\s+/g, "").toLowerCase();
        var fStyle = f.style.replace(/\s+/g, "").toLowerCase();
        if (fFamily === cleanFamily && fStyle === cleanStyle) {
            return f;
        }
    }
    // Fallback: try by PostScript name guess
    try {
        return app.textFonts.getByName(family + "-" + (style || "Regular"));
    } catch (e) {
        try {
            return app.textFonts.getByName(family);
        } catch (e2) {
            return null;
        }
    }
}

function hexToRgb(hex) {
    if (!hex) return null;
    hex = hex.replace('#', '');
    if (hex.length === 3) {
        hex = hex[0]+hex[0] + hex[1]+hex[1] + hex[2]+hex[2];
    }
    if (hex.length !== 6) return null;
    var num = parseInt(hex, 16);
    return {
        r: (num >> 16) & 255,
        g: (num >> 8) & 255,
        b: num & 255
    };
}

function applyHexColor(colorObj, hex) {
    var rgb = hexToRgb(hex);
    if (rgb) {
        colorObj.red = rgb.r;
        colorObj.green = rgb.g;
        colorObj.blue = rgb.b;
        return true;
    }
    return false;
}

function convertToHindiDigits(text) {
    var western = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    var hindi = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    var res = "";
    for (var i = 0; i < text.length; i++) {
        var idx = -1;
        for (var j = 0; j < western.length; j++) {
            if (text[i] === western[j]) {
                idx = j;
                break;
            }
        }
        res += (idx !== -1) ? hindi[idx] : text[i];
    }
    return res;
}

function findTextFrameByName(doc, name) {
    for (var i = 0; i < doc.textFrames.length; i++) {
        if (doc.textFrames[i].name === name) {
            return doc.textFrames[i];
        }
    }
    return null;
}

/* ─── Main text sync function ─── */

function syncTexts(jsonString) {
    var result = {
        success: false,
        synced: 0,
        created: 0,
        updated: 0,
        deleted: 0,
        error: ''
    };

    try {
        if (!app.documents.length) {
            result.error = 'No document open in Illustrator.';
            return JSON.stringify(result);
        }

        var doc = app.activeDocument;
        var rows;
        try {
            rows = JSON.parse(jsonString);
        } catch (e) {
            result.error = 'Failed to parse data: ' + e.message;
            return JSON.stringify(result);
        }

        if (!rows) {
            result.error = 'No text data received.';
            return JSON.stringify(result);
        }

        /* Build set of incoming names */
        var incomingNames = {};
        for (var i = 0; i < rows.length; i++) {
            incomingNames["ExcelTextFrame_" + rows[i].index] = true;
        }

        /* ── Pass 1: Create or Update text frames ── */
        for (var i = 0; i < rows.length; i++) {
            var row = rows[i];
            var tfName = "ExcelTextFrame_" + row.index;
            var tf = findTextFrameByName(doc, tfName);
            var isNew = false;

            var isArea = (row.textType && row.textType.toLowerCase().indexOf("area") !== -1);

            if (isArea) {
                var rect = buildRect(row.x, row.y, row.w, row.h);
                if (tf) {
                    if (tf.kind === TextType.AREATEXT) {
                        tf.textPath.geometricBounds = rect;
                    } else {
                        tf.remove();
                        tf = null;
                    }
                }
                if (!tf) {
                    var pathItem = doc.pathItems.rectangle(rect[1], rect[0], pxToPt(row.w), pxToPt(row.h));
                    tf = doc.textFrames.areaText(pathItem);
                    tf.name = tfName;
                    isNew = true;
                }
            } else {
                var pos = [pxToPt(row.x), -pxToPt(row.y)];
                if (tf) {
                    if (tf.kind === TextType.POINTTEXT) {
                        tf.position = pos;
                    } else {
                        tf.remove();
                        tf = null;
                    }
                }
                if (!tf) {
                    tf = doc.textFrames.add();
                    tf.kind = TextType.POINTTEXT;
                    tf.position = pos;
                    tf.name = tfName;
                    isNew = true;
                }
            }

            // Set content with digit conversion
            var contentStr = row.textItself || "";
            if (row.digitType && row.digitType.toLowerCase() === 'hindi') {
                contentStr = convertToHindiDigits(contentStr);
            }
            tf.contents = contentStr;

            var textRange = tf.textRange;

            // Character styling
            if (row.textSize) {
                var sz = parseFloat(row.textSize);
                if (!isNaN(sz)) {
                    textRange.characterAttributes.size = sz;
                    textRange.characterAttributes.leading = sz * 1.25; // Good default leading
                }
            }

            if (row.fontFamily) {
                var matchedFont = findFont(row.fontFamily, row.fontStyle);
                if (matchedFont) {
                    textRange.characterAttributes.textFont = matchedFont;
                }
            }

            // Colors
            if (row.fillColor && row.fillColor.toLowerCase() !== 'none') {
                var fillRGB = new RGBColor();
                if (applyHexColor(fillRGB, row.fillColor)) {
                    textRange.characterAttributes.fillColor = fillRGB;
                }
            }

            if (row.strokeColor && row.strokeColor.toLowerCase() !== 'none') {
                var strokeRGB = new RGBColor();
                if (applyHexColor(strokeRGB, row.strokeColor)) {
                    textRange.characterAttributes.strokeColor = strokeRGB;
                }
                if (row.strokeWidth) {
                    var sw = parseFloat(row.strokeWidth);
                    if (!isNaN(sw)) {
                        textRange.characterAttributes.strokeWeight = sw;
                    }
                }
            } else {
                // Remove stroke if set to None or missing
                try {
                    var noColor = new NoColor();
                    textRange.characterAttributes.strokeColor = noColor;
                } catch(err) {}
            }

            // Paragraph styling - Alignment
            if (row.paragraphAlignment) {
                var align = row.paragraphAlignment.toLowerCase();
                if (align.indexOf("center") !== -1) {
                    textRange.paragraphAttributes.justification = Justification.CENTER;
                } else if (align.indexOf("right") !== -1) {
                    textRange.paragraphAttributes.justification = Justification.RIGHT;
                } else {
                    textRange.paragraphAttributes.justification = Justification.LEFT;
                }
            }

            // Paragraph styling - RTL/LTR
            if (row.paragraphDirection) {
                var dir = row.paragraphDirection.toLowerCase();
                try {
                    for (var p = 0; p < tf.paragraphs.length; p++) {
                        var para = tf.paragraphs[p];
                        if (dir.indexOf("rtl") !== -1 || dir.indexOf("right to left") !== -1) {
                            para.paragraphDirection = ParagraphDirectionType.RIGHT_TO_LEFT_DIRECTION;
                        } else {
                            para.paragraphDirection = ParagraphDirectionType.LEFT_TO_RIGHT_DIRECTION;
                        }
                    }
                } catch(e) {
                    try {
                        if (dir.indexOf("rtl") !== -1 || dir.indexOf("right to left") !== -1) {
                            textRange.paragraphAttributes.paragraphDirection = ParagraphDirectionType.RIGHT_TO_LEFT_DIRECTION;
                        } else {
                            textRange.paragraphAttributes.paragraphDirection = ParagraphDirectionType.LEFT_TO_RIGHT_DIRECTION;
                        }
                    } catch(e2) {}
                }
            }

            // Object styling - Opacity
            if (row.opacity !== undefined && row.opacity !== '') {
                var op = parseFloat(row.opacity);
                if (!isNaN(op)) {
                    tf.opacity = op;
                }
            }

            // Object styling - Blending Mode
            if (row.blendingMode) {
                var bm = row.blendingMode.toUpperCase().replace(/\s+/g, '');
                try {
                    tf.blendMode = BlendModes[bm];
                } catch(e) {
                    tf.blendMode = BlendModes.NORMAL;
                }
            }

            // Object styling - Rotation
            if (row.rotateAngle) {
                var rot = parseFloat(row.rotateAngle);
                if (!isNaN(rot) && rot !== 0) {
                    tf.rotate(rot);
                }
            }

            if (isNew) {
                result.created++;
            } else {
                result.updated++;
            }
            result.synced++;
        }

        /* ── Pass 2: Clean up deleted text frames ── */
        for (var j = doc.textFrames.length - 1; j >= 0; j--) {
            var tfItem = doc.textFrames[j];
            if (tfItem.name && tfItem.name.indexOf("ExcelTextFrame_") === 0) {
                if (!incomingNames[tfItem.name]) {
                    tfItem.remove();
                    result.deleted++;
                }
            }
        }

        result.success = true;

    } catch (e) {
        result.error = e.message || String(e);
    }

    return JSON.stringify(result);
}

/* ─── Main Rectangles Sync function ─── */
function syncRectangles(jsonString) {
    var result = {
        success: false,
        synced: 0,
        created: 0,
        updated: 0,
        deleted: 0,
        error: ''
    };

    try {
        if (!app.documents.length) {
            result.error = 'No document open in Illustrator.';
            return JSON.stringify(result);
        }

        var doc = app.activeDocument;
        var rows;
        try {
            rows = JSON.parse(jsonString);
        } catch (e) {
            result.error = 'Failed to parse data: ' + e.message;
            return JSON.stringify(result);
        }

        if (!rows) {
            result.error = 'No rectangle data received.';
            return JSON.stringify(result);
        }

        var incomingNames = {};
        for (var i = 0; i < rows.length; i++) {
            incomingNames["ExcelRectangle_" + rows[i].index] = true;
        }

        for (var i = 0; i < rows.length; i++) {
            var row = rows[i];
            var rectName = "ExcelRectangle_" + row.index;
            
            var pathItem = null;
            for (var p = 0; p < doc.pathItems.length; p++) {
                if (doc.pathItems[p].name === rectName) {
                    pathItem = doc.pathItems[p];
                    break;
                }
            }

            var isNew = false;
            var w = pxToPt(row.w);
            var h = pxToPt(row.h);
            var left = pxToPt(row.x);
            var top = -pxToPt(row.y);

            // Recreate if we want specific corner roundness and it's new
            // For updates, we just update width/height/position
            if (pathItem) {
                pathItem.position = [left, top];
                pathItem.width = w;
                pathItem.height = h;
            } else {
                if (row.cornerRoundnessValue > 0) {
                    var r = pxToPt(row.cornerRoundnessValue);
                    pathItem = doc.pathItems.roundedRectangle(top, left, w, h, r, r);
                } else {
                    pathItem = doc.pathItems.rectangle(top, left, w, h);
                }
                pathItem.name = rectName;
                isNew = true;
            }

            // Colors
            if (row.fillColor && row.fillColor.toLowerCase() !== 'none') {
                pathItem.filled = true;
                var fillRGB = new RGBColor();
                if (applyHexColor(fillRGB, row.fillColor)) {
                    pathItem.fillColor = fillRGB;
                }
            } else {
                pathItem.filled = false;
            }

            if (row.strokeColor && row.strokeColor.toLowerCase() !== 'none') {
                pathItem.stroked = true;
                var strokeRGB = new RGBColor();
                if (applyHexColor(strokeRGB, row.strokeColor)) {
                    pathItem.strokeColor = strokeRGB;
                }
                if (row.strokeWidth) {
                    var sw = parseFloat(row.strokeWidth);
                    if (!isNaN(sw)) {
                        pathItem.strokeWidth = sw;
                    }
                }
            } else {
                pathItem.stroked = false;
            }

            // Opacity
            if (row.opacity !== undefined && row.opacity !== '') {
                var op = parseFloat(row.opacity);
                if (!isNaN(op)) {
                    pathItem.opacity = op;
                }
            }

            // Blending Mode
            if (row.blendingMode) {
                var bm = row.blendingMode.toUpperCase().replace(/\s+/g, '');
                try {
                    pathItem.blendingMode = BlendModes[bm];
                } catch(e) {
                    pathItem.blendingMode = BlendModes.NORMAL;
                }
            }

            // Rotation (only on new to avoid cumulative rotation)
            if (isNew && row.rotateAngle) {
                var rot = parseFloat(row.rotateAngle);
                if (!isNaN(rot) && rot !== 0) {
                    pathItem.rotate(rot);
                }
            }

            if (isNew) {
                result.created++;
            } else {
                result.updated++;
            }
            result.synced++;
        }

        // Clean up deleted rectangles
        for (var j = doc.pathItems.length - 1; j >= 0; j--) {
            var pItem = doc.pathItems[j];
            if (pItem.name && pItem.name.indexOf("ExcelRectangle_") === 0) {
                if (!incomingNames[pItem.name]) {
                    pItem.remove();
                    result.deleted++;
                }
            }
        }

        result.success = true;

    } catch (e) {
        result.error = e.message || String(e);
    }

    return JSON.stringify(result);
}
