@echo off
setlocal enabledelayedexpansion
set "DEST_DIR=%APPDATA%\Adobe\CEP\extensions\ExcelArtboardSync"
set "CONFIRM="
set /p "CONFIRM=Type YES: "
set "CONFIRM=!CONFIRM:"=!"
if /i not "!CONFIRM!"=="YES" (
    if /i not "!CONFIRM!"=="Y" (
        echo Cancelled
        pause
        exit /b 0
    )
)
echo OK
pause
