@echo off
setlocal enabledelayedexpansion
for /d %%u in (C:\Users\*) do (
    echo Path: %%u
    echo Name: %%~nxu
    set "USER_DEST=%%u\AppData\Roaming\Adobe\CEP\extensions\ExcelArtboardSync"
    echo Dest: !USER_DEST!
    if exist "!USER_DEST!" (
        echo Exist: YES
    ) else (
        echo Exist: NO
    )
)
pause
