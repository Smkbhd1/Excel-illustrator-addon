# 2>nul & set "HYBRID_PATH=%~f0" & powershell -NoProfile -ExecutionPolicy Bypass -Command "iex ((Get-Content -Raw -Path $env:HYBRID_PATH))" & exit /b

Write-Host "Hello from PowerShell!" -ForegroundColor Green
$confirm = Read-Host "Type YES to confirm"
Write-Host "You typed: $confirm"
Read-Host "Press Enter to exit"
