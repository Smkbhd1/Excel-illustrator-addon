/**
 * main.js  –  CEP Panel Logic
 * Excel Artboard Sync for Adobe Illustrator
 *
 * Architecture:
 *  - Runs inside CEF (Chromium) with Node.js context enabled
 *  - Uses SheetJS (XLSX) to read .xlsx files
 *  - Uses Node.js `fs.watch()` for Live Mode file watching
 *  - Bridges to ExtendScript via CSInterface.evalScript()
 */

/* ── Node.js context bridge ── */
// In CEP with --mixed-context, we access Node.js via window.__adobe_cep__
// or simply use require() which is globally available.
var nodePath, nodeFs;
try {
    nodePath = require('path');
    nodeFs   = require('fs');
} catch (e) {
    console.warn('Node.js context not available:', e);
}
var XLSX = window.XLSX;

/* ── CSInterface ── */
var csInterface = new CSInterface();

/* ── State ── */
var state = {
    filePath:      '',
    sheetName:     'ArtBoards',
    isLive:        false,
    isWatching:    false,
    watcher:       null,
    lastArtboards: [],
    lastTexts:     [],
    lastRectangles:[],
    activeTab:     'artboards', // 'artboards' | 'texts' | 'rectangles'
    syncTimer:     null,
    syncDebounce:  1200  // ms debounce for live mode
};

/* ── Persist settings key ── */
var STORAGE_KEY = 'excelArtboardSync_v1';

/* ══════════════════════════════════════
   DOM references
   ══════════════════════════════════════ */
var $filePath    = document.getElementById('file-path-text');
var $fileBox     = document.getElementById('file-path-display');
var $browseBtn   = document.getElementById('browse-btn');
var $fileInput   = document.getElementById('file-input');
var $sheetInput  = document.getElementById('sheet-name-input');
var $liveToggle  = document.getElementById('live-toggle');
var $liveBadge   = document.getElementById('live-badge');
var $syncBtn     = document.getElementById('sync-btn');
var $statusDot   = document.getElementById('status-dot');
var $statBoards  = document.getElementById('stat-boards');
var $statRows    = document.getElementById('stat-rows');
var $statTime    = document.getElementById('stat-time');
var $tbody       = document.getElementById('preview-tbody');
var $logBox      = document.getElementById('log-box');
var $refreshPrev = document.getElementById('refresh-preview-btn');
var $clearLog    = document.getElementById('clear-log-btn');
var $tabArtboards = document.getElementById('tab-artboards-btn');
var $tabTexts     = document.getElementById('tab-texts-btn');
var $tabRectangles= document.getElementById('tab-rectangles-btn');

/* ══════════════════════════════════════
   Logging
   ══════════════════════════════════════ */
function log(msg, type) {
    type = type || 'info';
    var entry = document.createElement('div');
    entry.className = 'log-entry ' + type;

    var now = new Date();
    var ts  = pad(now.getHours()) + ':' + pad(now.getMinutes()) + ':' + pad(now.getSeconds());
    entry.textContent = '[' + ts + '] ' + msg;

    $logBox.appendChild(entry);
    $logBox.scrollTop = $logBox.scrollHeight;

    // Keep log to last 80 entries
    var entries = $logBox.querySelectorAll('.log-entry');
    if (entries.length > 80) {
        $logBox.removeChild(entries[0]);
    }
}

function pad(n) { return n < 10 ? '0' + n : String(n); }

/* ══════════════════════════════════════
   Status Dot
   ══════════════════════════════════════ */
function setStatus(status) {
    $statusDot.className = 'status-dot ' + status;
    var titles = { idle: 'Idle', live: 'Live — watching file', syncing: 'Syncing…', error: 'Error', success: 'Sync successful' };
    $statusDot.title = titles[status] || status;
}

/* ══════════════════════════════════════
   File Path Display
   ══════════════════════════════════════ */
function updateFileDisplay(filePath) {
    if (!filePath) {
        $filePath.textContent = 'No file selected';
        $filePath.className = '';
        $fileBox.title = '';
        return;
    }
    var name = filePath.replace(/\\/g, '/').split('/').pop();
    $filePath.textContent = name;
    $filePath.className = 'has-file';
    $fileBox.title = filePath;
}

/* ══════════════════════════════════════
   Persist / Load Settings
   ══════════════════════════════════════ */
function saveSettings() {
    try {
        var data = {
            filePath:  state.filePath,
            sheetName: state.sheetName,
            isLive:    state.isLive
        };
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (e) { /* ignore */ }
}

function loadSettings() {
    try {
        var raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return;
        var data = JSON.parse(raw);
        if (data.filePath)  { state.filePath  = data.filePath;  updateFileDisplay(data.filePath); }
        if (data.sheetName) { state.sheetName = data.sheetName; $sheetInput.value = data.sheetName; }
        if (data.isLive) {
            // Restore live mode after load
            state.isLive = false; // will be toggled by setLiveMode
            $liveToggle.checked = false;
        }
    } catch (e) { /* ignore */ }
}

/* ══════════════════════════════════════
   Excel Reading (SheetJS)
   ══════════════════════════════════════ */
function readExcelSheet(filePath, sheetName, requiredKeys) {
    if (!filePath || !nodeFs) return null;
    try {
        if (!nodeFs.existsSync(filePath)) {
            log('File not found: ' + filePath, 'error');
            return null;
        }

        if (!XLSX || typeof XLSX.read !== 'function') {
            if (window.XLSX && typeof window.XLSX.read === 'function') {
                XLSX = window.XLSX;
            } else {
                log('XLSX library (SheetJS) is not loaded or missing XLSX.read function.', 'error');
                return null;
            }
        }

        var buf = nodeFs.readFileSync(filePath);
        var workbook = XLSX.read(buf, { type: 'buffer', cellStyles: false, cellFormulas: false });

        var sheet = workbook.Sheets[sheetName];
        if (!sheet) {
            // Case-insensitive match fallback
            var names = workbook.SheetNames;
            for (var i = 0; i < names.length; i++) {
                if (names[i].toLowerCase() === sheetName.toLowerCase()) {
                    sheet = workbook.Sheets[names[i]];
                    break;
                }
            }
        }

        if (!sheet) {
            return null;
        }

        var raw = XLSX.utils.sheet_to_json(sheet, { header: 1 });
        if (!raw || raw.length < 2) return [];

        // Find header row containing ##
        var headerRowIdx = -1;
        for (var r = 0; r < Math.min(raw.length, 5); r++) {
            var row = raw[r];
            for (var c = 0; c < row.length; c++) {
                if (row[c] && String(row[c]).toLowerCase().indexOf('##') !== -1) {
                    headerRowIdx = r;
                    break;
                }
            }
            if (headerRowIdx !== -1) break;
        }

        if (headerRowIdx === -1) return null;

        var headers = raw[headerRowIdx];
        var colMap = {};

        for (var h = 0; h < headers.length; h++) {
            if (headers[h] !== null && headers[h] !== undefined) {
                var key = String(headers[h]).replace(/##/g, '').trim().toLowerCase();
                if (key === 'paragraph alignmnet') key = 'paragraph alignment';
                colMap[key] = h;
            }
        }

        // Validate required columns
        for (var ri = 0; ri < requiredKeys.length; ri++) {
            if (colMap[requiredKeys[ri]] === undefined) {
                log('Sheet "' + sheetName + '" missing required column: ##' + requiredKeys[ri], 'error');
                return null;
            }
        }

        var results = [];
        for (var dr = headerRowIdx + 1; dr < raw.length; dr++) {
            var dataRow = raw[dr];
            if (!dataRow || dataRow.length === 0) continue;

            var hasData = false;
            var obj = {};

            for (var colKey in colMap) {
                var colIdx = colMap[colKey];
                var val = dataRow[colIdx];
                if (val !== undefined && val !== null && String(val).trim() !== '') {
                    hasData = true;
                    obj[colKey] = val;
                } else {
                    obj[colKey] = '';
                }
            }

            if (hasData) {
                results.push(obj);
            }
        }

        return results;
    } catch (e) {
        log('Error parsing sheet "' + sheetName + '": ' + e.message, 'error');
        return null;
    }
}

function readExcel(filePath, sheetName) {
    var rawArtboards = readExcelSheet(filePath, sheetName, ['name', 'x', 'y', 'w', 'h']);
    if (!rawArtboards) return null;

    return rawArtboards.map(function(item) {
        return {
            index: item.index !== '' ? parseFloat(item.index) : 0,
            name:  String(item.name).trim(),
            x:     parseFloat(item.x)  || 0,
            y:     parseFloat(item.y)  || 0,
            w:     parseFloat(item.w)  || 100,
            h:     parseFloat(item.h)  || 100,
            referencePoint: String(item['reference point'] || 'top-left').trim()
        };
    });
}

function readTextsExcel(filePath) {
    var rawTexts = readExcelSheet(filePath, 'Texts', ['text itself', 'x', 'y']);
    if (!rawTexts) return []; // Optional sheet

    return rawTexts.map(function(item) {
        return {
            index:              item.index !== '' ? parseFloat(item.index) : 0,
            textItself:         String(item['text itself']).trim(),
            x:                  parseFloat(item.x) || 0,
            y:                  parseFloat(item.y) || 0,
            w:                  item.w !== '' ? parseFloat(item.w) : 100,
            h:                  item.h !== '' ? parseFloat(item.h) : 100,
            textType:           String(item['text type'] || 'Point type').trim(),
            rotateAngle:        String(item['rotate angle'] || '0').trim(),
            textSize:           item['text size'] !== '' ? parseFloat(item['text size']) : 12,
            fontFamily:         String(item['font family'] || '').trim(),
            fontStyle:          String(item['font style'] || '').trim(),
            paragraphAlignment: String(item['paragraph alignment'] || 'left').trim(),
            paragraphDirection: String(item['paragraph direction'] || 'LTR').trim(),
            digitType:          String(item['digit type'] || 'arabic').trim(),
            fillColor:          String(item['fill color'] || 'None').trim(),
            strokeColor:        String(item['stroke color'] || 'None').trim(),
            strokeWidth:        String(item['stroke width'] || '0').trim(),
            opacity:            item.opacity !== '' ? parseFloat(item.opacity) : 100,
            blendingMode:       String(item['blending mode'] || 'normal').trim(),
            referencePoint:     String(item['reference point'] || 'top-left').trim()
        };
    });
}

function readRectanglesExcel(filePath) {
    var rawRects = readExcelSheet(filePath, 'Rectangles', ['x', 'y', 'w', 'h']);
    if (!rawRects) return []; // Optional sheet

    return rawRects.map(function(item) {
        return {
            index: item.index !== '' ? parseFloat(item.index) : 0,
            x: parseFloat(item.x) || 0,
            y: parseFloat(item.y) || 0,
            w: item.w !== '' ? parseFloat(item.w) : 100,
            h: item.h !== '' ? parseFloat(item.h) : 100,
            cornerRoundnessValue: item['corner roundness value'] !== '' ? parseFloat(item['corner roundness value']) : 0,
            cornerRoundnessUpRight: item['corner roundnes up right'] !== '' ? parseFloat(item['corner roundnes up right']) : null,
            cornerRoundnessDownLeft: item['corner roundnes down left'] !== '' ? parseFloat(item['corner roundnes down left']) : null,
            cornerRoundnessDownRight: item['corner roundnes down right'] !== '' ? parseFloat(item['corner roundnes down right']) : null,
            rotateAngle: String(item['rotate angle'] || '0').trim(),
            fillColor: String(item['fill color'] || 'None').trim(),
            strokeColor: String(item['stroke color'] || 'None').trim(),
            strokeWidth: String(item['stroke width'] || '0').trim(),
            opacity: item.opacity !== '' ? parseFloat(item.opacity) : 100,
            blendingMode: String(item['blending mode'] || 'normal').trim(),
            referencePoint: String(item['reference point'] || 'top-left').trim()
        };
    });
}

/* ══════════════════════════════════════
   Preview Table
   ══════════════════════════════════════ */
function updatePreview() {
    var active = state.activeTab;
    var $thead = document.getElementById('preview-thead');
    var $tbody = document.getElementById('preview-tbody');

    if (active === 'artboards') {
        var artboards = state.lastArtboards || [];
        $thead.innerHTML = '<tr>' +
            '<th>#</th>' +
            '<th>Name</th>' +
            '<th>X</th>' +
            '<th>Y</th>' +
            '<th>W</th>' +
            '<th>H</th>' +
            '</tr>';

        if (artboards.length === 0) {
            $tbody.innerHTML = '<tr><td colspan="6" class="empty-cell">No artboards loaded</td></tr>';
            $statRows.textContent = '0';
            return;
        }

        var html = '';
        for (var i = 0; i < artboards.length; i++) {
            var ab = artboards[i];
            html += '<tr>' +
                '<td>' + (i + 1) + '</td>' +
                '<td>' + escapeHtml(ab.name) + '</td>' +
                '<td>' + ab.x + '</td>' +
                '<td>' + ab.y + '</td>' +
                '<td>' + ab.w + '</td>' +
                '<td>' + ab.h + '</td>' +
                '</tr>';
        }
        $tbody.innerHTML = html;
        $statRows.textContent = String(artboards.length);

    } else if (active === 'texts') {
        var texts = state.lastTexts || [];
        $thead.innerHTML = '<tr>' +
            '<th>#</th>' +
            '<th>Text</th>' +
            '<th>X</th>' +
            '<th>Y</th>' +
            '<th>W</th>' +
            '<th>H</th>' +
            '<th>Type</th>' +
            '<th>Size</th>' +
            '<th>Angle</th>' +
            '<th>Font Family</th>' +
            '<th>Font Style</th>' +
            '<th>Align</th>' +
            '<th>Dir</th>' +
            '<th>Digit</th>' +
            '<th>Fill</th>' +
            '<th>Stroke</th>' +
            '<th>S.Width</th>' +
            '<th>Opacity</th>' +
            '<th>Blend</th>' +
            '</tr>';

        if (texts.length === 0) {
            $tbody.innerHTML = '<tr><td colspan="19" class="empty-cell">No texts loaded</td></tr>';
            $statRows.textContent = '0';
            return;
        }

        var html = '';
        for (var i = 0; i < texts.length; i++) {
            var tx = texts[i];
            html += '<tr>' +
                '<td>' + (i + 1) + '</td>' +
                '<td title="' + escapeHtml(tx.textItself) + '">' + escapeHtml(truncateString(tx.textItself, 15)) + '</td>' +
                '<td>' + tx.x + '</td>' +
                '<td>' + tx.y + '</td>' +
                '<td>' + tx.w + '</td>' +
                '<td>' + tx.h + '</td>' +
                '<td>' + escapeHtml(tx.textType) + '</td>' +
                '<td>' + tx.textSize + '</td>' +
                '<td>' + escapeHtml(tx.rotateAngle) + '</td>' +
                '<td>' + escapeHtml(tx.fontFamily) + '</td>' +
                '<td>' + escapeHtml(tx.fontStyle) + '</td>' +
                '<td>' + escapeHtml(tx.paragraphAlignment) + '</td>' +
                '<td>' + escapeHtml(tx.paragraphDirection) + '</td>' +
                '<td>' + escapeHtml(tx.digitType) + '</td>' +
                '<td>' + escapeHtml(tx.fillColor) + '</td>' +
                '<td>' + escapeHtml(tx.strokeColor) + '</td>' +
                '<td>' + escapeHtml(tx.strokeWidth) + '</td>' +
                '<td>' + tx.opacity + '</td>' +
                '<td>' + escapeHtml(tx.blendingMode) + '</td>' +
                '</tr>';
        }
        $tbody.innerHTML = html;
        $statRows.textContent = String(texts.length);
    } else if (active === 'rectangles') {
        var rects = state.lastRectangles || [];
        $thead.innerHTML = '<tr>' +
            '<th>#</th>' +
            '<th>X</th>' +
            '<th>Y</th>' +
            '<th>W</th>' +
            '<th>H</th>' +
            '<th>Corner Val</th>' +
            '<th>Fill</th>' +
            '<th>Stroke</th>' +
            '<th>S.Width</th>' +
            '<th>Angle</th>' +
            '</tr>';

        if (rects.length === 0) {
            $tbody.innerHTML = '<tr><td colspan="10" class="empty-cell">No rectangles loaded</td></tr>';
            $statRows.textContent = '0';
            return;
        }

        var html = '';
        for (var i = 0; i < rects.length; i++) {
            var r = rects[i];
            html += '<tr>' +
                '<td>' + (i + 1) + '</td>' +
                '<td>' + r.x + '</td>' +
                '<td>' + r.y + '</td>' +
                '<td>' + r.w + '</td>' +
                '<td>' + r.h + '</td>' +
                '<td>' + r.cornerRoundnessValue + '</td>' +
                '<td>' + escapeHtml(r.fillColor) + '</td>' +
                '<td>' + escapeHtml(r.strokeColor) + '</td>' +
                '<td>' + escapeHtml(r.strokeWidth) + '</td>' +
                '<td>' + escapeHtml(r.rotateAngle) + '</td>' +
                '</tr>';
        }
        $tbody.innerHTML = html;
        $statRows.textContent = String(rects.length);
    }
}

function truncateString(str, num) {
    if (str.length <= num) return str;
    return str.slice(0, num) + '...';
}

function escapeHtml(str) {
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

/* ══════════════════════════════════════
   File Picker
   ══════════════════════════════════════ */
function openFilePicker() {
    log('--- Browse clicked ---', 'info');
    log('nodeFs available: ' + (nodeFs ? 'YES' : 'NO'), 'info');
    log('window.cep available: ' + (window.cep ? 'YES' : 'NO'), 'info');
    log('window.cep.fs available: ' + (window.cep && window.cep.fs ? 'YES' : 'NO'), 'info');

    // Method 1: cep.fs.showOpenDialog (native CEP synchronous API)
    try {
        if (window.cep && window.cep.fs) {
            log('Trying Method 1: cep.fs.showOpenDialog...', 'info');
            var cepResult = window.cep.fs.showOpenDialog(
                false, false, 'Select Excel File', '', ['xlsx', 'xls']
            );
            log('cep.fs result: ' + JSON.stringify(cepResult), 'info');
            if (cepResult && cepResult.data && cepResult.data.length > 0) {
                log('Method 1 SUCCESS: ' + cepResult.data[0], 'success');
                setFilePath(cepResult.data[0]);
                return;
            }
            if (cepResult && cepResult.err === 0) {
                log('Method 1: user cancelled.', 'info');
                return;
            }
            log('Method 1: no file selected, falling through.', 'warning');
        } else {
            log('Method 1 SKIPPED: cep.fs not available.', 'warning');
        }
    } catch(e1) {
        log('Method 1 ERROR: ' + e1.message, 'error');
    }

    // Method 2: PowerShell file picker via Node.js child_process
    try {
        if (nodeFs) {
            log('Trying Method 2: PowerShell child_process...', 'info');
            var nodeChild = require('child_process');
            log('child_process loaded OK', 'info');
            var psCmd = '[System.Reflection.Assembly]::LoadWithPartialName(\'System.Windows.Forms\') | Out-Null; ' +
                '$d = New-Object System.Windows.Forms.OpenFileDialog; ' +
                '$d.Filter = \'Excel Files (*.xlsx;*.xls)|*.xlsx;*.xls\'; ' +
                '$d.Title = \'Select Excel File\'; ' +
                'if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { $d.FileName } else { \'\' }';
            log('Spawning PowerShell...', 'info');
            var picked = nodeChild.execSync(
                'powershell -NoProfile -NonInteractive -Command "' + psCmd + '"',
                { timeout: 60000 }
            ).toString().trim();
            log('PowerShell returned: "' + picked + '"', 'info');
            if (picked && picked.length > 0) {
                log('Method 2 SUCCESS: ' + picked, 'success');
                setFilePath(picked);
                return;
            }
            log('Method 2: user cancelled.', 'info');
            return;
        } else {
            log('Method 2 SKIPPED: nodeFs not available.', 'warning');
        }
    } catch(e2) {
        log('Method 2 ERROR: ' + e2.message, 'error');
    }

    // Method 3: evalScript fallback (needs Illustrator focus)
    log('Trying Method 3: evalScript File.openDialog...', 'info');
    csInterface.evalScript(
        '(function(){ try { var f = File.openDialog("Select Excel file", "*.xlsx;*.xls", false); return f ? f.fsName : "null"; } catch(e){ return "ERR:"+e.message; } })()',
        function(result) {
            log('evalScript returned: ' + result, 'info');
            if (result && result !== 'null' && result !== 'EvalScript error.' && result.indexOf('ERR:') !== 0) {
                log('Method 3 SUCCESS: ' + result, 'success');
                setFilePath(result);
            } else {
                log('Method 3 FAILED: ' + result, 'error');
                log('All file dialog methods failed!', 'error');
            }
        }
    );
}

/* ══════════════════════════════════════
   Artboard Count from Illustrator
   ══════════════════════════════════════ */
function refreshArtboardCount() {
    csInterface.evalScript('getArtboardCount()', function(result) {
        if (result && result !== 'EvalScript error.') {
            $statBoards.textContent = result;
        }
    });
}

/* ══════════════════════════════════════
   Core Sync
   ══════════════════════════════════════ */
function doSync() {
    if (!state.filePath) {
        log('No file selected.', 'warning');
        return;
    }

    $syncBtn.classList.add('spinning');
    $syncBtn.disabled = true;
    setStatus('syncing');

    var artboards = readExcel(state.filePath, state.sheetName);

    if (!artboards) {
        $syncBtn.classList.remove('spinning');
        $syncBtn.disabled = false;
        setStatus('error');
        return;
    }

    state.lastData = artboards;
    updatePreview(artboards);

    if (artboards.length === 0) {
        log('No artboard rows found in sheet.', 'warning');
        $syncBtn.classList.remove('spinning');
        $syncBtn.disabled = false;
        setStatus('idle');
        return;
    }

    var texts = readTextsExcel(state.filePath) || [];
    var rectangles = readRectanglesExcel(state.filePath) || [];

    var jsonStrAB = JSON.stringify(artboards);
    var escapedAB = jsonStrAB.replace(/\\/g, '\\\\').replace(/'/g, "\\'");

    // 1. Sync Artboards
    csInterface.evalScript("syncArtboards('" + escapedAB + "')", function(resultAB) {
        var abStatus = false;
        try {
            var resAB = JSON.parse(resultAB);
            if (resAB.success) {
                var msg = 'Artboards: Synced ' + resAB.synced;
                if (resAB.created)  msg += ' | +' + resAB.created + ' new';
                if (resAB.updated)  msg += ' | ~' + resAB.updated + ' updated';
                if (resAB.deleted)  msg += ' | -' + resAB.deleted + ' removed';
                log(msg, 'success');
                abStatus = true;
            } else {
                log('Artboard sync failed: ' + (resAB.error || 'Unknown error'), 'error');
            }
        } catch (e) {
            if (resultAB && resultAB.indexOf('EvalScript error') !== -1) {
                log('Illustrator artboard script error. Is document open?', 'error');
            } else {
                log('Artboard sync parsing error: ' + resultAB, 'error');
            }
        }

        // 2. Sync Texts
        if (abStatus && texts.length > 0) {
            var jsonStrTX = JSON.stringify(texts);
            var escapedTX = jsonStrTX.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
            csInterface.evalScript("syncTexts('" + escapedTX + "')", function(resultTX) {
                try {
                    var resTX = JSON.parse(resultTX);
                    if (resTX.success) {
                        var msg = 'Texts: Synced ' + resTX.synced;
                        if (resTX.created)  msg += ' | +' + resTX.created + ' new';
                        if (resTX.updated)  msg += ' | ~' + resTX.updated + ' updated';
                        if (resTX.deleted)  msg += ' | -' + resTX.deleted + ' removed';
                        log(msg, 'success');
                    } else {
                        log('Text sync failed: ' + (resTX.error || 'Unknown error'), 'error');
                    }
                } catch (e) {
                    log('Text sync parsing error: ' + resultTX, 'error');
                }
                syncRectanglesStep();
            });
        } else {
            if (abStatus && texts.length === 0) log('No texts sheet found or rows empty. Skipped text sync.', 'info');
            syncRectanglesStep();
        }

        function syncRectanglesStep() {
            if (abStatus && rectangles.length > 0) {
                var jsonStrRC = JSON.stringify(rectangles);
                var escapedRC = jsonStrRC.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
                csInterface.evalScript("syncRectangles('" + escapedRC + "')", function(resultRC) {
                    try {
                        var resRC = JSON.parse(resultRC);
                        if (resRC.success) {
                            var msg = 'Rectangles: Synced ' + resRC.synced;
                            if (resRC.created)  msg += ' | +' + resRC.created + ' new';
                            if (resRC.updated)  msg += ' | ~' + resRC.updated + ' updated';
                            if (resRC.deleted)  msg += ' | -' + resRC.deleted + ' removed';
                            log(msg, 'success');
                            setStatus('success');
                        } else {
                            log('Rectangle sync failed: ' + (resRC.error || 'Unknown error'), 'error');
                            setStatus('error');
                        }
                    } catch (e) {
                        log('Rectangle sync parsing error: ' + resultRC, 'error');
                        setStatus('error');
                    }
                    finalizeSync();
                });
            } else {
                if (abStatus && rectangles.length === 0) log('No rectangles sheet found. Skipped rectangle sync.', 'info');
                if (abStatus) setStatus('success');
                else setStatus('error');
                finalizeSync();
            }
        }

        function finalizeSync() {
            $syncBtn.classList.remove('spinning');
            $syncBtn.disabled = false;
            setTimeout(function() {
                setStatus(state.isLive ? 'live' : 'idle');
            }, 2000);
            var now = new Date();
            $statTime.textContent = pad(now.getHours()) + ':' + pad(now.getMinutes());
            refreshArtboardCount();
        }
    });
}

/* ══════════════════════════════════════
   Live Mode / File Watching
   ══════════════════════════════════════ */
function startWatching() {
    if (!nodeFs || !state.filePath) return;
    stopWatching();

    try {
        state.watcher = nodeFs.watch(state.filePath, { persistent: false }, function(event) {
            if (event === 'change') {
                // Debounce rapid saves
                if (state.syncTimer) clearTimeout(state.syncTimer);
                state.syncTimer = setTimeout(function() {
                    log('File changed — auto-syncing…', 'info');
                    doSync();
                }, state.syncDebounce);
            }
        });
        state.isWatching = true;
        log('Watching: ' + state.filePath.replace(/\\/g, '/').split('/').pop(), 'success');
    } catch (e) {
        log('Cannot watch file: ' + e.message, 'error');
    }
}

function stopWatching() {
    if (state.watcher) {
        try { state.watcher.close(); } catch (e) {}
        state.watcher = null;
    }
    if (state.syncTimer) {
        clearTimeout(state.syncTimer);
        state.syncTimer = null;
    }
    state.isWatching = false;
}

function setLiveMode(enabled) {
    state.isLive = enabled;
    $liveToggle.checked = enabled;

    if (enabled) {
        $liveBadge.classList.remove('hidden');
        setStatus('live');
        startWatching();
        log('Live Mode ON', 'success');
    } else {
        $liveBadge.classList.add('hidden');
        setStatus('idle');
        stopWatching();
        log('Live Mode OFF', 'info');
    }
    saveSettings();
}

/* ══════════════════════════════════════
   File Picking
   ══════════════════════════════════════ */
function setFilePath(fp) {
    state.filePath = fp;
    updateFileDisplay(fp);
    saveSettings();

    if (fp) {
        // Load preview
        var artboards = readExcel(fp, state.sheetName);
        var texts = readTextsExcel(fp) || [];
        
        state.lastArtboards = artboards || [];
        state.lastTexts = texts;
        
        updatePreview();
        
        if (artboards) {
            log('Loaded ' + artboards.length + ' artboard(s) and ' + texts.length + ' text(s) from Excel.', 'success');
        }

        // Re-attach watcher if live
        if (state.isLive) {
            startWatching();
        }
    }
}

/* ══════════════════════════════════════
   Event Listeners
   ══════════════════════════════════════ */

// Sync button
$syncBtn.addEventListener('click', function() {
    log('Button clicked: "Sync Now". Initializing sync...', 'info');
    doSync();
});

// Browse button – native Windows file picker via PowerShell (Node.js child_process)
// This approach is fully independent of Illustrator focus, always reliable in CEP.
$browseBtn.addEventListener('click', function() {
    log('Button clicked: "Browse" (Folder icon). Opening file dialog...', 'info');
    openFilePicker();
});

// Also allow clicking the path box
$fileBox.addEventListener('click', function() {
    log('Click: File Path display box clicked. Opening file dialog...', 'info');
    openFilePicker();
});

// Live mode toggle
$liveToggle.addEventListener('change', function() {
    log('Toggle changed: "Live Mode" set to ' + (this.checked ? 'ON' : 'OFF'), 'info');
    setLiveMode(this.checked);
});

// Tab switching
$tabArtboards.addEventListener('click', function() {
    log('Tab clicked: "Artboards". Loading artboards preview...', 'info');
    state.activeTab = 'artboards';
    $tabArtboards.classList.add('active');
    $tabTexts.classList.remove('active');
    $tabRectangles.classList.remove('active');
    updatePreview();
});

$tabTexts.addEventListener('click', function() {
    log('Tab clicked: "Texts". Loading texts preview...', 'info');
    state.activeTab = 'texts';
    $tabTexts.classList.add('active');
    $tabArtboards.classList.remove('active');
    $tabRectangles.classList.remove('active');
    updatePreview();
});

$tabRectangles.addEventListener('click', function() {
    log('Tab clicked: "Rectangles". Loading rectangles preview...', 'info');
    state.activeTab = 'rectangles';
    $tabRectangles.classList.add('active');
    $tabArtboards.classList.remove('active');
    $tabTexts.classList.remove('active');
    updatePreview();
});

// Sheet name change
$sheetInput.addEventListener('change', function() {
    log('Input changed: "Sheet name" set to "' + this.value + '". Reloading preview...', 'info');
    state.sheetName = this.value.trim() || 'ArtBoards';
    saveSettings();
    // Reload preview
    if (state.filePath) {
        var artboards = readExcel(state.filePath, state.sheetName);
        state.lastArtboards = artboards || [];
        updatePreview();
    }
});

// Refresh preview
$refreshPrev.addEventListener('click', function() {
    log('Button clicked: "Refresh". Force reading Excel data...', 'info');
    if (!state.filePath) { log('Refresh aborted: No file selected.', 'warning'); return; }
    var artboards = readExcel(state.filePath, state.sheetName);
    var texts = readTextsExcel(state.filePath) || [];
    var rectangles = readRectanglesExcel(state.filePath) || [];
    state.lastArtboards = artboards || [];
    state.lastTexts = texts;
    state.lastRectangles = rectangles;
    updatePreview();
    log('Preview refreshed.', 'info');
});

// Clear log
$clearLog.addEventListener('click', function() {
    // Clear the DOM but log one line so they know it cleared
    $logBox.innerHTML = '';
    log('Log cleared.', 'info');
});

// Debug Position Apply Button
var $debugApplyBtn = document.getElementById('debug-apply-btn');
var $debugXInput   = document.getElementById('debug-x-input');
var $debugYInput   = document.getElementById('debug-y-input');

$debugApplyBtn.addEventListener('click', function() {
    var xVal = $debugXInput.value.trim();
    var yVal = $debugYInput.value.trim();
    log('Click: "Apply Position" button clicked. Target coordinates: X=' + xVal + ', Y=' + yVal, 'info');
    
    csInterface.evalScript("debugSetPosition('" + xVal + "', '" + yVal + "')", function(result) {
        if (result.indexOf('ERR:') === 0) {
            log(result, 'error');
        } else {
            var lines = result.split('\n');
            lines.forEach(function(line) {
                log(line, 'success');
            });
        }
    });
});

// Theme synchronization with Illustrator
csInterface.addEventListener('com.adobe.csxs.events.ThemeColorChanged', function(e) {
    // Optionally sync to Illustrator's theme — panel uses its own dark theme
});

/* ══════════════════════════════════════
   Init
   ══════════════════════════════════════ */
(function init() {
    log('Excel Artboard Sync panel loaded.', 'info');

    // Default file path from the project
    var defaultPath = 'E:\\IMP\\MyApps\\My illustrator Scripts and Stuff\\Excel-illustrator-addon\\Test Excel File\\TestExcel-14050422-1-1.xlsx';
    if (nodeFs && nodeFs.existsSync(defaultPath)) {
        setFilePath(defaultPath);
        log('Default file detected and loaded.', 'success');
    } else {
        // Try to restore saved settings
        loadSettings();
        if (state.filePath) {
            log('Restored file: ' + state.filePath.split(/[\\/]/).pop(), 'info');
        }
    }

    // Update artboard count
    refreshArtboardCount();
    setStatus('idle');
})();
