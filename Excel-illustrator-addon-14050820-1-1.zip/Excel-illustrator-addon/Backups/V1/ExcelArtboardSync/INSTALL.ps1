<#
.SYNOPSIS
    Installs the "Excel Artboard Sync" CEP extension for Adobe Illustrator.
.DESCRIPTION
    1. Enables PlayerDebugMode in Windows Registry (loads unsigned extensions)
    2. Copies extension to %APPDATA%\Adobe\CEP\extensions\
    3. Downloads SheetJS (xlsx.full.min.js) if not already present
    4. Prints verification summary
#>

$ErrorActionPreference = 'Stop'

# ── Paths ─────────────────────────────────────────────────────────────────
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ExtId     = "ExcelArtboardSync"
$DestRoot  = "$env:APPDATA\Adobe\CEP\extensions"
$DestDir   = "$DestRoot\$ExtId"
$XlsxJs    = "$ScriptDir\js\xlsx.full.min.js"
$XlsxUrl   = "https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js"

Write-Host ""
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host "   Excel Artboard Sync - CEP Extension Installer     " -ForegroundColor Cyan
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host ""

# ── Step 1: Registry ──────────────────────────────────────────────────────
Write-Host "Step 1: Enabling PlayerDebugMode in registry..." -ForegroundColor Yellow

$csxsVersions = @("11", "12", "10", "9")
foreach ($ver in $csxsVersions) {
    $regPath = "HKCU:\Software\Adobe\CSXS.$ver"
    try {
        if (-not (Test-Path $regPath)) {
            New-Item -Path $regPath -Force | Out-Null
        }
        Set-ItemProperty -Path $regPath -Name "PlayerDebugMode" -Value "1" -Type String -Force
        Write-Host "  [OK] Set PlayerDebugMode=1 in CSXS.$ver" -ForegroundColor Green
    } catch {
        Write-Host "  [--] CSXS.$ver skipped: $($_.Exception.Message)" -ForegroundColor DarkGray
    }
}

# ── Step 2: Create destination ────────────────────────────────────────────
Write-Host ""
Write-Host "Step 2: Preparing extension folder..." -ForegroundColor Yellow

if (-not (Test-Path $DestRoot)) {
    New-Item -ItemType Directory -Path $DestRoot -Force | Out-Null
    Write-Host "  [OK] Created: $DestRoot" -ForegroundColor Green
}

if (Test-Path $DestDir) {
    Write-Host "  Removing old install..." -ForegroundColor DarkGray
    Remove-Item -Recurse -Force -Path $DestDir
}

# ── Step 3: SheetJS ───────────────────────────────────────────────────────
Write-Host ""
Write-Host "Step 3: Checking SheetJS (xlsx.full.min.js)..." -ForegroundColor Yellow

if (-not (Test-Path $XlsxJs)) {
    Write-Host "  Downloading SheetJS from CDN..." -ForegroundColor DarkGray
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $XlsxUrl -OutFile $XlsxJs -UseBasicParsing
        Write-Host "  [OK] Downloaded: xlsx.full.min.js" -ForegroundColor Green
    } catch {
        Write-Host "  [ERR] Failed: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "  Manual download URL: $XlsxUrl" -ForegroundColor Yellow
        Write-Host "  Save it to: $ScriptDir\js\xlsx.full.min.js" -ForegroundColor Yellow
    }
} else {
    Write-Host "  [OK] SheetJS already present." -ForegroundColor Green
}

# ── Step 4: Copy files ────────────────────────────────────────────────────
Write-Host ""
Write-Host "Step 4: Copying extension files..." -ForegroundColor Yellow

try {
    Copy-Item -Recurse -Force -Path $ScriptDir -Destination $DestDir
    Write-Host "  [OK] Copied to: $DestDir" -ForegroundColor Green
} catch {
    Write-Host "  [ERR] $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# ── Step 5: Verify ────────────────────────────────────────────────────────
Write-Host ""
Write-Host "Step 5: Verifying install..." -ForegroundColor Yellow

$checkFiles = @(
    "CSXS\manifest.xml",
    "index.html",
    "js\main.js",
    "js\CSInterface.js",
    "js\xlsx.full.min.js",
    "jsx\artboard.jsx",
    "css\style.css"
)

$allOk = $true
foreach ($f in $checkFiles) {
    $fp = "$DestDir\$f"
    if (Test-Path $fp) {
        Write-Host "  [OK] $f" -ForegroundColor Green
    } else {
        Write-Host "  [MISSING] $f" -ForegroundColor Red
        $allOk = $false
    }
}

# ── Done ──────────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "=====================================================" -ForegroundColor Cyan

if ($allOk) {
    Write-Host "  Installation COMPLETE!" -ForegroundColor Green
} else {
    Write-Host "  Installation done with warnings (missing files above)." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "  Next steps:" -ForegroundColor White
Write-Host "  1. Close Adobe Illustrator completely (if open)" -ForegroundColor White
Write-Host "  2. Re-open Adobe Illustrator" -ForegroundColor White
Write-Host "  3. Go to: Window > Extensions > Excel Artboard Sync" -ForegroundColor White
Write-Host ""
Write-Host "  Installed to:" -ForegroundColor DarkGray
Write-Host "  $DestDir" -ForegroundColor DarkGray
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host ""
