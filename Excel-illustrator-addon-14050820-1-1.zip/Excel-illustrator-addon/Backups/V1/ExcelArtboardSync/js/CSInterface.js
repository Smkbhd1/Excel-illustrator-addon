/**
 * CSInterface.js  –  Adobe CEP CSInterface v9.3
 * Minimal clean version with all required APIs.
 * Adapted from Adobe's open-source CSInterface library (Apache 2.0).
 */

var SystemPath = {
    USER_DATA:     'userData',
    COMMON_FILES:  'commonFiles',
    MY_DOCUMENTS:  'myDocuments',
    APPLICATION:   'application',
    EXTENSION:     'extension',
    HOST_APPLICATION: 'hostApplication'
};

var ColorType = { NONE: 'none', CUSTOM: 'custom', FOREGROUND: 'foreground' };

var RGBColor = function(red, green, blue) {
    this.red   = red;
    this.green = green;
    this.blue  = blue;
};

var Direction = { TOP: 0, RIGHT: 1, BOTTOM: 2, LEFT: 3 };

var GradientStop = function(offset, rgbColor) {
    this.offset   = offset;
    this.rgbColor = rgbColor;
};

var GradientColor = function(type, direction, numStops, gradientStopList) {
    this.type             = type;
    this.direction        = direction;
    this.numStops         = numStops;
    this.gradientStopList = gradientStopList;
};

var UIColor = function(type, antialiasLevel, color) {
    this.type           = type;
    this.antialiasLevel = antialiasLevel;
    this.color          = color;
};

var AppSkinInfo = function(baseFontFamily, baseFontSize, appBarBackgroundColor, panelBackgroundColor, appBarBackgroundColorSRGB, panelBackgroundColorSRGB, systemHighlightColor) {
    this.baseFontFamily              = baseFontFamily;
    this.baseFontSize                = baseFontSize;
    this.appBarBackgroundColor       = appBarBackgroundColor;
    this.panelBackgroundColor        = panelBackgroundColor;
    this.appBarBackgroundColorSRGB   = appBarBackgroundColorSRGB;
    this.panelBackgroundColorSRGB    = panelBackgroundColorSRGB;
    this.systemHighlightColor        = systemHighlightColor;
};

var HostEnvironment = function(appName, appVersion, appLocale, appUILocale, appId, isAppOnline, appSkinInfo) {
    this.appName      = appName;
    this.appVersion   = appVersion;
    this.appLocale    = appLocale;
    this.appUILocale  = appUILocale;
    this.appId        = appId;
    this.isAppOnline  = isAppOnline;
    this.appSkinInfo  = appSkinInfo;
};

var HostCapabilities = function(EXTENDED_PANEL_MENU, EXTENDED_PANEL_ICONS, DELEGATE_APE_ENGINE, SUPPORT_HTML_EXTENSIONS, DISABLE_FLASH_EXTENSIONS) {
    this.EXTENDED_PANEL_MENU       = EXTENDED_PANEL_MENU;
    this.EXTENDED_PANEL_ICONS      = EXTENDED_PANEL_ICONS;
    this.DELEGATE_APE_ENGINE       = DELEGATE_APE_ENGINE;
    this.SUPPORT_HTML_EXTENSIONS   = SUPPORT_HTML_EXTENSIONS;
    this.DISABLE_FLASH_EXTENSIONS  = DISABLE_FLASH_EXTENSIONS;
};

var ApiVersion = function(major, minor, micro) {
    this.major = major;
    this.minor = minor;
    this.micro = micro;
};

var CSXSWindowType = {
    _PANEL: 'Panel',
    _MODELESS: 'Modeless',
    _MODAL_DIALOG: 'ModalDialog'
};

var CSEvent = function(type, scope, appId, extensionId) {
    this.type        = type;
    this.scope       = scope;
    this.appId       = appId;
    this.extensionId = extensionId;
    this.data        = '';
};

var EvalScript_ErrMessage = 'EvalScript error.';

var CSInterface = (function() {

    function CSInterface() {
        if (typeof window.__adobe_cep__ !== 'undefined') {
            this.hostEnvironment = JSON.parse(window.__adobe_cep__.getHostEnvironment());
        } else {
            this.hostEnvironment = {};
        }
    }

    CSInterface.GLOBAL_SCOPE = 'GLOBAL';
    CSInterface.LOCAL_SCOPE  = 'LOCAL';

    CSInterface.prototype.getSystemPath = function(pathType) {
        var path;
        try {
            path = decodeURIComponent(window.__adobe_cep__.getSystemPath(pathType));
        } catch (e) {
            path = '';
        }
        return path;
    };

    CSInterface.prototype.evalScript = function(script, callback) {
        if (typeof callback !== 'function') {
            callback = function(result) {};
        }
        window.__adobe_cep__.evalScript(script, callback);
    };

    CSInterface.prototype.getApplicationID = function() {
        if (this.hostEnvironment && this.hostEnvironment.appId) {
            return this.hostEnvironment.appId;
        }
        return '';
    };

    CSInterface.prototype.getHostCapabilities = function() {
        var caps;
        try {
            caps = JSON.parse(window.__adobe_cep__.getHostCapabilities());
        } catch (e) {
            caps = {};
        }
        return caps;
    };

    CSInterface.prototype.dispatchEvent = function(event) {
        if (typeof event.data !== 'string') {
            event.data = JSON.stringify(event.data);
        }
        window.__adobe_cep__.dispatchEvent(event);
    };

    CSInterface.prototype.addEventListener = function(type, listener, obj) {
        window.__adobe_cep__.addEventListener(type, listener, obj);
    };

    CSInterface.prototype.removeEventListener = function(type, listener, obj) {
        window.__adobe_cep__.removeEventListener(type, listener, obj);
    };

    CSInterface.prototype.requestOpenExtension = function(extensionId, params) {
        window.__adobe_cep__.requestOpenExtension(extensionId, params || '');
    };

    CSInterface.prototype.getExtensions = function(extensionIds) {
        var exts;
        try {
            exts = JSON.parse(window.__adobe_cep__.getExtensions(JSON.stringify(extensionIds)));
        } catch (e) {
            exts = [];
        }
        return exts;
    };

    CSInterface.prototype.getNetworkPreferences = function() {
        var prefs;
        try {
            prefs = JSON.parse(window.__adobe_cep__.getNetworkPreferences());
        } catch (e) {
            prefs = {};
        }
        return prefs;
    };

    CSInterface.prototype.initResourceBundle = function() {
        var langs;
        try {
            var locale = JSON.parse(window.__adobe_cep__.getHostEnvironment()).appUILocale;
            // basic stub
            langs = {};
        } catch (e) {
            langs = {};
        }
        return langs;
    };

    CSInterface.prototype.dumpInstallationInfo = function() {
        return window.__adobe_cep__.dumpInstallationInfo();
    };

    CSInterface.prototype.getOSInformation = function() {
        var userAgent = navigator.userAgent;
        if (navigator.platform === 'Win32' || navigator.platform === 'Windows') {
            var winVersion = 'Windows';
            if (userAgent.indexOf('Windows NT 10') !== -1) winVersion = 'Windows 10';
            else if (userAgent.indexOf('Windows NT 6.3') !== -1) winVersion = 'Windows 8.1';
            else if (userAgent.indexOf('Windows NT 6.2') !== -1) winVersion = 'Windows 8';
            else if (userAgent.indexOf('Windows NT 6.1') !== -1) winVersion = 'Windows 7';
            return winVersion;
        } else if (navigator.platform === 'MacIntel' || navigator.platform === 'Macintosh') {
            return 'Mac OS X';
        }
        return 'Unknown';
    };

    CSInterface.prototype.openURLInDefaultBrowser = function(url) {
        if (window.cep && window.cep.util) {
            return window.cep.util.openURLInDefaultBrowser(url);
        }
        return false;
    };

    CSInterface.prototype.getExtensionID = function() {
        return window.__adobe_cep__.getExtensionId();
    };

    CSInterface.prototype.getScaleFactorOfScreen = function() {
        var screenWidth = screen.availWidth;
        if (window.devicePixelRatio) return window.devicePixelRatio;
        return 1;
    };

    CSInterface.prototype.setWindowTitle = function(title) {
        window.__adobe_cep__.setWindowTitle(title);
    };

    CSInterface.prototype.getWindowTitle = function() {
        return window.__adobe_cep__.getWindowTitle();
    };

    return CSInterface;
}());
