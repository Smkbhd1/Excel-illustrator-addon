/**
 * main.js  –  CEP Panel Logic
 * Excel Artboard Sync for Adobe Illustrator
 *
 * Architecture:
 *  - Runs inside CEF (Chromium) with Node.js context enabled
 *  - Uses SheetJS (XLSX) to read .xlsx files
 *  - Uses Node.js `fs.watch()` for Live Mode file watching
 *  - Bridges to ExtendScript via CSInterface.evalScript()
 */

/* ── Node.js context bridge ── */
// In CEP with --mixed-context, we access Node.js via window.__adobe_cep__
// or simply use require() which is globally available.
var nodePath, nodeFs;
try {
    nodePath = require('path');
    nodeFs   = require('fs');
} catch (e) {
    console.warn('Node.js context not available:', e);
}
var XLSX = window.XLSX;

/* ── CSInterface ── */
var csInterface = new CSInterface();

/* ── State ── */
var state = {
    filePath:    '',
    sheetName:   'ArtBoards',
    isLive:      false,
    isWatching:  false,
    watcher:     null,
    lastData:    [],
    syncTimer:   null,
    syncDebounce: 1200  // ms debounce for live mode
};

/* ── Persist settings key ── */
var STORAGE_KEY = 'excelArtboardSync_v1';

/* ══════════════════════════════════════
   DOM references
   ══════════════════════════════════════ */
var $filePath    = document.getElementById('file-path-text');
var $fileBox     = document.getElementById('file-path-display');
var $browseBtn   = document.getElementById('browse-btn');
var $fileInput   = document.getElementById('file-input');
var $sheetInput  = document.getElementById('sheet-name-input');
var $liveToggle  = document.getElementById('live-toggle');
var $liveBadge   = document.getElementById('live-badge');
var $syncBtn     = document.getElementById('sync-btn');
var $statusDot   = document.getElementById('status-dot');
var $statBoards  = document.getElementById('stat-boards');
var $statRows    = document.getElementById('stat-rows');
var $statTime    = document.getElementById('stat-time');
var $tbody       = document.getElementById('preview-tbody');
var $logBox      = document.getElementById('log-box');
var $refreshPrev = document.getElementById('refresh-preview-btn');
var $clearLog    = document.getElementById('clear-log-btn');

/* ══════════════════════════════════════
   Logging
   ══════════════════════════════════════ */
function log(msg, type) {
    type = type || 'info';
    var entry = document.createElement('div');
    entry.className = 'log-entry ' + type;

    var now = new Date();
    var ts  = pad(now.getHours()) + ':' + pad(now.getMinutes()) + ':' + pad(now.getSeconds());
    entry.textContent = '[' + ts + '] ' + msg;

    $logBox.appendChild(entry);
    $logBox.scrollTop = $logBox.scrollHeight;

    // Keep log to last 80 entries
    var entries = $logBox.querySelectorAll('.log-entry');
    if (entries.length > 80) {
        $logBox.removeChild(entries[0]);
    }
}

function pad(n) { return n < 10 ? '0' + n : String(n); }

/* ══════════════════════════════════════
   Status Dot
   ══════════════════════════════════════ */
function setStatus(status) {
    $statusDot.className = 'status-dot ' + status;
    var titles = { idle: 'Idle', live: 'Live — watching file', syncing: 'Syncing…', error: 'Error', success: 'Sync successful' };
    $statusDot.title = titles[status] || status;
}

/* ══════════════════════════════════════
   File Path Display
   ══════════════════════════════════════ */
function updateFileDisplay(filePath) {
    if (!filePath) {
        $filePath.textContent = 'No file selected';
        $filePath.className = '';
        $fileBox.title = '';
        return;
    }
    var name = filePath.replace(/\\/g, '/').split('/').pop();
    $filePath.textContent = name;
    $filePath.className = 'has-file';
    $fileBox.title = filePath;
}

/* ══════════════════════════════════════
   Persist / Load Settings
   ══════════════════════════════════════ */
function saveSettings() {
    try {
        var data = {
            filePath:  state.filePath,
            sheetName: state.sheetName,
            isLive:    state.isLive
        };
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (e) { /* ignore */ }
}

function loadSettings() {
    try {
        var raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return;
        var data = JSON.parse(raw);
        if (data.filePath)  { state.filePath  = data.filePath;  updateFileDisplay(data.filePath); }
        if (data.sheetName) { state.sheetName = data.sheetName; $sheetInput.value = data.sheetName; }
        if (data.isLive) {
            // Restore live mode after load
            state.isLive = false; // will be toggled by setLiveMode
            $liveToggle.checked = false;
        }
    } catch (e) { /* ignore */ }
}

/* ══════════════════════════════════════
   Excel Reading (SheetJS)
   ══════════════════════════════════════ */
function readExcel(filePath, sheetName) {
    if (!filePath) return null;
    if (!nodeFs)   return null;

    try {
        if (!nodeFs.existsSync(filePath)) {
            log('File not found: ' + filePath, 'error');
            return null;
        }

        if (!XLSX || typeof XLSX.read !== 'function') {
            if (window.XLSX && typeof window.XLSX.read === 'function') {
                XLSX = window.XLSX;
            } else {
                log('XLSX library (SheetJS) is not loaded or missing XLSX.read function.', 'error');
                return null;
            }
        }

        var buf = nodeFs.readFileSync(filePath);
        var workbook = XLSX.read(buf, { type: 'buffer', cellStyles: false, cellFormulas: false });

        // Find the sheet (exact name or first sheet)
        var sheet = workbook.Sheets[sheetName];
        if (!sheet) {
            // Try case-insensitive match
            var names = workbook.SheetNames;
            for (var i = 0; i < names.length; i++) {
                if (names[i].toLowerCase() === sheetName.toLowerCase()) {
                    sheet = workbook.Sheets[names[i]];
                    log('Using sheet: ' + names[i], 'info');
                    break;
                }
            }
        }

        if (!sheet) {
            var available = workbook.SheetNames.join(', ');
            log('Sheet "' + sheetName + '" not found. Available: ' + available, 'error');
            return null;
        }

        // Convert to JSON using raw rows
        var raw = XLSX.utils.sheet_to_json(sheet, { header: 1 });
        if (!raw || raw.length < 2) {
            log('Sheet has no data rows.', 'warning');
            return [];
        }

        // Find header row (contains ##name)
        var headerRowIdx = -1;
        for (var r = 0; r < Math.min(raw.length, 5); r++) {
            var row = raw[r];
            for (var c = 0; c < row.length; c++) {
                if (row[c] && String(row[c]).toLowerCase().indexOf('##name') !== -1) {
                    headerRowIdx = r;
                    break;
                }
            }
            if (headerRowIdx !== -1) break;
        }

        if (headerRowIdx === -1) {
            log('Header row with ##name not found.', 'error');
            return null;
        }

        var headers = raw[headerRowIdx];
        var colMap  = {}; // columnKey → index

        // Map header keys (lowercase, stripped of ##)
        for (var h = 0; h < headers.length; h++) {
            if (headers[h] !== null && headers[h] !== undefined) {
                var key = String(headers[h]).replace(/##/g, '').trim().toLowerCase();
                colMap[key] = h;
            }
        }

        // Validate required columns
        var required = ['name', 'x', 'y', 'w', 'h'];
        for (var ri = 0; ri < required.length; ri++) {
            if (colMap[required[ri]] === undefined) {
                log('Missing column: ##' + required[ri], 'error');
                return null;
            }
        }

        // Parse data rows
        var artboards = [];
        for (var dr = headerRowIdx + 1; dr < raw.length; dr++) {
            var dataRow = raw[dr];
            if (!dataRow || dataRow.length === 0) continue;

            var name = dataRow[colMap['name']];
            if (name === null || name === undefined || String(name).trim() === '') continue;

            var ab = {
                index: dataRow[colMap['index']] !== undefined ? dataRow[colMap['index']] : dr,
                name:  String(name).trim(),
                x:     parseFloat(dataRow[colMap['x']])  || 0,
                y:     parseFloat(dataRow[colMap['y']])  || 0,
                w:     parseFloat(dataRow[colMap['w']])  || 100,
                h:     parseFloat(dataRow[colMap['h']])  || 100
            };
            artboards.push(ab);
        }

        return artboards;

    } catch (e) {
        log('Error reading file: ' + e.message, 'error');
        return null;
    }
}

/* ══════════════════════════════════════
   Preview Table
   ══════════════════════════════════════ */
function updatePreview(artboards) {
    if (!artboards || artboards.length === 0) {
        $tbody.innerHTML = '<tr><td colspan="6" class="empty-cell">No data loaded</td></tr>';
        $statRows.textContent = '0';
        return;
    }

    var html = '';
    for (var i = 0; i < artboards.length; i++) {
        var ab = artboards[i];
        html += '<tr>' +
            '<td>' + (i + 1) + '</td>' +
            '<td>' + escapeHtml(ab.name) + '</td>' +
            '<td>' + ab.x + '</td>' +
            '<td>' + ab.y + '</td>' +
            '<td>' + ab.w + '</td>' +
            '<td>' + ab.h + '</td>' +
            '</tr>';
    }
    $tbody.innerHTML = html;
    $statRows.textContent = String(artboards.length);
}

function escapeHtml(str) {
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

/* ══════════════════════════════════════
   Artboard Count from Illustrator
   ══════════════════════════════════════ */
function refreshArtboardCount() {
    csInterface.evalScript('getArtboardCount()', function(result) {
        if (result && result !== 'EvalScript error.') {
            $statBoards.textContent = result;
        }
    });
}

/* ══════════════════════════════════════
   Core Sync
   ══════════════════════════════════════ */
function doSync() {
    if (!state.filePath) {
        log('No file selected.', 'warning');
        return;
    }

    $syncBtn.classList.add('spinning');
    $syncBtn.disabled = true;
    setStatus('syncing');

    var artboards = readExcel(state.filePath, state.sheetName);

    if (!artboards) {
        $syncBtn.classList.remove('spinning');
        $syncBtn.disabled = false;
        setStatus('error');
        return;
    }

    state.lastData = artboards;
    updatePreview(artboards);

    if (artboards.length === 0) {
        log('No artboard rows found in sheet.', 'warning');
        $syncBtn.classList.remove('spinning');
        $syncBtn.disabled = false;
        setStatus('idle');
        return;
    }

    var jsonStr = JSON.stringify(artboards);
    // Escape single quotes for evalScript wrapping
    var escaped = jsonStr.replace(/\\/g, '\\\\').replace(/'/g, "\\'");

    csInterface.evalScript("syncArtboards('" + escaped + "')", function(result) {
        $syncBtn.classList.remove('spinning');
        $syncBtn.disabled = false;

        try {
            var res = JSON.parse(result);
            if (res.success) {
                var msg = 'Synced ' + res.synced + ' artboard(s)';
                if (res.created)  msg += ' | +' + res.created + ' new';
                if (res.updated)  msg += ' | ~' + res.updated + ' updated';
                if (res.deleted)  msg += ' | -' + res.deleted + ' removed';
                log(msg, 'success');
                setStatus('success');
                setTimeout(function() {
                    setStatus(state.isLive ? 'live' : 'idle');
                }, 2000);
            } else {
                log('Sync failed: ' + (res.error || 'Unknown error'), 'error');
                setStatus('error');
            }
        } catch (e) {
            if (result && result.indexOf('EvalScript error') !== -1) {
                log('Illustrator script error. Is a document open?', 'error');
            } else {
                log('Unexpected response: ' + result, 'error');
            }
            setStatus('error');
        }

        // Update stats
        var now = new Date();
        $statTime.textContent = pad(now.getHours()) + ':' + pad(now.getMinutes());
        refreshArtboardCount();
    });
}

/* ══════════════════════════════════════
   Live Mode / File Watching
   ══════════════════════════════════════ */
function startWatching() {
    if (!nodeFs || !state.filePath) return;
    stopWatching();

    try {
        state.watcher = nodeFs.watch(state.filePath, { persistent: false }, function(event) {
            if (event === 'change') {
                // Debounce rapid saves
                if (state.syncTimer) clearTimeout(state.syncTimer);
                state.syncTimer = setTimeout(function() {
                    log('File changed — auto-syncing…', 'info');
                    doSync();
                }, state.syncDebounce);
            }
        });
        state.isWatching = true;
        log('Watching: ' + state.filePath.replace(/\\/g, '/').split('/').pop(), 'success');
    } catch (e) {
        log('Cannot watch file: ' + e.message, 'error');
    }
}

function stopWatching() {
    if (state.watcher) {
        try { state.watcher.close(); } catch (e) {}
        state.watcher = null;
    }
    if (state.syncTimer) {
        clearTimeout(state.syncTimer);
        state.syncTimer = null;
    }
    state.isWatching = false;
}

function setLiveMode(enabled) {
    state.isLive = enabled;
    $liveToggle.checked = enabled;

    if (enabled) {
        $liveBadge.classList.remove('hidden');
        setStatus('live');
        startWatching();
        log('Live Mode ON', 'success');
    } else {
        $liveBadge.classList.add('hidden');
        setStatus('idle');
        stopWatching();
        log('Live Mode OFF', 'info');
    }
    saveSettings();
}

/* ══════════════════════════════════════
   File Picking
   ══════════════════════════════════════ */
function setFilePath(fp) {
    state.filePath = fp;
    updateFileDisplay(fp);
    saveSettings();

    if (fp) {
        // Load preview
        var data = readExcel(fp, state.sheetName);
        if (data) {
            state.lastData = data;
            updatePreview(data);
            log('Loaded ' + data.length + ' row(s) from: ' + fp.split(/[\\/]/).pop(), 'success');
        }

        // Re-attach watcher if live
        if (state.isLive) {
            startWatching();
        }
    }
}

/* ══════════════════════════════════════
   Event Listeners
   ══════════════════════════════════════ */

// Sync button
$syncBtn.addEventListener('click', function() {
    doSync();
});

// Browse button – use CEP openFileDialog and return native path (fsName)
$browseBtn.addEventListener('click', function() {
    csInterface.evalScript(
        '(function(){ var f = File.openDialog("Select Excel file", "*.xlsx;*.xls", false); return f ? f.fsName : "null"; })()',
        function(result) {
            if (result && result !== 'null' && result !== 'EvalScript error.') {
                setFilePath(result);
            }
        }
    );
});

// Also allow clicking the path box
$fileBox.addEventListener('click', function() {
    $browseBtn.click();
});

// Live mode toggle
$liveToggle.addEventListener('change', function() {
    setLiveMode(this.checked);
});

// Sheet name change
$sheetInput.addEventListener('change', function() {
    state.sheetName = this.value.trim() || 'ArtBoards';
    saveSettings();
    // Reload preview
    if (state.filePath) {
        var data = readExcel(state.filePath, state.sheetName);
        if (data) { state.lastData = data; updatePreview(data); }
    }
});

// Refresh preview
$refreshPrev.addEventListener('click', function() {
    if (!state.filePath) { log('No file selected.', 'warning'); return; }
    var data = readExcel(state.filePath, state.sheetName);
    if (data) { state.lastData = data; updatePreview(data); log('Preview refreshed.', 'info'); }
});

// Clear log
$clearLog.addEventListener('click', function() {
    $logBox.innerHTML = '';
    log('Log cleared.', 'info');
});

// Theme synchronization with Illustrator
csInterface.addEventListener('com.adobe.csxs.events.ThemeColorChanged', function(e) {
    // Optionally sync to Illustrator's theme — panel uses its own dark theme
});

/* ══════════════════════════════════════
   Init
   ══════════════════════════════════════ */
(function init() {
    log('Excel Artboard Sync panel loaded.', 'info');

    // Default file path from the project
    var defaultPath = 'E:\\IMP\\MyApps\\My illustrator Scripts and Stuff\\Excel-illustrator-addon\\Test Excel File\\TestExcel-14050422-1-1.xlsx';
    if (nodeFs && nodeFs.existsSync(defaultPath)) {
        setFilePath(defaultPath);
        log('Default file detected and loaded.', 'success');
    } else {
        // Try to restore saved settings
        loadSettings();
        if (state.filePath) {
            log('Restored file: ' + state.filePath.split(/[\\/]/).pop(), 'info');
        }
    }

    // Update artboard count
    refreshArtboardCount();
    setStatus('idle');
})();
