/**
 * artboard.jsx  –  ExtendScript for Adobe Illustrator
 * Manages artboard creation and update from JSON data passed by CEP panel
 *
 * Coordinate convention (matching the panel's Excel format):
 *   X, Y = top-left corner of artboard in pixels (screen coords, Y=0 at top)
 *   W, H = width and height in pixels
 *
 * Illustrator internal rect = [left, top, right, bottom] in points
 *   where top > bottom (Y axis points UP in Illustrator)
 *   Ruler origin: top-left of first artboard = (0, 0)
 *   Down from origin → negative Y
 *
 * Conversion: 1 pixel = 1 point (1:1) for 72dpi documents.
 * The panel will let users choose px / pt.
 */

/* ─── JSON polyfill for ExtendScript ─── */
if (typeof JSON === 'undefined') {
    JSON = {};
}
if (typeof JSON.parse !== 'function') {
    JSON.parse = function (str) {
        return eval('(' + str + ')');
    };
}
if (typeof JSON.stringify !== 'function') {
    JSON.stringify = function (obj) {
        var t = typeof obj;
        if (t === 'undefined') return undefined;
        if (t === 'number' || t === 'boolean') return String(obj);
        if (t === 'string') return '"' + obj.replace(/\\/g,'\\\\').replace(/"/g,'\\"') + '"';
        if (obj === null) return 'null';
        if (obj instanceof Array) {
            var items = [];
            for (var i = 0; i < obj.length; i++) {
                items.push(JSON.stringify(obj[i]));
            }
            return '[' + items.join(',') + ']';
        }
        var pairs = [];
        for (var k in obj) {
            if (obj.hasOwnProperty(k)) {
                pairs.push('"' + k + '":' + JSON.stringify(obj[k]));
            }
        }
        return '{' + pairs.join(',') + '}';
    };
}

/* ─── Helpers ─── */

/**
 * Convert pixel value to Illustrator points.
 * By default 1px = 1pt (correct for 72dpi).
 * Adjust multiplier if needed.
 */
function pxToPt(px) {
    return parseFloat(px) * 1.0;
}

/**
 * Build an Illustrator Rect [left, top, right, bottom] from
 * user-supplied screen-coordinate values.
 * Y is inverted: screen Y=0 top → Illustrator Y=0 top, positive going down
 * becomes negative in Illustrator's math axis.
 */
function buildRect(x, y, w, h) {
    var left   =  pxToPt(x);
    var top    = -pxToPt(y);
    var right  =  pxToPt(x) + pxToPt(w);
    var bottom = -pxToPt(y) - pxToPt(h);
    return [left, top, right, bottom];
}

/**
 * Find an artboard by name. Returns index (0-based) or -1.
 */
function findArtboardByName(doc, name) {
    for (var i = 0; i < doc.artboards.length; i++) {
        if (doc.artboards[i].name === name) {
            return i;
        }
    }
    return -1;
}

/**
 * Collect all current artboard names into a plain object (name → index).
 */
function getArtboardMap(doc) {
    var map = {};
    for (var i = 0; i < doc.artboards.length; i++) {
        map[doc.artboards[i].name] = i;
    }
    return map;
}

/* ─── Main sync function (called from JS via evalScript) ─── */

/**
 * syncArtboards(jsonString)
 * 
 * Accepts a JSON string array of artboard definitions:
 * [{ index, name, x, y, w, h }, ...]
 * 
 * Strategy (update by name):
 *  - For each row in Excel:
 *      • If artboard with that name exists → update its rect
 *      • If not → create a new artboard
 *  - After processing all rows, delete any artboards whose names
 *    are NOT in the Excel list (they were removed).
 *    Exception: always keep at least one artboard (Illustrator requirement).
 * 
 * Returns a JSON result string: { success, synced, created, updated, deleted, error }
 */
function syncArtboards(jsonString) {
    var result = {
        success: false,
        synced: 0,
        created: 0,
        updated: 0,
        deleted: 0,
        error: ''
    };

    try {
        if (!app.documents.length) {
            result.error = 'No document open in Illustrator.';
            return JSON.stringify(result);
        }

        var doc = app.activeDocument;
        var rows;
        try {
            rows = JSON.parse(jsonString);
        } catch (e) {
            result.error = 'Failed to parse data: ' + e.message;
            return JSON.stringify(result);
        }

        if (!rows || !rows.length) {
            result.error = 'No artboard data received.';
            return JSON.stringify(result);
        }

        /* Build set of incoming names */
        var incomingNames = {};
        for (var i = 0; i < rows.length; i++) {
            incomingNames[rows[i].name] = true;
        }

        /* ── Pass 1: Update existing / create new ── */
        for (var i = 0; i < rows.length; i++) {
            var row  = rows[i];
            var rect = buildRect(row.x, row.y, row.w, row.h);
            var idx  = findArtboardByName(doc, row.name);

            if (idx !== -1) {
                /* Update existing artboard */
                doc.artboards[idx].artboardRect = rect;
                result.updated++;
            } else {
                /* Create new artboard */
                var newAB = doc.artboards.add(rect);
                newAB.name = row.name;
                result.created++;
            }
            result.synced++;
        }

        /* ── Pass 2: Delete artboards not in Excel list ── */
        /* Collect removals first to avoid index shifting */
        var toDelete = [];
        for (var j = doc.artboards.length - 1; j >= 0; j--) {
            var abName = doc.artboards[j].name;
            if (!incomingNames[abName]) {
                toDelete.push(j);
            }
        }

        /* Keep at least one artboard */
        if (toDelete.length >= doc.artboards.length) {
            toDelete.pop();
        }

        for (var k = 0; k < toDelete.length; k++) {
            doc.artboards.remove(toDelete[k]);
            result.deleted++;
        }

        result.success = true;

    } catch (e) {
        result.error = e.message || String(e);
    }

    return JSON.stringify(result);
}

/**
 * getArtboardCount()
 * Returns the number of artboards in the active document.
 */
function getArtboardCount() {
    try {
        if (!app.documents.length) return '0';
        return String(app.activeDocument.artboards.length);
    } catch (e) {
        return '0';
    }
}

/**
 * checkDocument()
 * Returns 'ok' if a document is open, 'none' otherwise.
 */
function checkDocument() {
    try {
        return app.documents.length > 0 ? 'ok' : 'none';
    } catch (e) {
        return 'error';
    }
}
