@echo off
setlocal enabledelayedexpansion
title Excel Artboard Sync - Auto-Installer for Adobe Illustrator

echo =======================================================================
echo     EXCEL ARTBOARD SYNC - ADOBE ILLUSTRATOR AUTO-INSTALLER
echo     (CEP Panel ^| Illustrator 2020 to 2026 Compatible)
echo =======================================================================
echo.

:: ── Admin check ─────────────────────────────────────────────────────────────
openfiles >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] NOTE: Running without full Administrator privileges.
    echo     Registry and file copy will still work for the current user.
    echo     If the panel doesn't appear in Illustrator, try right-clicking
    echo     this file and choosing "Run as administrator".
    echo.
) else (
    echo [*] Administrator privileges confirmed.
    echo.
)

:: ── Paths ────────────────────────────────────────────────────────────────────
set "SOURCE_FOLDER=%~dp0ExcelArtboardSync"
set "CEP_DIR=%APPDATA%\Adobe\CEP\extensions"
set "DEST_DIR=%CEP_DIR%\ExcelArtboardSync"
set "XLSX_JS=%~dp0ExcelArtboardSync\js\xlsx.full.min.js"
set "XLSX_URL=https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js"

:: ── Step 1: SheetJS ──────────────────────────────────────────────────────────
echo [*] Step 1: Checking for SheetJS (xlsx.full.min.js) ...

if exist "%XLSX_JS%" (
    echo     [+] SheetJS already present. Skipping download.
) else (
    echo     [*] Downloading SheetJS from CDN...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '%XLSX_URL%' -OutFile '%XLSX_JS%' -UseBasicParsing; Write-Host '    [+] Download OK' } catch { Write-Host '    [!] Download FAILED:' $_.Exception.Message }"
    if exist "%XLSX_JS%" (
        echo     [+] SheetJS downloaded successfully.
    ) else (
        echo     [!] FAILED to download SheetJS automatically.
        echo         Please download it manually from:
        echo         %XLSX_URL%
        echo         Save it to: %~dp0ExcelArtboardSync\js\xlsx.full.min.js
        echo.
    )
)

:: ── Step 2: Copy CEP Panel ───────────────────────────────────────────────────
echo.
echo [*] Step 2: Installing CEP Extension Panel ...

if not exist "%SOURCE_FOLDER%" (
    echo     [!] ERROR: Source folder not found:
    echo         %SOURCE_FOLDER%
    echo         Make sure this .bat file sits next to the ExcelArtboardSync folder.
    echo.
    pause
    exit /b 1
)

if not exist "%CEP_DIR%" (
    mkdir "%CEP_DIR%" >nul 2>&1
    echo     [+] Created CEP extensions directory.
)

if exist "%DEST_DIR%" (
    echo     [*] Removing previous installation...
    rmdir /s /q "%DEST_DIR%" >nul 2>&1
)

echo     [*] Copying panel files to:
echo         %DEST_DIR%
xcopy /s /e /y /i "%SOURCE_FOLDER%" "%DEST_DIR%" >nul 2>&1

if %errorlevel% equ 0 (
    echo     [+] Panel files installed successfully.
    set "PANEL_INSTALLED=1"
) else (
    echo     [FAILED] Could not copy files. Check folder permissions.
    set "PANEL_INSTALLED=0"
)

:: ── Step 3: Registry ─────────────────────────────────────────────────────────
echo.
echo [*] Step 3: Enabling Adobe CEP Debug Mode in registry ...
echo     (Allows unsigned local extensions to load)

reg add "HKCU\Software\Adobe\CSXS.7"  /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.8"  /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.9"  /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.13" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.14" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1

echo     [+] PlayerDebugMode enabled for CSXS.7 through CSXS.14!

:: ── Step 4: Verify ───────────────────────────────────────────────────────────
echo.
echo [*] Step 4: Verifying installation ...
echo.

set "ALL_OK=1"

call :check "CSXS\manifest.xml"
call :check "index.html"
call :check "css\style.css"
call :check "js\main.js"
call :check "js\CSInterface.js"
call :check "js\xlsx.full.min.js"
call :check "jsx\artboard.jsx"

:: ── Done ─────────────────────────────────────────────────────────────────────
echo.
echo =======================================================================
echo                      INSTALLATION PROCESS COMPLETE!
echo =======================================================================
echo.

if "%PANEL_INSTALLED%"=="1" (
    echo    DOCKABLE PANEL INSTALLED SUCCESSFULLY:
    echo.
    echo       1. Close Adobe Illustrator completely ^(if it is open^).
    echo       2. Re-launch Adobe Illustrator.
    echo       3. Go to:  Window -^> Extensions -^> Excel Artboard Sync
    echo       4. The panel loads your Excel file automatically!
    echo.
    echo    HOW TO USE:
    echo       - Click "Sync Now" to push artboards from Excel to Illustrator.
    echo       - Toggle "Live Mode" to auto-sync every time you save the Excel file.
    echo.
)

if "!ALL_OK!"=="0" (
    echo    [!] WARNING: Some files are missing ^(see above^).
    echo        Re-run the installer or check the ExcelArtboardSync source folder.
    echo.
)

echo    Installed to:
echo    %DEST_DIR%
echo.
echo =======================================================================
echo.
pause
exit /b 0

:: ── Helper: check file ───────────────────────────────────────────────────────
:check
set "_f=%DEST_DIR%\%~1"
if exist "%_f%" (
    echo     [+] %~1
) else (
    echo     [!] MISSING: %~1
    set "ALL_OK=0"
)
exit /b
