import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Layers,
  Grid,
  Save,
  Trash2,
  Sliders,
  Settings,
  HelpCircle,
  Sparkles,
  RotateCcw,
  Maximize2,
  Copy,
  Check,
  Download,
  AlignLeft,
  AlignCenter,
  AlignRight,
  MousePointer,
  Hand,
  Crop,
  Shapes,
  Scale,
  RefreshCw,
  Play,
  Square,
  Circle,
  HelpCircle as InfoIcon,
  ChevronRight,
  Code,
  FileCode,
  Sparkle,
  Grid3X3,
  ExternalLink,
  Lock,
  Unlock,
  CheckCircle,
  FolderOpen
} from 'lucide-react';

// Interfaces for our interactive items
interface ArtItem {
  id: string;
  name: string;
  type: 'star' | 'landscape' | 'flower' | 'crest' | 'badge' | 'tech' | 'custom_shape';
  x: number; // Left coordinate on artboard
  y: number; // Top coordinate on artboard
  w: number; // Current simulated width
  h: number; // Current simulated height
  initialW: number; // Original width to calculate aspect ratio
  initialH: number; // Original height to calculate aspect ratio
  color: string; // Theme hue color
  secondaryColor: string;
  selected: boolean;
  rotation: number; // Rotation in degrees
}

// Initial set of mock items to populate the Artboard
const INITIAL_ITEMS: ArtItem[] = [
  {
    id: 'item-1',
    name: 'Red Starburst Logo',
    type: 'star',
    x: 40,
    y: 80,
    w: 110,
    h: 110,
    initialW: 110,
    initialH: 110,
    color: '#EF4444',
    secondaryColor: '#991B1B',
    selected: true,
    rotation: 12
  },
  {
    id: 'item-2',
    name: 'Emerald Hexagonal Seal',
    type: 'tech',
    x: 180,
    y: 50,
    w: 160,
    h: 100,
    initialW: 160,
    initialH: 100,
    color: '#10B981',
    secondaryColor: '#065F46',
    selected: true,
    rotation: -5
  },
  {
    id: 'item-3',
    name: 'Sunset Coast Landscape',
    type: 'landscape',
    x: 405,
    y: 65,
    w: 150,
    h: 90,
    initialW: 150,
    initialH: 90,
    color: '#F97316',
    secondaryColor: '#9A3412',
    selected: true,
    rotation: 0
  },
  {
    id: 'item-4',
    name: 'Amethyst Royal Crest',
    type: 'crest',
    x: 50,
    y: 250,
    w: 95,
    h: 135,
    initialW: 95,
    initialH: 135,
    color: '#8B5CF6',
    secondaryColor: '#5B21B6',
    selected: true,
    rotation: 8
  },
  {
    id: 'item-5',
    name: 'Sunny Golden Badge',
    type: 'badge',
    x: 195,
    y: 190,
    w: 90,
    h: 90,
    initialW: 90,
    initialH: 90,
    color: '#FBBF24',
    secondaryColor: '#92400E',
    selected: true,
    rotation: -15
  },
  {
    id: 'item-6',
    name: 'Lavender Orchid Vector',
    type: 'flower',
    x: 320,
    y: 215,
    w: 105,
    h: 140,
    initialW: 105,
    initialH: 140,
    color: '#C084FC',
    secondaryColor: '#6B21A8',
    selected: false,
    rotation: 6
  },
  {
    id: 'item-7',
    name: 'Oceanic Wave Banner',
    type: 'custom_shape',
    x: 450,
    y: 260,
    w: 130,
    h: 70,
    initialW: 130,
    initialH: 70,
    color: '#0EA5E9',
    secondaryColor: '#075985',
    selected: false,
    rotation: 0
  }
];

export interface AppSettings {
  gridMode: 'cols' | 'rows' | 'square' | 'optimal_vertical' | 'optimal_horizontal' | 'fixed_gap_h' | 'fixed_gap_v';
  gridModeVal: number;
  constrainManual: boolean;
  spacing: number;
  scale: number;
  flowDirection: 'horizontal' | 'vertical';
  aspectRatioMode: 'fit' | 'width' | 'height' | 'stretch' | 'optimal_vertical' | 'optimal_horizontal';
  lockRatio: boolean;
  hAlign: 'left' | 'center' | 'right';
  vAlign: 'top' | 'middle' | 'bottom';
  sizingStrategy: 'average' | 'manual';
  manualW: number;
  manualH: number;
  minWEnabled: boolean;
  minWVal: number;
  maxWEnabled: boolean;
  maxWVal: number;
  minHEnabled: boolean;
  minHVal: number;
  maxHEnabled: boolean;
  maxHVal: number;
}

export interface SavedPreset {
  name: string;
  settings: AppSettings;
}

export const DEFAULT_PRESETS: SavedPreset[] = [
  {
    name: "Default 4-Column Grid",
    settings: {
      gridMode: 'cols',
      gridModeVal: 4,
      constrainManual: false,
      spacing: 14,
      scale: 100,
      flowDirection: 'horizontal',
      aspectRatioMode: 'fit',
      lockRatio: true,
      hAlign: 'center',
      vAlign: 'middle',
      sizingStrategy: 'average',
      manualW: 120,
      manualH: 120,
      minWEnabled: false,
      minWVal: 60,
      maxWEnabled: false,
      maxWVal: 300,
      minHEnabled: false,
      minHVal: 60,
      maxHEnabled: false,
      maxHVal: 300
    }
  },
  {
    name: "3-Col Pinterest Waterfall",
    settings: {
      gridMode: 'optimal_vertical',
      gridModeVal: 3,
      constrainManual: false,
      spacing: 14,
      scale: 100,
      flowDirection: 'horizontal',
      aspectRatioMode: 'width',
      lockRatio: true,
      hAlign: 'center',
      vAlign: 'middle',
      sizingStrategy: 'average',
      manualW: 120,
      manualH: 120,
      minWEnabled: false,
      minWVal: 60,
      maxWEnabled: false,
      maxWVal: 300,
      minHEnabled: false,
      minHVal: 60,
      maxHEnabled: false,
      maxHVal: 300
    }
  },
  {
    name: "Dynamic Banner Row",
    settings: {
      gridMode: 'fixed_gap_h',
      gridModeVal: 1,
      constrainManual: false,
      spacing: 18,
      scale: 100,
      flowDirection: 'horizontal',
      aspectRatioMode: 'fit',
      lockRatio: true,
      hAlign: 'center',
      vAlign: 'middle',
      sizingStrategy: 'average',
      manualW: 120,
      manualH: 120,
      minWEnabled: false,
      minWVal: 60,
      maxWEnabled: false,
      maxWVal: 300,
      minHEnabled: false,
      minHVal: 60,
      maxHEnabled: false,
      maxHVal: 300
    }
  },
  {
    name: "Dense Compact Grid",
    settings: {
      gridMode: 'cols',
      gridModeVal: 6,
      constrainManual: false,
      spacing: 8,
      scale: 70,
      flowDirection: 'horizontal',
      aspectRatioMode: 'fit',
      lockRatio: true,
      hAlign: 'center',
      vAlign: 'middle',
      sizingStrategy: 'average',
      manualW: 80,
      manualH: 80,
      minWEnabled: false,
      minWVal: 40,
      maxWEnabled: false,
      maxWVal: 200,
      minHEnabled: false,
      minHVal: 40,
      maxHEnabled: false,
      maxHVal: 200
    }
  }
];

export default function App() {
  // Artboard Items State
  const [items, setItems] = useState<ArtItem[]>(INITIAL_ITEMS);
  
  // Plugin UI States
  const [gridMode, setGridMode] = useState<'cols' | 'rows' | 'square' | 'optimal_vertical' | 'optimal_horizontal' | 'fixed_gap_h' | 'fixed_gap_v'>('cols');
  const [gridModeVal, setGridModeVal] = useState<number>(4);
  const [constrainManual, setConstrainManual] = useState<boolean>(false);
  const lastRatioRef = useRef<number>(1.0);
  const selectionAnchorRef = useRef<{ x: number; y: number } | null>(null);
  const lastSelectedIdsRef = useRef<string>('');
  const [spacing, setSpacing] = useState<number>(14);
  const [scale, setScale] = useState<number>(100); // percentage sizing
  const [flowDirection, setFlowDirection] = useState<'horizontal' | 'vertical'>('horizontal');
  const [aspectRatioMode, setAspectRatioMode] = useState<'fit' | 'width' | 'height' | 'stretch' | 'optimal_vertical' | 'optimal_horizontal'>('fit');
  const [lockRatio, setLockRatio] = useState<boolean>(true);
  const [hAlign, setHAlign] = useState<'left' | 'center' | 'right'>('center');
  const [vAlign, setVAlign] = useState<'top' | 'middle' | 'bottom'>('middle');
  const [sizingStrategy, setSizingStrategy] = useState<'average' | 'manual'>('average');
  
  // Manual target bounding size if "sizingStrategy" === "manual"
  const [manualW, setManualW] = useState<number>(120);
  const [manualH, setManualH] = useState<number>(120);

  // Dimension limits state
  const [minWEnabled, setMinWEnabled] = useState<boolean>(false);
  const [minWVal, setMinWVal] = useState<number>(60);
  const [maxWEnabled, setMaxWEnabled] = useState<boolean>(false);
  const [maxWVal, setMaxWVal] = useState<number>(300);
  const [minHEnabled, setMinHEnabled] = useState<boolean>(false);
  const [minHVal, setMinHVal] = useState<number>(60);
  const [maxHEnabled, setMaxHEnabled] = useState<boolean>(false);
  const [maxHVal, setMaxHVal] = useState<number>(300);

  // Realtime live update state
  const [realtime, setRealtime] = useState<boolean>(true);

  // Load custom presets on mount
  const [presets, setPresets] = useState<SavedPreset[]>([]);
  const [newPresetName, setNewPresetName] = useState<string>('');
  const [activePresetIndex, setActivePresetIndex] = useState<number>(0);

  // Helper to apply preset settings object to states
  const applySettingsObject = (settings: Partial<AppSettings>) => {
    if (settings.gridMode !== undefined) setGridMode(settings.gridMode);
    if (settings.gridModeVal !== undefined) setGridModeVal(settings.gridModeVal);
    if (settings.constrainManual !== undefined) setConstrainManual(settings.constrainManual);
    if (settings.spacing !== undefined) setSpacing(settings.spacing);
    if (settings.scale !== undefined) setScale(settings.scale);
    if (settings.flowDirection !== undefined) setFlowDirection(settings.flowDirection);
    if (settings.aspectRatioMode !== undefined) setAspectRatioMode(settings.aspectRatioMode);
    if (settings.lockRatio !== undefined) setLockRatio(settings.lockRatio);
    if (settings.hAlign !== undefined) setHAlign(settings.hAlign);
    if (settings.vAlign !== undefined) setVAlign(settings.vAlign);
    if (settings.sizingStrategy !== undefined) setSizingStrategy(settings.sizingStrategy);
    if (settings.manualW !== undefined) setManualW(settings.manualW);
    if (settings.manualH !== undefined) setManualH(settings.manualH);
    if (settings.minWEnabled !== undefined) setMinWEnabled(settings.minWEnabled);
    if (settings.minWVal !== undefined) setMinWVal(settings.minWVal);
    if (settings.maxWEnabled !== undefined) setMaxWEnabled(settings.maxWEnabled);
    if (settings.maxWVal !== undefined) setMaxWVal(settings.maxWVal);
    if (settings.minHEnabled !== undefined) setMinHEnabled(settings.minHEnabled);
    if (settings.minHVal !== undefined) setMinHVal(settings.minHVal);
    if (settings.maxHEnabled !== undefined) setMaxHEnabled(settings.maxHEnabled);
    if (settings.maxHVal !== undefined) setMaxHVal(settings.maxHVal);
  };

  // Mount effect to restore last used details and presets
  useEffect(() => {
    try {
      // 1. Restore Custom Presets
      const savedPresets = localStorage.getItem('gridmaster_presets');
      if (savedPresets) {
        setPresets(JSON.parse(savedPresets));
      }

      // 2. Restore Last Used Settings
      const savedLast = localStorage.getItem('gridmaster_last_used_settings');
      if (savedLast) {
        const parsed = JSON.parse(savedLast);
        applySettingsObject(parsed);
      }
    } catch (e) {
      console.error('Failed to restore config on mount:', e);
    }
  }, []);

  // Save latest settings to localStorage whenever they change
  useEffect(() => {
    const currentSettings: AppSettings = {
      gridMode,
      gridModeVal,
      constrainManual,
      spacing,
      scale,
      flowDirection,
      aspectRatioMode,
      lockRatio,
      hAlign,
      vAlign,
      sizingStrategy,
      manualW,
      manualH,
      minWEnabled,
      minWVal,
      maxWEnabled,
      maxWVal,
      minHEnabled,
      minHVal,
      maxHEnabled,
      maxHVal,
    };
    try {
      localStorage.setItem('gridmaster_last_used_settings', JSON.stringify(currentSettings));
    } catch (e) {
      console.error('Failed to save last-used settings:', e);
    }
  }, [
    gridMode,
    gridModeVal,
    constrainManual,
    spacing,
    scale,
    flowDirection,
    aspectRatioMode,
    lockRatio,
    hAlign,
    vAlign,
    sizingStrategy,
    manualW,
    manualH,
    minWEnabled,
    minWVal,
    maxWEnabled,
    maxWVal,
    minHEnabled,
    minHVal,
    maxHEnabled,
    maxHVal
  ]);

  // Combined list of presets for the UI dropdown Selector
  const allPresets = useMemo(() => {
    return [...DEFAULT_PRESETS, ...presets];
  }, [presets]);

  // Scrubby adjustment tracking state
  const scrubStartRef = useRef<{ x: number; val: number } | null>(null);
  const activeScrubberRef = useRef<{
    label: string;
    setValue: (val: number) => void;
    min: number;
    max: number;
    step?: number;
    intOnly?: boolean;
  } | null>(null);

  // Reusable mouse-scrubbing handler
  const startScrub = (
    e: React.MouseEvent,
    label: string,
    currentVal: number,
    setValue: (val: number) => void,
    min: number,
    max: number,
    step: number = 1,
    intOnly: boolean = false
  ) => {
    e.preventDefault();
    scrubStartRef.current = { x: e.clientX, val: currentVal };
    activeScrubberRef.current = { label, setValue, min, max, step, intOnly };
    document.body.style.cursor = 'ew-resize';

    const handleMouseMove = (mouseEvent: MouseEvent) => {
      if (!scrubStartRef.current || !activeScrubberRef.current) return;
      
      const deltaX = mouseEvent.clientX - scrubStartRef.current.x;
      const { val } = scrubStartRef.current;
      const { setValue: setVal, min: minValue, max: maxValue, step: stepValue, intOnly: isInt } = activeScrubberRef.current;

      // Scrolling speed factor based on modifiers
      let speed = 0.5;
      if (mouseEvent.shiftKey) speed = 2.0;
      if (mouseEvent.ctrlKey) speed = 0.05;

      let deltaValue = deltaX * (stepValue || 1) * speed;
      if (isInt) {
        deltaValue = Math.round(deltaValue);
      }

      const calculated = val + deltaValue;
      const boundedValue = Math.max(minValue, Math.min(maxValue, calculated));
      const finalVal = isInt ? Math.round(boundedValue) : Math.round(boundedValue * 2) / 2;
      
      setVal(finalVal);
    };

    const handleMouseUp = () => {
      scrubStartRef.current = null;
      activeScrubberRef.current = null;
      document.body.style.cursor = '';
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  };

  // Reusable wheel scroll adjustment handler
  const handleWheelAdjust = (
    e: React.WheelEvent<HTMLDivElement>,
    value: number,
    setValue: (val: number) => void,
    options: { min: number; max: number; baseStep?: number; intOnly?: boolean }
  ) => {
    e.preventDefault();
    e.stopPropagation();

    const isUp = e.deltaY < 0;
    const baseStep = options.baseStep ?? 1;
    const intOnly = options.intOnly ?? false;

    let multiplier = 1;
    if (e.ctrlKey) {
      multiplier = 0.1;
    } else if (e.shiftKey) {
      multiplier = 5;
    }

    let delta = (isUp ? 1 : -1) * baseStep * multiplier;
    if (intOnly) {
      delta = isUp ? Math.ceil(delta) : Math.floor(delta);
      if (delta === 0) delta = isUp ? 1 : -1;
    }

    const calculatedNewVal = value + delta;
    const boundedVal = Math.max(options.min, Math.min(options.max, calculatedNewVal));
    const finalVal = intOnly ? Math.round(boundedVal) : Math.round(boundedVal * 10) / 10;
    setValue(finalVal);
  };

  // Selection hash to monitor selection updates cleanly without layout loops
  const selectionHash = useMemo(() => {
    return items.map(item => `${item.id}:${item.selected}`).join(',');
  }, [items]);

  // General States
  const [codeSection, setCodeSection] = useState<'code' | 'installer'>('code');
  const [scriptType, setScriptType] = useState<'jsx' | 'uxp'>('jsx');
  const [copied, setCopied] = useState<boolean>(false);
  const [showGuides, setShowGuides] = useState<boolean>(true);
  const [selectedTool, setSelectedTool] = useState<'select' | 'hand' | 'direct'>('select');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Dragging interaction state
  const [draggedId, setDraggedId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const artboardRef = useRef<HTMLDivElement>(null);

  // Trigger brief alert toast
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // 1. Download raw JSX Script File
  const downloadJSX = () => {
    const element = document.createElement("a");
    const file = new Blob([generatedScriptCode], {type: 'text/javascript;charset=utf-8'});
    element.href = URL.createObjectURL(file);
    element.download = "GridMasterPro.jsx";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    triggerToast("GridMasterPro.jsx downloaded successfully!");
  };

  // 2. Download Windows Auto-Installer Batch (.bat) File
  const downloadBAT = () => {
    const batTemplate = `@echo off
:: Title
title GridMaster Pro - Automated Installer for Adobe Illustrator
echo =======================================================================
echo              GridMaster Pro - Adobe Illustrator Installer             
echo =======================================================================
echo.

:: Check Admin Rights
openfiles >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] WARNING: This script does not have Administrator privileges.
    echo     Please right-click this .bat file and choose "Run as administrator"
    echo     to allow installation into the C:\\Program Files directory.
    echo.
    pause
    exit /b
)

echo [*] Administrator privileges detected. Proceeding...
echo.

:: Temporary file to hold the JSX script
set "TEMP_JSX=%TEMP%\\GridMasterPro_temp.jsx"

echo [*] Extracting plugin script...
powershell -Command "$lines = Get-Content '%~f0'; $start = [array]::IndexOf($lines, ':: ---- START_JSX ----') + 1; $jsx = $lines[$start..($lines.Length-1)] -join [Environment]::NewLine; [System.IO.File]::WriteAllText('%TEMP_JSX%', $jsx)"

:: Auto-locate Illustrator scripts path
set "FOUND_PATH="
for /d %%i in ("C:\\Program Files\\Adobe\\Adobe Illustrator *") do (
    if exist "%%i\\Presets" (
        for /d %%j in ("%%i\\Presets\\*") do (
            if exist "%%j\\Scripts" (
                set "FOUND_PATH=%%j\\Scripts"
                echo [+] Found Adobe Illustrator Scripts folder:
                echo     "%%j\\Scripts"
                copy /y "%TEMP_JSX%" "%%j\\Scripts\\GridMasterPro.jsx" >nul
                if %errorlevel% equ 0 (
                    echo [SUCCESS] GridMasterPro.jsx successfully installed for: "%%~nxi"
                ) else (
                    echo [FAILED] Failed to copy to: "%%j\\Scripts"
                )
            )
        )
    )
)

if "%FOUND_PATH%"=="" (
    echo.
    echo [!] Adobe Illustrator installation could not be automatically located.
    echo     Illustrator usually installs to: C:\\Program Files\\Adobe\\Adobe Illustrator [Year]
    echo.
    echo     We can attempt to let you paste your custom Scripts folder path!
    set /p "CUSTOM_DIR=Please paste the full path to your Illustrator Scripts directory: "
    if exist "%CUSTOM_DIR%" (
        copy /y "%TEMP_JSX%" "%CUSTOM_DIR%\\GridMasterPro.jsx" >nul
        if %errorlevel% equ 0 (
            echo [SUCCESS] GridMasterPro.jsx successfully copied to: "%CUSTOM_DIR%"
        ) else (
            echo [FAILED] Folder exists but copy failed. Check write permissions.
        )
    ) else (
        echo [!] Active directory does not exist. Manual installation recommended.
    )
)

del "%TEMP_JSX%" >nul 2>&1
echo.
echo =======================================================================
echo    Installation Process Complete!
echo    1. Restart Adobe Illustrator
echo    2. Select multiple elements on your artboard
echo    3. Go to: File -^> Scripts -^> GridMasterPro
echo =======================================================================
pause
exit /b

:: ---- START_JSX ----
` + generatedScriptCode;

    const element = document.createElement("a");
    const file = new Blob([batTemplate], {type: 'application/x-bat;charset=utf-8'});
    element.href = URL.createObjectURL(file);
    element.download = "install_gridmaster.bat";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    triggerToast("install_gridmaster.bat downloaded!");
  };

  // 3. Download Platform-Independent Python GUI Installer (.py) File
  const downloadPython = () => {
    const sanitizedJSX = generatedScriptCode
      .replace(/\\\\/g, '\\\\\\\\')
      .replace(/"""/g, '\\"\\"\\"');

    const pythonTemplate = `import os
import sys
import glob
import tkinter as tk
from tkinter import messagebox, filedialog

# GridMaster Pro Installer Script
# Generated automatically for dynamic installation

JSX_CONTENT = """${sanitizedJSX}"""

class GridMasterInstallerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("GridMaster Pro - Extension Auto-Installer")
        self.root.geometry("540x440")
        self.root.resizable(False, False)
        self.root.configure(bg="#1E1E1E")
        
        # Style Definitions
        self.accent_color = "#FF9A00"
        self.bg_dark = "#1E1E1E"
        self.bg_panel = "#2D2D2D"
        self.text_light = "#F3F4F6"
        self.text_dim = "#9CA3AF"
        
        self.setup_ui()
        self.scan_illustrator_installations()

    def setup_ui(self):
        # Header Logotype
        header = tk.Frame(self.root, bg=self.bg_panel, height=60, borderwidth=1, relief="flat")
        header.pack(fill="x", side="top")
        
        logo = tk.Label(header, text="Ai", bg=self.accent_color, fg="#121212", font=("Arial", 14, "bold"), width=3, height=1)
        logo.pack(side="left", padx=15, pady=10)
        
        title_lbl = tk.Label(header, text="GridMaster Pro Auto-Installer", bg=self.bg_panel, fg=self.text_light, font=("Arial", 12, "bold"))
        title_lbl.pack(side="left", pady=10)
        
        ver_lbl = tk.Label(header, text="V1.0.4", bg=self.bg_panel, fg=self.accent_color, font=("Arial", 9, "bold"))
        ver_lbl.pack(side="right", padx=15, pady=10)

        # Body Frame
        body = tk.Frame(self.root, bg=self.bg_dark)
        body.pack(fill="both", expand=True, padx=20, pady=20)

        # Subtitle instructions
        desc = tk.Label(body, text="Scans compatible Adobe Illustrator script folders on Windows and macOS.", bg=self.bg_dark, fg=self.text_dim, font=("Arial", 10), justify="left", anchor="w")
        desc.pack(fill="x", pady=(0, 10))

        # List Box of found installations
        tk.Label(body, text="Select Illustrator Scripts Region Location:", bg=self.bg_dark, fg=self.text_light, font=("Arial", 10, "bold"), anchor="w").pack(fill="x")
        
        self.listbox_frame = tk.Frame(body, bg="#151515", bd=1, relief="solid")
        self.listbox_frame.pack(fill="both", expand=True, pady=5)
        
        scrollbar = tk.Scrollbar(self.listbox_frame)
        scrollbar.pack(side="right", fill="y")
        
        self.path_listbox = tk.Listbox(self.listbox_frame, bg="#151515", fg="#FFF", selectbackground="#3B82F6", selectforeground="white", highlightthickness=0, font=("Courier New", 9), yscrollcommand=scrollbar.set)
        self.path_listbox.pack(fill="both", expand=True, side="left", padx=5, pady=5)
        scrollbar.config(command=self.path_listbox.yview)

        # Custom directory selector row
        custom_frame = tk.Frame(body, bg=self.bg_dark)
        custom_frame.pack(fill="x", pady=10)
        
        self.custom_path_var = tk.StringVar()
        self.path_entry = tk.Entry(custom_frame, textvariable=self.custom_path_var, bg="#2D2D2D", fg="white", bd=1, relief="solid", font=("Arial", 9))
        self.path_entry.pack(side="left", fill="x", expand=True, padx=(0, 10), ipady=3)
        
        browse_btn = tk.Button(custom_frame, text="Browse...", bg="#373737", fg="white", activebackground="#4B4B4B", activeforeground="white", bd=0, relief="flat", font=("Arial", 9, "bold"), command=self.browse_custom_folder, padx=10, pady=2)
        browse_btn.pack(side="right")

        # Action Buttons Row
        btn_frame = tk.Frame(body, bg=self.bg_dark)
        btn_frame.pack(fill="x", pady=(10, 0))

        self.install_btn = tk.Button(btn_frame, text="⚡ AUTO-INSTALL TO EXTENSIONS", bg="#2563EB", fg="white", activebackground="#3B82F6", activeforeground="white", bd=0, relief="flat", font=("Arial", 11, "bold"), command=self.run_installation, pady=8)
        self.install_btn.pack(fill="x")

    def scan_illustrator_installations(self):
        scripts_dirs = []
        
        if sys.platform == "win32":
            # Search Windows Programs Folder
            base_dir = r"C:\\\\Program Files\\\\Adobe"
            if os.path.exists(base_dir):
                for folder in os.listdir(base_dir):
                    if "Adobe Illustrator" in folder:
                        preset_pattern = os.path.join(base_dir, folder, "Presets", "*", "Scripts")
                        for matched_path in glob.glob(preset_pattern):
                            scripts_dirs.append(matched_path)
        elif sys.platform == "darwin":
            # Search macOS Applications Folder
            base_dir = "/Applications"
            if os.path.exists(base_dir):
                for folder in os.listdir(base_dir):
                    if "Adobe Illustrator" in folder:
                        loc_names = ["Presets", "Presets.localized"]
                        for loc in loc_names:
                            preset_pattern = os.path.join(base_dir, folder, loc, "*", "Scripts")
                            for matched_path in glob.glob(preset_pattern):
                                scripts_dirs.append(matched_path)

        for path in scripts_dirs:
            self.path_listbox.insert(tk.END, path)

        if scripts_dirs:
            self.path_listbox.select_set(0)
            self.custom_path_var.set(scripts_dirs[0])
            self.path_listbox.bind('<<ListboxSelect>>', self.on_listbox_select)
        else:
            self.path_listbox.insert(tk.END, "No directories found automatically. Please browse manually.")
            self.path_listbox.config(state="disabled")

    def on_listbox_select(self, event):
        if not self.path_listbox.curselection():
            return
        selected_index = self.path_listbox.curselection()[0]
        selected_path = self.path_listbox.get(selected_index)
        self.custom_path_var.set(selected_path)

    def browse_custom_folder(self):
        chosen_dir = filedialog.askdirectory(title="Locate Adobe/Illustrator Scripts Directory")
        if chosen_dir:
            self.custom_path_var.set(chosen_dir)
            self.path_listbox.config(state="normal")
            self.path_listbox.delete(0, tk.END)
            self.path_listbox.insert(tk.END, chosen_dir)
            self.path_listbox.select_set(0)

    def run_installation(self):
        target_dir = self.custom_path_var.get().strip()
        
        if not target_dir or not os.path.exists(target_dir):
            messagebox.showerror("Error", "The specified folder does not exist. Please check your path.")
            return

        target_file_path = os.path.join(target_dir, "GridMasterPro.jsx")
        
        try:
            with open(target_file_path, "w", encoding="utf-8") as f:
                f.write(JSX_CONTENT)
            
            messagebox.showinfo(
                "Success!", 
                f"GridMasterPro.jsx was successfully installed!\\n\\nPath:\\n{target_file_path}\\n\\nTo use:\\n1. Restart Adobe Illustrator\\n2. Select elements on artboard\\n3. Go to File -> Scripts -> GridMasterPro"
            )
        except Exception as e:
            messagebox.showerror("Installation Failed", f"Could not copy script file. This might require Administrator privileges.\\n\\nError Details:\\n{str(e)}")

if __name__ == "__main__":
    app_root = tk.Tk()
    app = GridMasterInstallerApp(app_root)
    app_root.mainloop()
`;

    const element = document.createElement("a");
    const file = new Blob([pythonTemplate], {type: 'text/x-python;charset=utf-8'});
    element.href = URL.createObjectURL(file);
    element.download = "install_gridmaster.py";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    triggerToast("install_gridmaster.py downloaded!");
  };

  // Selection statistics
  const selectedItems = useMemo(() => items.filter((item) => item.selected), [items]);
  const numSelected = selectedItems.length;

  const columns = useMemo(() => {
    if (gridMode === 'cols' || gridMode === 'optimal_vertical' || gridMode === 'fixed_gap_h') {
      return gridModeVal;
    } else if (gridMode === 'rows' || gridMode === 'optimal_horizontal' || gridMode === 'fixed_gap_v') {
      return Math.ceil(numSelected / gridModeVal) || 1;
    } else {
      return Math.ceil(Math.sqrt(numSelected)) || 1;
    }
  }, [gridMode, gridModeVal, numSelected]);

  const currentSelectedIds = useMemo(() => {
    return selectedItems.map(it => it.id).sort().join(',');
  }, [selectedItems]);

  useEffect(() => {
    if (currentSelectedIds !== lastSelectedIdsRef.current) {
      lastSelectedIdsRef.current = currentSelectedIds;
      selectionAnchorRef.current = null; // Reset top-left anchor on selection change to capture fresh bounds
    }
  }, [currentSelectedIds]);

  // Compute live averages of selected items
  const averages = useMemo(() => {
    if (numSelected === 0) {
      return { w: 0, h: 0 };
    }
    const totalW = selectedItems.reduce((acc, curr) => acc + curr.w, 0);
    const totalH = selectedItems.reduce((acc, curr) => acc + curr.h, 0);
    return {
      w: Math.round(totalW / numSelected),
      h: Math.round(totalH / numSelected)
    };
  }, [selectedItems, numSelected]);

  useEffect(() => {
    if (realtime) {
      applyGridLayout(true);
    }
  }, [realtime, columns, spacing, scale, flowDirection, aspectRatioMode, lockRatio, hAlign, vAlign, sizingStrategy, manualW, manualH, selectionHash, minWEnabled, minWVal, maxWEnabled, maxWVal, minHEnabled, minHVal, maxHEnabled, maxHVal]);

  // Handle dynamic script updating to copy
  const generatedScriptCode = useMemo(() => {
    const finalScaledW = Math.round((sizingStrategy === 'average' ? averages.w : manualW) * (scale / 100));
    const finalScaledH = Math.round((sizingStrategy === 'average' ? averages.h : manualH) * (scale / 100));

    if (scriptType === 'jsx') {
      return `/*
======================================================================================
GridMaster Pro - Adobe Illustrator Resizer & Layout Script
======================================================================================
Description:
A high-performance script to resize multiple chosen assets to their average
boundaries and arrange them into structured grids. Preserves strict aspect proportions!

Author: ExtendScript Core Automator
Version: 1.0.4
======================================================================================
*/

(function() {
    if (app.documents.length === 0) {
        alert("GridMaster Error:\\nNo active document found. Please open a document first.");
        return;
    }

    var doc = app.activeDocument;
    var selection = doc.selection;

    if (!selection || selection.length === 0) {
        alert("GridMaster Info:\\nPlease select two or more objects to resize and arrange into a grid.");
        return;
    }

    // 1. Core Selection Measurements
    var items = [];
    var totalW = 0;
    var totalH = 0;
    var minLeft = selection[0].left;
    var maxTop = selection[0].top;

    for (var i = 0; i < selection.length; i++) {
        var item = selection[i];
        items.push(item);
        totalW += item.width;
        totalH += item.height;
        if (item.left < minLeft) minLeft = item.left;
        if (item.top > maxTop) maxTop = item.top;
    }

    var count = items.length;
    var avgW = totalW / count;
    var avgH = totalH / count;

    // Configuration file management
    function parseKVs(kvStr) {
        var obj = {};
        if (!kvStr) return obj;
        var pairs = kvStr.split(",");
        for (var i = 0; i < pairs.length; i++) {
            var kv = pairs[i].split(":");
            if (kv.length < 2) continue;
            var k = kv[0];
            var v = kv[1];
            if (v === "true") obj[k] = true;
            else if (v === "false") obj[k] = false;
            else if (!isNaN(Number(v))) obj[k] = Number(v);
            else obj[k] = v;
        }
        return obj;
    }

    function serializeKVs(obj) {
        var parts = [];
        for (var k in obj) {
            if (obj.hasOwnProperty(k)) {
                parts.push(k + ":" + obj[k]);
            }
        }
        return parts.join(",");
    }

    function readConfigFile() {
        var presets = [
            { name: "Default 4-Column Grid", data: { gridMode: 0, gridModeVal: 4, spacing: 14, rbHoriz: true, rbAverage: true, txtW: 120, txtH: 120, chkConstrain: false, chkMinW: false, txtMinW: 60, chkMaxW: false, txtMaxW: 300, chkMinH: false, txtMinH: 60, chkMaxH: false, txtMaxH: 300, ddlAspect: 0, ddlH: 1, ddlV: 1 } },
            { name: "3-Col Pinterest Waterfall", data: { gridMode: 3, gridModeVal: 3, spacing: 14, rbHoriz: true, rbAverage: true, txtW: 120, txtH: 120, chkConstrain: false, chkMinW: false, txtMinW: 60, chkMaxW: false, txtMaxW: 300, chkMinH: false, txtMinH: 60, chkMaxH: false, txtMaxH: 300, ddlAspect: 1, ddlH: 1, ddlV: 1 } },
            { name: "Dynamic Banner Row", data: { gridMode: 5, gridModeVal: 1, spacing: 18, rbHoriz: true, rbAverage: true, txtW: 120, txtH: 120, chkConstrain: false, chkMinW: false, txtMinW: 60, chkMaxW: false, txtMaxW: 300, chkMinH: false, txtMinH: 60, chkMaxH: false, txtMaxH: 300, ddlAspect: 0, ddlH: 1, ddlV: 1 } },
            { name: "Dense Compact Grid", data: { gridMode: 0, gridModeVal: 6, spacing: 8, rbHoriz: true, rbAverage: true, txtW: 80, txtH: 80, chkConstrain: false, chkMinW: false, txtMinW: 40, chkMaxW: false, txtMaxW: 200, chkMinH: false, txtMinH: 40, chkMaxH: false, txtMaxH: 200, ddlAspect: 0, ddlH: 1, ddlV: 1 } }
        ];
        var lastUsed = null;

        try {
            var presetsFile = new File(Folder.userData + "/GridMasterPro_Presets.txt");
            if (presetsFile.exists) {
                presetsFile.open("r");
                while (!presetsFile.eof) {
                    var line = presetsFile.readLine();
                    if (!line) continue;
                    
                    if (line.indexOf("LAST_USED:") === 0) {
                        var kvStr = line.substring(10);
                        lastUsed = parseKVs(kvStr);
                    } else if (line.indexOf("PRESET:") === 0) {
                        var eqIdx = line.indexOf("=");
                        if (eqIdx !== -1) {
                            var presetName = line.substring(7, eqIdx);
                            var kvStr = line.substring(eqIdx + 1);
                            var data = parseKVs(kvStr);
                            
                            var found = false;
                            for (var p = 0; p < presets.length; p++) {
                                if (presets[p].name === presetName) {
                                    presets[p].data = data;
                                    found = true;
                                    break;
                                }
                            }
                            if (!found) {
                                presets.push({ name: presetName, data: data });
                            }
                        }
                    }
                }
                presetsFile.close();
            }
        } catch (e) {
            // fail silently
        }
        return { presets: presets, lastUsed: lastUsed };
    }

    function saveConfigFile(lastUsed, presets) {
        try {
            var presetsFile = new File(Folder.userData + "/GridMasterPro_Presets.txt");
            presetsFile.open("w");
            if (lastUsed) {
                presetsFile.write("LAST_USED:" + serializeKVs(lastUsed) + "\n");
            }
            for (var i = 4; i < presets.length; i++) {
                presetsFile.write("PRESET:" + presets[i].name + "=" + serializeKVs(presets[i].data) + "\n");
            }
            presetsFile.close();
        } catch (e) {
            // fail silently
        }
    }

    var config = readConfigFile();
    var lastUsedObj = config.lastUsed;

    // 2. Launch the Adobe Native ScriptUI Dialog
    var dialog = new Window("dialog", "GridMaster Pro - Layout Console");
    dialog.alignChildren = "fill";
    dialog.margins = 16;

    // Header Setup
    var titleGrp = dialog.add("group");
    titleGrp.orientation = "column";
    titleGrp.alignChildren = "center";
    var mainTitle = titleGrp.add("statictext", undefined, "GRIDMASTER AUTOMATION");
    mainTitle.graphics.font = ScriptUI.newFont("sans", "BOLD", 15);

    // PANEL 0: Presets Manager Panel
    var pnlPresets = dialog.add("panel", undefined, "Saved Settings Presets");
    pnlPresets.alignChildren = "fill";
    pnlPresets.margins = 12;

    var rowPresetSel = pnlPresets.add("group");
    rowPresetSel.add("statictext", undefined, "Select Preset:");
    var presetNames = [];
    for (var p = 0; p < config.presets.length; p++) {
        presetNames.push(config.presets[p].name);
    }
    var ddlPresets = rowPresetSel.add("dropdownlist", undefined, presetNames);
    ddlPresets.selection = 0;

    var rowPresetBtns = pnlPresets.add("group");
    rowPresetBtns.alignment = "right";
    var btnSavePreset = rowPresetBtns.add("button", undefined, "Save Preset");
    var btnDeletePreset = rowPresetBtns.add("button", undefined, "Delete");

    // Panel 1: Layout Properties
    var pnlGrid = dialog.add("panel", undefined, "Grid Properties");
    pnlGrid.alignChildren = "fill";

    var dRowMode = pnlGrid.add("group");
    dRowMode.add("statictext", undefined, "Distribution:");
    var ddlGridMode = dRowMode.add("dropdownlist", undefined, [
        "Fixed Columns Count", 
        "Fixed Rows Count", 
        "Keep Almost Square", 
        "Optimal Vertical (Waterfall)", 
        "Optimal Horizontal (Justified Rows)",
        "Fix Horizontal Gap",
        "Fix Vertical Gap"
    ]);
    ddlGridMode.selection = lastUsedObj && lastUsedObj.gridMode !== undefined ? lastUsedObj.gridMode : ${gridMode === 'cols' ? 0 : gridMode === 'rows' ? 1 : gridMode === 'square' ? 2 : gridMode === 'optimal_vertical' ? 3 : gridMode === 'optimal_horizontal' ? 4 : gridMode === 'fixed_gap_h' ? 5 : 6};

    var gRow1 = pnlGrid.add("group");
    var lblGridVal = gRow1.add("statictext", undefined, "Columns or Rows value:");
    var txtCols = gRow1.add("edittext", undefined, lastUsedObj && lastUsedObj.gridModeVal !== undefined ? String(lastUsedObj.gridModeVal) : "${gridModeVal}");
    txtCols.characters = 4;
    txtCols.enabled = ${gridMode === 'square' ? 'false' : 'true'};

    gRow1.add("statictext", undefined, "Spacing (pt):");
    var txtSpacing = gRow1.add("edittext", undefined, lastUsedObj && lastUsedObj.spacing !== undefined ? String(lastUsedObj.spacing) : "${spacing}");
    txtSpacing.characters = 4;

    ddlGridMode.onChange = function() {
        var idx = ddlGridMode.selection.index;
        if (idx === 0 || idx === 3 || idx === 5) {
            lblGridVal.text = idx === 0 ? "Columns Count:" : idx === 3 ? "Columns Count (Waterfall):" : "Columns Count (Fixed Gap):";
            txtCols.enabled = true;
        } else if (idx === 1 || idx === 4 || idx === 6) {
            lblGridVal.text = idx === 1 ? "Rows Count:" : idx === 4 ? "Rows Count (Justified):" : "Rows Count (Fixed Gap):";
            txtCols.enabled = true;
        } else {
            lblGridVal.text = "Auto calculated:";
            txtCols.enabled = false;
        }
    };

    var gRow2 = pnlGrid.add("group");
    gRow2.add("statictext", undefined, "Flow:");
    var rBtnHoriz = gRow2.add("radiobutton", undefined, "Horizontal");
    var rBtnVert = gRow2.add("radiobutton", undefined, "Vertical");
    if ("${flowDirection}" === "horizontal") { rBtnHoriz.value = true; } else { rBtnVert.value = true; }

    // Panel 2: Sizing Method
    var pnlSize = dialog.add("panel", undefined, "Sizing Strategy");
    pnlSize.alignChildren = "fill";
    var rbAverage = pnlSize.add("radiobutton", undefined, "Use Selected Average (" + Math.round(avgW) + " x " + Math.round(avgH) + " pt)");
    var rbManual = pnlSize.add("radiobutton", undefined, "Use Manual Dimensions");
    if ("${sizingStrategy}" === "average") { rbAverage.value = true; } else { rbManual.value = true; }

    var mSizeGrp = pnlSize.add("group");
    mSizeGrp.add("statictext", undefined, "Scale W (pt):");
    var txtManualW = mSizeGrp.add("edittext", undefined, "${manualW}");
    txtManualW.characters = 4;
    mSizeGrp.add("statictext", undefined, "Scale H (pt):");
    var txtManualH = mSizeGrp.add("edittext", undefined, "${manualH}");
    txtManualH.characters = 4;
    txtManualW.enabled = rbManual.value;
    txtManualH.enabled = rbManual.value;

    var rowConstrain = pnlSize.add("group");
    var chkConstrain = rowConstrain.add("checkbox", undefined, "Constrain W & H ratio when typing");
    chkConstrain.value = ${constrainManual ? 'true' : 'false'};
    chkConstrain.enabled = rbManual.value;

    var manualRatio = ${manualH > 0 ? manualW / manualH : 1.0};
    chkConstrain.onClick = function() {
        if (chkConstrain.value) {
            var w = parseFloat(txtManualW.text) || 120;
            var h = parseFloat(txtManualH.text) || 120;
            if (h > 0) {
                manualRatio = w / h;
            }
        }
    };

    txtManualW.onChange = function() {
        if (chkConstrain.value) {
            var w = parseFloat(txtManualW.text) || 0;
            if (manualRatio > 0) {
                var h = w / manualRatio;
                txtManualH.text = String(Math.round(h * 10) / 10);
            }
        } else {
            var w = parseFloat(txtManualW.text) || 0;
            var h = parseFloat(txtManualH.text) || 120;
            if (h > 0) {
                manualRatio = w / h;
            }
        }
    };

    txtManualH.onChange = function() {
        if (chkConstrain.value) {
            var h = parseFloat(txtManualH.text) || 0;
            var w = h * manualRatio;
            txtManualW.text = String(Math.round(w * 10) / 10);
        } else {
            var h = parseFloat(txtManualH.text) || 0;
            var w = parseFloat(txtManualW.text) || 120;
            if (h > 0) {
                manualRatio = w / h;
            }
        }
    };

    rbAverage.onClick = function() { 
        txtManualW.enabled = false; 
        txtManualH.enabled = false; 
        chkConstrain.enabled = false;
    };
    rbManual.onClick = function() { 
        txtManualW.enabled = true; 
        txtManualH.enabled = true; 
        chkConstrain.enabled = true;
    };

    // Panel Dimension Limits
    var pnlLimits = dialog.add("panel", undefined, "Optional Dimension Limits (checkbox + pt value)");
    pnlLimits.alignChildren = "left";
    pnlLimits.orientation = "column";

    // Min Width Group
    var gpMinW = pnlLimits.add("group");
    var chkMinW = gpMinW.add("checkbox", undefined, "Min Width: ");
    chkMinW.value = ${minWEnabled};
    var txtMinW = gpMinW.add("edittext", undefined, "${minWVal}");
    txtMinW.characters = 5;
    txtMinW.enabled = ${minWEnabled};
    chkMinW.onClick = function() { txtMinW.enabled = chkMinW.value; };

    // Max Width Group
    var gpMaxW = pnlLimits.add("group");
    var chkMaxW = gpMaxW.add("checkbox", undefined, "Max Width: ");
    chkMaxW.value = ${maxWEnabled};
    var txtMaxW = gpMaxW.add("edittext", undefined, "${maxWVal}");
    txtMaxW.characters = 5;
    txtMaxW.enabled = ${maxWEnabled};
    chkMaxW.onClick = function() { txtMaxW.enabled = chkMaxW.value; };

    // Min Height Group
    var gpMinH = pnlLimits.add("group");
    var chkMinH = gpMinH.add("checkbox", undefined, "Min Height: ");
    chkMinH.value = ${minHEnabled};
    var txtMinH = gpMinH.add("edittext", undefined, "${minHVal}");
    txtMinH.characters = 5;
    txtMinH.enabled = ${minHEnabled};
    chkMinH.onClick = function() { txtMinH.enabled = chkMinH.value; };

    // Max Height Group
    var gpMaxH = pnlLimits.add("group");
    var chkMaxH = gpMaxH.add("checkbox", undefined, "Max Height: ");
    chkMaxH.value = ${maxHEnabled};
    var txtMaxH = gpMaxH.add("edittext", undefined, "${maxHVal}");
    txtMaxH.characters = 5;
    txtMaxH.enabled = ${maxHEnabled};
    chkMaxH.onClick = function() { txtMaxH.enabled = chkMaxH.value; };

    // Panel 3: Aspect Scaling & Alignments
    var pnlRules = dialog.add("panel", undefined, "Aspect Rules & Alignments");
    pnlRules.alignChildren = "left";
    var ddlAspect = pnlRules.add("dropdownlist", undefined, [
        "Aspect Fit (Keep Ratio, Fit Inside Box)",
        "Fit Width (Keep Ratio, Auto Height)",
        "Fit Height (Keep Ratio, Auto Width)",
        "Stretch Fill (Stretch boundaries)",
        "Optimal Aspect vertical (Larger side equals size)",
        "Optimal Aspect Horizontal (Shorter side equals size)"
    ]);
    ddlAspect.selection = ${aspectRatioMode === 'fit' ? 0 : aspectRatioMode === 'width' ? 1 : aspectRatioMode === 'height' ? 2 : aspectRatioMode === 'stretch' ? 3 : aspectRatioMode === 'optimal_vertical' ? 4 : 5};

    var alignRow = pnlRules.add("group");
    alignRow.add("statictext", undefined, "H-Align:");
    var ddlH = alignRow.add("dropdownlist", undefined, ["Left", "Center", "Right"]);
    ddlH.selection = ${hAlign === 'left' ? 0 : hAlign === 'center' ? 1 : 2};
    
    alignRow.add("statictext", undefined, "V-Align:");
    var ddlV = alignRow.add("dropdownlist", undefined, ["Top", "Middle", "Bottom"]);
    ddlV.selection = ${vAlign === 'top' ? 0 : vAlign === 'middle' ? 1 : 2};

    // Presets event listener logic
    function applyPresetToUI(presetData) {
        if (!presetData) return;
        if (presetData.gridMode !== undefined) ddlGridMode.selection = presetData.gridMode;
        if (presetData.gridModeVal !== undefined) txtCols.text = String(presetData.gridModeVal);
        if (presetData.spacing !== undefined) txtSpacing.text = String(presetData.spacing);
        
        if (presetData.rbHoriz !== undefined) {
            rBtnHoriz.value = presetData.rbHoriz;
            rBtnVert.value = !presetData.rbHoriz;
        }
        
        if (presetData.rbAverage !== undefined) {
            rbAverage.value = presetData.rbAverage;
            rbManual.value = !presetData.rbAverage;
            txtManualW.enabled = !presetData.rbAverage;
            txtManualH.enabled = !presetData.rbAverage;
            chkConstrain.enabled = !presetData.rbAverage;
        }
        
        if (presetData.txtW !== undefined) txtManualW.text = String(presetData.txtW);
        if (presetData.txtH !== undefined) txtManualH.text = String(presetData.txtH);
        if (presetData.chkConstrain !== undefined) chkConstrain.value = presetData.chkConstrain;
        
        if (presetData.chkMinW !== undefined) {
            chkMinW.value = presetData.chkMinW;
            txtMinW.enabled = presetData.chkMinW;
        }
        if (presetData.txtMinW !== undefined) txtMinW.text = String(presetData.txtMinW);
        
        if (presetData.chkMaxW !== undefined) {
            chkMaxW.value = presetData.chkMaxW;
            txtMaxW.enabled = presetData.chkMaxW;
        }
        if (presetData.txtMaxW !== undefined) txtMaxW.text = String(presetData.txtMaxW);
        
        if (presetData.chkMinH !== undefined) {
            chkMinH.value = presetData.chkMinH;
            txtMinH.enabled = presetData.chkMinH;
        }
        if (presetData.txtMinH !== undefined) txtMinH.text = String(presetData.txtMinH);
        
        if (presetData.chkMaxH !== undefined) {
            chkMaxH.value = presetData.chkMaxH;
            txtMaxH.enabled = presetData.chkMaxH;
        }
        if (presetData.txtMaxH !== undefined) txtMaxH.text = String(presetData.txtMaxH);
        
        if (presetData.ddlAspect !== undefined) ddlAspect.selection = presetData.ddlAspect;
        if (presetData.ddlH !== undefined) ddlH.selection = presetData.ddlH;
        if (presetData.ddlV !== undefined) ddlV.selection = presetData.ddlV;
    }

    ddlPresets.onChange = function() {
        var idx = ddlPresets.selection.index;
        if (idx !== -1 && config.presets[idx]) {
            applyPresetToUI(config.presets[idx].data);
        }
    };

    btnSavePreset.onClick = function() {
        var name = prompt("Enter a name for this custom layout preset:", "My Custom Preset");
        if (name) {
            name = name.replace(/=/g, "").replace(/:/g, "");
            var uiData = {
                gridMode: ddlGridMode.selection.index,
                gridModeVal: parseInt(txtCols.text, 10) || 4,
                spacing: parseFloat(txtSpacing.text) || 12,
                rbHoriz: rBtnHoriz.value,
                rbAverage: rbAverage.value,
                txtW: parseFloat(txtManualW.text) || Math.round(avgW),
                txtH: parseFloat(txtManualH.text) || Math.round(avgH),
                chkConstrain: chkConstrain.value,
                chkMinW: chkMinW.value,
                txtMinW: parseFloat(txtMinW.text) || 60,
                chkMaxW: chkMaxW.value,
                txtMaxW: parseFloat(txtMaxW.text) || 300,
                chkMinH: chkMinH.value,
                txtMinH: parseFloat(txtMinH.text) || 60,
                chkMaxH: chkMaxH.value,
                txtMaxH: parseFloat(txtMaxH.text) || 300,
                ddlAspect: ddlAspect.selection.index,
                ddlH: ddlH.selection.index,
                ddlV: ddlV.selection.index
            };
            
            var existsIdx = -1;
            for (var i = 0; i < config.presets.length; i++) {
                if (config.presets[i].name.toLowerCase() === name.toLowerCase()) {
                    existsIdx = i;
                    break;
                }
            }
            if (existsIdx !== -1) {
                config.presets[existsIdx].data = uiData;
            } else {
                config.presets.push({ name: name, data: uiData });
            }
            
            saveConfigFile(uiData, config.presets);
            
            ddlPresets.removeAll();
            for (var i = 0; i < config.presets.length; i++) {
                ddlPresets.add("item", config.presets[i].name);
            }
            
            for (var i = 0; i < config.presets.length; i++) {
                if (config.presets[i].name === name) {
                    ddlPresets.selection = i;
                    break;
                }
            }
            alert("Preset '" + name + "' saved successfully!");
        }
    };

    btnDeletePreset.onClick = function() {
        var selIdx = ddlPresets.selection.index;
        if (selIdx < 4) {
            alert("Cannot delete default core presets!");
            return;
        }
        var nameToDelete = config.presets[selIdx].name;
        if (confirm("Are you sure you want to delete preset '" + nameToDelete + "'?")) {
            config.presets.splice(selIdx, 1);
            
            var currentUIData = {
                gridMode: ddlGridMode.selection.index,
                gridModeVal: parseInt(txtCols.text, 10) || 4,
                spacing: parseFloat(txtSpacing.text) || 12,
                rbHoriz: rBtnHoriz.value,
                rbAverage: rbAverage.value,
                txtW: parseFloat(txtManualW.text) || Math.round(avgW),
                txtH: parseFloat(txtManualH.text) || Math.round(avgH),
                chkConstrain: chkConstrain.value,
                chkMinW: chkMinW.value,
                txtMinW: parseFloat(txtMinW.text) || 60,
                chkMaxW: chkMaxW.value,
                txtMaxW: parseFloat(txtMaxW.text) || 300,
                chkMinH: chkMinH.value,
                txtMinH: parseFloat(txtMinH.text) || 60,
                chkMaxH: chkMaxH.value,
                txtMaxH: parseFloat(txtMaxH.text) || 300,
                ddlAspect: ddlAspect.selection.index,
                ddlH: ddlH.selection.index,
                ddlV: ddlV.selection.index
            };
            
            saveConfigFile(currentUIData, config.presets);
            
            ddlPresets.removeAll();
            for (var i = 0; i < config.presets.length; i++) {
                ddlPresets.add("item", config.presets[i].name);
            }
            ddlPresets.selection = 0;
            applyPresetToUI(config.presets[0].data);
            alert("Preset deleted successfully.");
        }
    };

    // Apply last used automatically on dialog startup
    if (lastUsedObj) {
        applyPresetToUI(lastUsedObj);
    }

    // Action Row
    var actionGrp = dialog.add("group");
    actionGrp.alignment = "center";
    actionGrp.add("button", undefined, "Cancel", {name: "cancel"});
    var btnOK = actionGrp.add("button", undefined, "Apply Layout", {name: "ok"});

    if (dialog.show() === 1) {
        var isMinW = chkMinW.value;
        var valMinW = parseFloat(txtMinW.text) || 60;
        var isMaxW = chkMaxW.value;
        var valMaxW = parseFloat(txtMaxW.text) || 300;
        var isMinH = chkMinH.value;
        var valMinH = parseFloat(txtMinH.text) || 60;
        var isMaxH = chkMaxH.value;
        var valMaxH = parseFloat(txtMaxH.text) || 300;

        var finalGridMode = ddlGridMode.selection.index;
        var finalGridVal = parseInt(txtCols.text, 10) || 4;
        
        var finalCols = 4;
        if (finalGridMode === 0 || finalGridMode === 3 || finalGridMode === 5) {
            finalCols = finalGridVal;
        } else if (finalGridMode === 1 || finalGridMode === 4 || finalGridMode === 6) {
            finalCols = Math.ceil(count / finalGridVal);
        } else {
            finalCols = Math.ceil(Math.sqrt(count));
        }
        if (finalCols < 1) finalCols = 1;

        var finalSpacing = parseFloat(txtSpacing.text) || 12;
        var scaleFactor = ${scale / 100};

        var targetW = rbAverage.value ? avgW : (parseFloat(txtManualW.text) || avgW);
        var targetH = rbAverage.value ? avgH : (parseFloat(txtManualH.text) || avgH);
        targetW *= scaleFactor;
        targetH *= scaleFactor;

        var aspectOption = ddlAspect.selection.index;
        var alignHIndex = ddlH.selection.index;
        var alignVIndex = ddlV.selection.index;
        var isHorizFlow = rBtnHoriz.value;

        // Sort relative to top-left locations so the grid is ordered naturally
        items.sort(function(a, b) {
            var aY = Math.round(a.top);
            var bY = Math.round(b.top);
            var aX = Math.round(a.left);
            var bX = Math.round(b.left);
            if (aY !== bY) { return bY - aY; } // top-to-bottom
            return aX - bX; // left-to-right
        });

        var gridRows = Math.ceil(count / finalCols);

        // Pre-calculate sizing for all items
        var sizedList = [];
        for (var j = 0; j < count; j++) {
            var el = items[j];
            var origW = el.width;
            var origH = el.height;
            var origRatio = origW / origH;

            var newW = targetW;
            var newH = targetH;

            // Aspect Ratio constraints calculations
            if (aspectOption === 0) { // Aspect Fit (keep ratio inside bounding target cell)
                var cellRatio = targetW / targetH;
                if (origRatio > cellRatio) {
                    newW = targetW;
                    newH = targetW / origRatio;
                } else {
                    newH = targetH;
                    newW = targetH * origRatio;
                }
            } else if (aspectOption === 1) { // Fit Width
                newW = targetW;
                newH = targetW / origRatio;
            } else if (aspectOption === 2) { // Fit Height
                newH = targetH;
                newW = targetH * origRatio;
            } else if (aspectOption === 4) { // Optimal Aspect vertical (Larger side equals size)
                if (origRatio >= 1.0) { // horizontal or square
                    newW = targetW;
                    newH = targetW / origRatio;
                } else { // vertical
                    newH = targetW;
                    newW = targetW * origRatio;
                }
            } else if (aspectOption === 5) { // Optimal Aspect Horizontal (Shorter side equals size)
                if (origRatio >= 1.0) { // horizontal or square
                    newH = targetW;
                    newW = targetW * origRatio;
                } else { // vertical
                    newW = targetW;
                    newH = targetW / origRatio;
                }
            }

            // Apply ExtendScript dimension limits
            var lockAspect = (aspectOption !== 3);
            if (lockAspect) {
                if (isMinW && newW < valMinW) {
                    newW = valMinW;
                    newH = valMinW / origRatio;
                }
                if (isMinH && newH < valMinH) {
                    newH = valMinH;
                    newW = valMinH * origRatio;
                }
                if (isMaxW && newW > valMaxW) {
                    newW = valMaxW;
                    newH = valMaxW / origRatio;
                }
                if (isMaxH && newH > valMaxH) {
                    newH = valMaxH;
                    newW = valMaxH * origRatio;
                }
            } else {
                if (isMinW && newW < valMinW) newW = valMinW;
                if (isMaxW && newW > valMaxW) newW = valMaxW;
                if (isMinH && newH < valMinH) newH = valMinH;
                if (isMaxH && newH > valMaxH) newH = valMaxH;
            }

            sizedList.push({
                el: el,
                w: newW,
                h: newH
            });
        }

        // Trackers for waterfall columns / justified rows
        var colHeights = [];
        var colItemsCount = [];
        if (finalGridMode === 3) {
            for (var c = 0; c < finalCols; c++) {
                colHeights.push(maxTop);
                colItemsCount.push(0);
            }
        }

        var rowWidths = [];
        var rowItemsCount = [];
        if (finalGridMode === 4) {
            var designRows = finalGridVal;
            if (designRows < 1) designRows = 1;
            for (var r = 0; r < designRows; r++) {
                rowWidths.push(minLeft);
                rowItemsCount.push(0);
            }
        }

        if (finalGridMode === 5) { // Fix Gap Horizontal (Y grows upwards)
            var currentY = maxTop;
            var numRows = Math.ceil(count / finalCols);
            for (var r = 0; r < numRows; r++) {
                var rowItems = [];
                for (var i = r * finalCols; i < Math.min((r + 1) * finalCols, count); i++) {
                    rowItems.push(sizedList[i]);
                }
                if (rowItems.length === 0) continue;

                var rowTallest = 0;
                for (var i = 0; i < rowItems.length; i++) {
                    if (rowItems[i].h > rowTallest) rowTallest = rowItems[i].h;
                }

                var previousLeft = minLeft;
                for (var i = 0; i < rowItems.length; i++) {
                    var si = rowItems[i];
                    var elementLeft = previousLeft;
                    if (i > 0) {
                        elementLeft = previousLeft + finalSpacing;
                    }

                    var elementTop = currentY; 
                    if (alignVIndex === 1) { // middle
                        elementTop = currentY - (rowTallest - si.h) / 2;
                    } else if (alignVIndex === 2) { // bottom
                        elementTop = currentY - (rowTallest - si.h);
                    }

                    si.el.width = si.w;
                    si.el.height = si.h;
                    si.el.position = [elementLeft, elementTop];

                    previousLeft = elementLeft + si.w;
                }

                currentY -= (rowTallest + finalSpacing);
            }
        } else if (finalGridMode === 6) { // Fix Gap Vertical (Y grows upwards)
            var rowsPerCol = Math.ceil(count / finalCols);
            var numColsCalculated = Math.ceil(count / rowsPerCol);
            var currentX = minLeft;

            for (var c = 0; c < numColsCalculated; c++) {
                var colItems = [];
                for (var i = c * rowsPerCol; i < Math.min((c + 1) * rowsPerCol, count); i++) {
                    colItems.push(sizedList[i]);
                }
                if (colItems.length === 0) continue;

                var colWidest = 0;
                for (var i = 0; i < colItems.length; i++) {
                    if (colItems[i].w > colWidest) colWidest = colItems[i].w;
                }

                var previousTop = maxTop;
                for (var i = 0; i < colItems.length; i++) {
                    var si = colItems[i];
                    var elementTop = previousTop;
                    if (i > 0) {
                        elementTop = previousTop - finalSpacing;
                    }

                    var elementLeft = currentX;
                    if (alignHIndex === 1) { // center
                        elementLeft = currentX + (colWidest - si.w) / 2;
                    } else if (alignHIndex === 2) { // right
                        elementLeft = currentX + (colWidest - si.w);
                    }

                    si.el.width = si.w;
                    si.el.height = si.h;
                    si.el.position = [elementLeft, elementTop];

                    previousTop = elementTop - si.h;
                }

                currentX += colWidest + finalSpacing;
            }
        } else {
            for (var j = 0; j < count; j++) {
                var si = sizedList[j];

                if (finalGridMode === 3) { // Optimal Vertical (Waterfall)
                    var targetColIdx = 0;
                    var maxColY = -Infinity;
                    for (var c = 0; c < finalCols; c++) {
                        if (colHeights[c] > maxColY) {
                            maxColY = colHeights[c];
                            targetColIdx = c;
                        }
                    }

                    var cellLeft = minLeft + targetColIdx * (targetW + finalSpacing);
                    var cellTop = colHeights[targetColIdx];
                    if (colItemsCount[targetColIdx] > 0) {
                        cellTop = cellTop - finalSpacing;
                    }

                    var finalLeft = cellLeft;
                    if (alignHIndex === 1) {
                        finalLeft = cellLeft + (targetW - si.w) / 2;
                    } else if (alignHIndex === 2) {
                        finalLeft = cellLeft + targetW - si.w;
                    }

                    var finalTop = cellTop; // Top boundary of element
                    si.el.width = si.w;
                    si.el.height = si.h;
                    si.el.position = [finalLeft, finalTop];

                    // Update column height
                    colHeights[targetColIdx] = cellTop - si.h;
                    colItemsCount[targetColIdx]++;

                } else if (finalGridMode === 4) { // Optimal Horizontal (Justified Rows)
                    var designRows = finalGridVal;
                    if (designRows < 1) designRows = 1;

                    var targetRowIdx = 0;
                    var minRowX = Infinity;
                    for (var r = 0; r < designRows; r++) {
                        if (rowWidths[r] < minRowX) {
                            minRowX = rowWidths[r];
                            targetRowIdx = r;
                        }
                    }

                    var cellTop = maxTop - targetRowIdx * (targetH + finalSpacing);
                    var cellLeft = rowWidths[targetRowIdx];
                    if (rowItemsCount[targetRowIdx] > 0) {
                        cellLeft = cellLeft + finalSpacing;
                    }

                    var finalLeft = cellLeft;
                    var finalTop = cellTop;
                    if (alignVIndex === 1) {
                        finalTop = cellTop - (targetH - si.h) / 2;
                    } else if (alignVIndex === 2) {
                        finalTop = cellTop - (targetH - si.h);
                    }

                    si.el.width = si.w;
                    si.el.height = si.h;
                    si.el.position = [finalLeft, finalTop];

                    // Update row width
                    rowWidths[targetRowIdx] = cellLeft + si.w;
                    rowItemsCount[targetRowIdx]++;

                } else { // Standard Grid
                    var colIdx, rowIdx;
                    if (isHorizFlow) {
                        colIdx = j % finalCols;
                        rowIdx = Math.floor(j / finalCols);
                    } else {
                        rowIdx = j % gridRows;
                        colIdx = Math.floor(j / gridRows);
                    }

                    var cellLeft = minLeft + colIdx * (targetW + finalSpacing);
                    var cellTop = maxTop - rowIdx * (targetH + finalSpacing);

                    var finalLeft = cellLeft;
                    if (alignHIndex === 1) { // Center
                        finalLeft = cellLeft + (targetW - si.w) / 2;
                    } else if (alignHIndex === 2) { // Right
                        finalLeft = cellLeft + targetW - si.w;
                    }

                    var finalTop = cellTop; // Top boundary
                    if (alignVIndex === 1) { // Middle
                        finalTop = cellTop - (targetH - si.h) / 2;
                    } else if (alignVIndex === 2) { // Bottom
                        finalTop = cellTop - (targetH - si.h);
                    }

                    si.el.width = si.w;
                    si.el.height = si.h;
                    si.el.position = [finalLeft, finalTop];
                }
            }
        }

        doc.views[0].zoom = doc.views[0].zoom; // Redraw trigger
        alert("Completed Successfully!\\nResized and ordered " + count + " assets in a grid layout.");
    }
})();`;
    }

    // Modern Adobe UXP (JS structure)
    return `// Adobe Illustrator Unified Extensibility Platform (UXP) Script
const { app } = require("illustrator");

async function executeGridMasterLayout() {
    if (app.documents.length === 0) {
        console.log("No active documents found.");
        return;
    }

    const doc = app.activeDocument;
    const selection = doc.selection;

    if (!selection || selection.length === 0) {
        console.log("Please select at least 2 elements first.");
        return;
    }

    // 1. Read sizes and positions
    let totalW = 0;
    let totalH = 0;
    let minLeft = selection[0].bounds[0];
    let maxTop = selection[0].bounds[1];

    const items = [];
    for (let i = 0; i < selection.length; i++) {
        const item = selection[i];
        items.push(item);
        totalW += item.width;
        totalH += item.height;
        if (item.bounds[0] < minLeft) minLeft = item.bounds[0];
        if (item.bounds[1] > maxTop) maxTop = item.bounds[1];
    }

    const count = items.length;
    const avgW = totalW / count;
    const avgH = totalH / count;

    // Config parameters (Mirrored directly from active slider setup)
    const presetCols = ${columns};
    const presetSpacing = ${spacing};
    const scalingFactor = ${scale / 100};
    const horizontalFlow = ${flowDirection === 'horizontal'};
    
    const baseW = ${sizingStrategy === 'average' ? 'avgW' : manualW};
    const baseH = ${sizingStrategy === 'average' ? 'avgH' : manualH};

    const minWEnabled = ${minWEnabled};
    const minWVal = ${minWVal};
    const maxWEnabled = ${maxWEnabled};
    const maxWVal = ${maxWVal};
    const minHEnabled = ${minHEnabled};
    const minHVal = ${minHVal};
    const maxHEnabled = ${maxHEnabled};
    const maxHVal = ${maxHVal};

    const targetW = baseW * scalingFactor;
    const targetH = baseH * scalingFactor;

    // Align indices (0 = Left/Top, 1 = Center/Middle, 2 = Right/Bottom)
    const hAlignRule = "${hAlign}"; // 'left', 'center', 'right'
    const vAlignRule = "${vAlign}"; // 'top', 'middle', 'bottom'

    // Sort visually
    items.sort((a, b) => {
        const aL = a.bounds[0];
        const aT = a.bounds[1];
        const bL = b.bounds[0];
        const bT = b.bounds[1];
        if (Math.round(aT) !== Math.round(bT)) {
            return bT - aT; // Top to bottom (Y coordinate values)
        }
        return aL - bL; // Left to right
    });

    const numRows = Math.ceil(count / presetCols);

    // 2. Pre-calculate sizing for each selected item
    const sizedList = [];
    for (let j = 0; j < count; j++) {
        const el = items[j];
        const originalW = el.width;
        const originalH = el.height;
        const origRatio = originalW / originalH;

        let finalW = targetW;
        let finalH = targetH;

        // Aspect keeping calculations
        const resizeMode = "${aspectRatioMode}";
        if (resizeMode === "fit") {
            const cellRatio = targetW / targetH;
            if (origRatio > cellRatio) {
                finalW = targetW;
                finalH = targetW / origRatio;
            } else {
                finalH = targetH;
                finalW = targetH * origRatio;
            }
        } else if (resizeMode === "width") {
            finalW = targetW;
            finalH = targetW / origRatio;
        } else if (resizeMode === "height") {
            finalH = targetH;
            finalW = targetH * origRatio;
        } else if (resizeMode === "optimal_vertical") {
            if (origRatio >= 1.0) {
                finalW = targetW;
                finalH = targetW / origRatio;
            } else {
                finalH = targetW;
                finalW = targetW * origRatio;
            }
        } else if (resizeMode === "optimal_horizontal") {
            if (origRatio >= 1.0) {
                finalH = targetW;
                finalW = targetW * origRatio;
            } else {
                finalW = targetW;
                finalH = targetW / origRatio;
            }
        }

        // Apply Dimension limits constraints
        const lockAspect = (resizeMode !== "stretch");
        if (lockAspect) {
            if (minWEnabled && finalW < minWVal) {
                finalW = minWVal;
                finalH = Math.round(minWVal / origRatio);
            }
            if (minHEnabled && finalH < minHVal) {
                finalH = minHVal;
                finalW = Math.round(minHVal * origRatio);
            }
            if (maxWEnabled && finalW > maxWVal) {
                finalW = maxWVal;
                finalH = Math.round(maxWVal / origRatio);
            }
            if (maxHEnabled && finalH > maxHVal) {
                finalH = maxHVal;
                finalW = Math.round(maxHVal * origRatio);
            }
        } else {
            if (minWEnabled && finalW < minWVal) finalW = minWVal;
            if (maxWEnabled && finalW > maxWVal) finalW = maxWVal;
            if (minHEnabled && finalH < minHVal) finalH = minHVal;
            if (maxHEnabled && finalH > maxHVal) finalH = maxHVal;
        }

        sizedList.push({
            el,
            w: finalW,
            h: finalH
        });
    }

    if (activeGridMode === "fixed_gap_h") {
        let currentY = maxTop;
        for (let r = 0; r < numRows; r++) {
            const rowItems = [];
            for (let i = r * presetCols; i < Math.min((r + 1) * presetCols, count); i++) {
                rowItems.push(sizedList[i]);
            }
            if (rowItems.length === 0) continue;

            let rowTallest = 0;
            for (let i = 0; i < rowItems.length; i++) {
                if (rowItems[i].h > rowTallest) rowTallest = rowItems[i].h;
            }

            let previousLeft = minLeft;
            for (let i = 0; i < rowItems.length; i++) {
                const si = rowItems[i];
                const elementLeft = i > 0 ? previousLeft + presetSpacing : previousLeft;
                
                let elementTop = currentY;
                if (vAlignRule === "middle") {
                    elementTop = currentY - (rowTallest - si.h) / 2;
                } else if (vAlignRule === "bottom") {
                    elementTop = currentY - (rowTallest - si.h);
                }

                si.el.width = si.w;
                si.el.height = si.h;
                si.el.position = [elementLeft, elementTop];

                previousLeft = elementLeft + si.w;
            }
            currentY -= (rowTallest + presetSpacing);
        }
    } else if (activeGridMode === "fixed_gap_v") {
        const rowsPerCol = Math.ceil(count / presetCols);
        const numColsCalculated = Math.ceil(count / rowsPerCol);
        let currentX = minLeft;

        for (let c = 0; c < numColsCalculated; c++) {
            const colItems = [];
            for (let i = c * rowsPerCol; i < Math.min((c + 1) * rowsPerCol, count); i++) {
                colItems.push(sizedList[i]);
            }
            if (colItems.length === 0) continue;

            let colWidest = 0;
            for (let i = 0; i < colItems.length; i++) {
                if (colItems[i].w > colWidest) colWidest = colItems[i].w;
            }

            let previousTop = maxTop;
            for (let i = 0; i < colItems.length; i++) {
                const si = colItems[i];
                const elementTop = i > 0 ? previousTop - presetSpacing : previousTop;

                let elementLeft = currentX;
                if (hAlignRule === "center") {
                    elementLeft = currentX + (colWidest - si.w) / 2;
                } else if (hAlignRule === "right") {
                    elementLeft = currentX + (colWidest - si.w);
                }

                si.el.width = si.w;
                si.el.height = si.h;
                si.el.position = [elementLeft, elementTop];

                previousTop = elementTop - si.h;
            }
            currentX += colWidest + presetSpacing;
        }
    } else {
        const colHeights = [];
        const colItemsCount = [];
        if (activeGridMode === "optimal_vertical") {
            for (let c = 0; c < presetCols; c++) {
                colHeights.push(maxTop);
                colItemsCount.push(0);
            }
        }

        const rowWidths = [];
        const rowItemsCount = [];
        if (activeGridMode === "optimal_horizontal") {
            const designRows = gridModeVal;
            for (let r = 0; r < designRows; r++) {
                rowWidths.push(minLeft);
                rowItemsCount.push(0);
            }
        }

        for (let j = 0; j < count; j++) {
            const si = sizedList[j];

            if (activeGridMode === "optimal_vertical") {
                let targetColIdx = 0;
                let maxColY = -Infinity;
                for (let c = 0; c < presetCols; c++) {
                    if (colHeights[c] > maxColY) {
                        maxColY = colHeights[c];
                        targetColIdx = c;
                    }
                }

                const cellLeft = minLeft + targetColIdx * (targetW + presetSpacing);
                const cellTop = colItemsCount[targetColIdx] > 0 ? colHeights[targetColIdx] - presetSpacing : colHeights[targetColIdx];

                let elementLeft = cellLeft;
                if (hAlignRule === "center") elementLeft = cellLeft + (targetW - si.w) / 2;
                else if (hAlignRule === "right") elementLeft = cellLeft + targetW - si.w;

                si.el.width = si.w;
                si.el.height = si.h;
                si.el.position = [elementLeft, cellTop];

                colHeights[targetColIdx] = cellTop - si.h;
                colItemsCount[targetColIdx]++;

            } else if (activeGridMode === "optimal_horizontal") {
                let targetRowIdx = 0;
                let minRowX = Infinity;
                for (let r = 0; r < gridModeVal; r++) {
                    if (rowWidths[r] < minRowX) {
                        minRowX = rowWidths[r];
                        targetRowIdx = r;
                    }
                }

                const cellTop = maxTop - targetRowIdx * (targetH + presetSpacing);
                const cellLeft = rowItemsCount[targetRowIdx] > 0 ? rowWidths[targetRowIdx] + presetSpacing : rowWidths[targetRowIdx];

                let elementTop = cellTop;
                if (vAlignRule === "middle") elementTop = cellTop - (targetH - si.h) / 2;
                else if (vAlignRule === "bottom") elementTop = cellTop - (targetH - si.h);

                si.el.width = si.w;
                si.el.height = si.h;
                si.el.position = [cellLeft, elementTop];

                rowWidths[targetRowIdx] = cellLeft + si.w;
                rowItemsCount[targetRowIdx]++;

            } else {
                let colIdx, rowIdx;
                if (horizontalFlow) {
                    colIdx = j % presetCols;
                    rowIdx = Math.floor(j / presetCols);
                } else {
                    rowIdx = j % numRows;
                    colIdx = Math.floor(j / numRows);
                }

                const cellLeft = minLeft + colIdx * (targetW + presetSpacing);
                const cellTop = maxTop - rowIdx * (targetH + presetSpacing);

                let elementLeft = cellLeft;
                if (hAlignRule === "center") elementLeft = cellLeft + (targetW - si.w) / 2;
                else if (hAlignRule === "right") elementLeft = cellLeft + targetW - si.w;

                let elementTop = cellTop;
                if (vAlignRule === "middle") elementTop = cellTop - (targetH - si.h) / 2;
                else if (vAlignRule === "bottom") elementTop = cellTop - (targetH - si.h);

                si.el.width = si.w;
                si.el.height = si.h;
                si.el.position = [elementLeft, elementTop];
            }
        }
    }
    
    console.log("Structured " + count + " items successfully into a grid!");
}

executeGridMasterLayout().catch(err => {
    console.error("Layout Exception:", err);
});`;
  }, [columns, spacing, scale, flowDirection, aspectRatioMode, hAlign, vAlign, sizingStrategy, manualW, manualH, averages, scriptType, minWEnabled, minWVal, maxWEnabled, maxWVal, minHEnabled, minHVal, maxHEnabled, maxHVal, gridMode, gridModeVal]);

  // Copy code utility
  const copyScriptToClipboard = () => {
    navigator.clipboard.writeText(generatedScriptCode);
    setCopied(true);
    triggerToast('Illustrator Script Copied to Clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  // Click handler to select / deselect an item manually
  const toggleSelection = (e: React.MouseEvent, itemId: string) => {
    e.stopPropagation(); // Avoid triggering standard artboard deselects
    setItems(prev =>
      prev.map(item =>
        item.id === itemId
          ? { ...item, selected: !item.selected }
          : item
      )
    );
  };

  // Helper buttons to clear or select all items
  const selectAllItems = () => {
    setItems(prev => prev.map(item => ({ ...item, selected: true })));
    triggerToast('All elements selected');
  };

  const deselectAllItems = () => {
    setItems(prev => prev.map(item => ({ ...item, selected: false })));
    triggerToast('Selection cleared');
  };

  // Scramble / Scatter command to break the grid and test resizing layout again
  const scatterItems = () => {
    selectionAnchorRef.current = null;
    setItems(prev =>
      prev.map(item => {
        // Generate random sizes keeping the initial ratios but scaling heavily
        const randomScale = 0.5 + Math.random() * 1.0; // multiplier
        const newW = Math.round(item.initialW * randomScale);
        const newH = Math.round(item.initialH * randomScale);
        const randomX = Math.round(30 + Math.random() * 320);
        const randomY = Math.round(40 + Math.random() * 220);
        const randomRotation = Math.round(-25 + Math.random() * 50);

        return {
          ...item,
          x: randomX,
          y: randomY,
          w: newW,
          h: newH,
          rotation: randomRotation
        };
      })
    );
    triggerToast('Artboard elements randomized & scattered!');
  };

  // Core Math - Apply the Grid Resize and Placement Logic on Selected Items!
  const applyGridLayout = (quiet: boolean = false) => {
    if (numSelected < 2) {
      if (!quiet) {
        triggerToast('Please select at least 2 items to align into a grid.');
      }
      return;
    }

    const totalSelected = numSelected;

    // Find the starting top-left coordinates of the currently active selection
    let minX = Infinity;
    let minY = Infinity;

    selectedItems.forEach(item => {
      if (item.x < minX) minX = item.x;
      if (item.y < minY) minY = item.y;
    });

    if (selectionAnchorRef.current === null && minX !== Infinity && minY !== Infinity) {
      selectionAnchorRef.current = { x: minX, y: minY };
    }

    const anchorX = selectionAnchorRef.current ? selectionAnchorRef.current.x : minX;
    const anchorY = selectionAnchorRef.current ? selectionAnchorRef.current.y : minY;

    const targetW = (sizingStrategy === 'average' ? averages.w : manualW) * (scale / 100);
    const targetH = (sizingStrategy === 'average' ? averages.h : manualH) * (scale / 100);

    // Sort selected items by their visual coordinates: Top-to-Bottom, Left-to-Right
    // To mimic genuine graphic ordering
    const sortedSelected = [...selectedItems].sort((a, b) => {
      const centerY_A = a.y + a.h / 2;
      const centerY_B = b.y + b.h / 2;
      const centerX_A = a.x + a.w / 2;
      const centerX_B = b.x + b.w / 2;

      // Group roughly equal Y positions within 30 pixels window
      if (Math.abs(centerY_A - centerY_B) > 30) {
        return centerY_A - centerY_B;
      }
      return centerX_A - centerX_B;
    });

    // Pre-calculate sizing for all selected items
    const sizedItems = sortedSelected.map((item) => {
      const originalRatio = item.initialW / item.initialH;
      let finalW = targetW;
      let finalH = targetH;

      if (lockRatio) {
        if (aspectRatioMode === 'fit') {
          const cellRatio = targetW / targetH;
          if (originalRatio > cellRatio) {
            finalW = targetW;
            finalH = Math.round(targetW / originalRatio);
          } else {
            finalH = targetH;
            finalW = Math.round(targetH * originalRatio);
          }
        } else if (aspectRatioMode === 'width') {
          finalW = targetW;
          finalH = Math.round(targetW / originalRatio);
        } else if (aspectRatioMode === 'height') {
          finalH = targetH;
          finalW = Math.round(targetH * originalRatio);
        } else if (aspectRatioMode === 'optimal_vertical') {
          if (originalRatio >= 1.0) {
            finalW = targetW;
            finalH = Math.round(targetW / originalRatio);
          } else {
            finalH = targetW;
            finalW = Math.round(targetW * originalRatio);
          }
        } else if (aspectRatioMode === 'optimal_horizontal') {
          if (originalRatio >= 1.0) {
            finalH = targetW;
            finalW = Math.round(targetW * originalRatio);
          } else {
            finalW = targetW;
            finalH = Math.round(targetW / originalRatio);
          }
        }
      }

      // Apply Dimension limit bounds
      if (lockRatio) {
        if (minWEnabled && finalW < minWVal) {
          finalW = minWVal;
          finalH = Math.round(minWVal / originalRatio);
        }
        if (minHEnabled && finalH < minHVal) {
          finalH = minHVal;
          finalW = Math.round(minHVal * originalRatio);
        }
        if (maxWEnabled && finalW > maxWVal) {
          finalW = maxWVal;
          finalH = Math.round(maxWVal / originalRatio);
        }
        if (maxHEnabled && finalH > maxHVal) {
          finalH = maxHVal;
          finalW = Math.round(maxHVal * originalRatio);
        }
      } else {
        if (minWEnabled && finalW < minWVal) finalW = minWVal;
        if (maxWEnabled && finalW > maxWVal) finalW = maxWVal;
        if (minHEnabled && finalH < minHVal) finalH = minHVal;
        if (maxHEnabled && finalH > maxHVal) finalH = maxHVal;
      }

      return {
        item,
        originalRatio,
        w: finalW,
        h: finalH
      };
    });

    const computedLayouts = new Map<string, { x: number; y: number; w: number; h: number }>();

    if (gridMode === 'fixed_gap_h') {
      const numCols = columns;
      const numRows = Math.ceil(sizedItems.length / numCols);
      let currentY = anchorY;

      for (let r = 0; r < numRows; r++) {
        const rowItems = sizedItems.slice(r * numCols, (r + 1) * numCols);
        if (rowItems.length === 0) continue;

        const rowTallest = Math.max(...rowItems.map(si => si.h));
        let previousLeft = anchorX;

        rowItems.forEach((si, c) => {
          let elementLeft = previousLeft;
          if (c > 0) {
            elementLeft = previousLeft + spacing;
          }

          let elementTop = currentY;
          if (vAlign === 'middle') {
            elementTop = currentY + (rowTallest - si.h) / 2;
          } else if (vAlign === 'bottom') {
            elementTop = currentY + rowTallest - si.h;
          }

          computedLayouts.set(si.item.id, {
            x: Math.round(elementLeft),
            y: Math.round(elementTop),
            w: Math.round(si.w),
            h: Math.round(si.h)
          });

          previousLeft = elementLeft + si.w;
        });

        currentY += rowTallest + spacing;
      }
    } else if (gridMode === 'fixed_gap_v') {
      const rowsPerCol = Math.ceil(sizedItems.length / columns);
      const numColsCalculated = Math.ceil(sizedItems.length / rowsPerCol);
      let currentX = anchorX;

      for (let c = 0; c < numColsCalculated; c++) {
        const colItems = sizedItems.slice(c * rowsPerCol, (c + 1) * rowsPerCol);
        if (colItems.length === 0) continue;

        const colWidest = Math.max(...colItems.map(si => si.w));
        let previousTop = anchorY;

        colItems.forEach((si, r) => {
          let elementTop = previousTop;
          if (r > 0) {
            elementTop = previousTop + spacing;
          }

          let elementLeft = currentX;
          if (hAlign === 'center') {
            elementLeft = currentX + (colWidest - si.w) / 2;
          } else if (hAlign === 'right') {
            elementLeft = currentX + colWidest - si.w;
          }

          computedLayouts.set(si.item.id, {
            x: Math.round(elementLeft),
            y: Math.round(elementTop),
            w: Math.round(si.w),
            h: Math.round(si.h)
          });

          previousTop = elementTop + si.h;
        });

        currentX += colWidest + spacing;
      }
    } else if (gridMode === 'optimal_vertical') {
      const numCols = columns;
      const colHeights = Array(numCols).fill(anchorY);
      const colItemsCount = Array(numCols).fill(0);

      sizedItems.forEach((si) => {
        let targetColIdx = 0;
        let minColY = Infinity;
        for (let c = 0; c < numCols; c++) {
          if (colHeights[c] < minColY) {
            minColY = colHeights[c];
            targetColIdx = c;
          }
        }

        const cellLeft = anchorX + targetColIdx * (targetW + spacing);
        const cellTop = colHeights[targetColIdx];
        const itemTop = colItemsCount[targetColIdx] > 0 ? cellTop + spacing : cellTop;

        let elementLeft = cellLeft;
        if (hAlign === 'center') {
          elementLeft = cellLeft + (targetW - si.w) / 2;
        } else if (hAlign === 'right') {
          elementLeft = cellLeft + targetW - si.w;
        }

        computedLayouts.set(si.item.id, {
          x: Math.round(elementLeft),
          y: Math.round(itemTop),
          w: Math.round(si.w),
          h: Math.round(si.h)
        });

        colHeights[targetColIdx] = itemTop + si.h;
        colItemsCount[targetColIdx]++;
      });
    } else if (gridMode === 'optimal_horizontal') {
      const designRows = gridModeVal;
      const rowWidths = Array(designRows).fill(anchorX);
      const rowItemsCount = Array(designRows).fill(0);

      sizedItems.forEach((si) => {
        let targetRowIdx = 0;
        let minRowX = Infinity;
        for (let r = 0; r < designRows; r++) {
          if (rowWidths[r] < minRowX) {
            minRowX = rowWidths[r];
            targetRowIdx = r;
          }
        }

        const cellTop = anchorY + targetRowIdx * (targetH + spacing);
        const cellLeft = rowWidths[targetRowIdx];
        const itemLeft = rowItemsCount[targetRowIdx] > 0 ? cellLeft + spacing : cellLeft;

        let elementTop = cellTop;
        if (vAlign === 'middle') {
          elementTop = cellTop + (targetH - si.h) / 2;
        } else if (vAlign === 'bottom') {
          elementTop = cellTop + targetH - si.h;
        }

        computedLayouts.set(si.item.id, {
          x: Math.round(itemLeft),
          y: Math.round(elementTop),
          w: Math.round(si.w),
          h: Math.round(si.h)
        });

        rowWidths[targetRowIdx] = itemLeft + si.w;
        rowItemsCount[targetRowIdx]++;
      });
    } else {
      const numCols = columns;
      const numRows = Math.ceil(totalSelected / numCols);

      sizedItems.forEach((si, index) => {
        let cIdx = 0;
        let rIdx = 0;

        if (flowDirection === 'horizontal') {
          cIdx = index % numCols;
          rIdx = Math.floor(index / numCols);
        } else {
          rIdx = index % numRows;
          cIdx = Math.floor(index / numRows);
        }

        const cellLeft = anchorX + cIdx * (targetW + spacing);
        const cellTop = anchorY + rIdx * (targetH + spacing);

        let elementLeft = cellLeft;
        if (hAlign === 'center') {
          elementLeft = cellLeft + (targetW - si.w) / 2;
        } else if (hAlign === 'right') {
          elementLeft = cellLeft + targetW - si.w;
        }

        let elementTop = cellTop;
        if (vAlign === 'middle') {
          elementTop = cellTop + (targetH - si.h) / 2;
        } else if (vAlign === 'bottom') {
          elementTop = cellTop + targetH - si.h;
        }

        computedLayouts.set(si.item.id, {
          x: Math.round(elementLeft),
          y: Math.round(elementTop),
          w: Math.round(si.w),
          h: Math.round(si.h)
        });
      });
    }

    setItems(prev => {
      return prev.map(item => {
        if (!item.selected) {
          return item;
        }
        const layout = computedLayouts.get(item.id);
        if (!layout) return item;
        return {
          ...item,
          x: layout.x,
          y: layout.y,
          w: layout.w,
          h: layout.h,
          rotation: 0
        };
      });
    });

    if (!quiet) {
      triggerToast(`Aligned and scaled ${totalSelected} elements successfully!`);
    }
  };

  // Manual Drag and drop mouse event handlers inside Artboard
  const handleArtboardMouseDown = (e: React.MouseEvent) => {
    // If clicking directly on empty Artboard background, clear selection unless shift key is pressed
    if (e.target === e.currentTarget || (e.target as HTMLElement).id === 'artboard-bg') {
      if (!e.shiftKey) {
        setItems(prev => prev.map(item => ({ ...item, selected: false })));
        triggerToast('Deselected elements');
      }
    }
  };

  const handleItemMouseDown = (e: React.MouseEvent, item: ArtItem) => {
    e.stopPropagation();
    if (selectedTool !== 'select') return;

    // Toggle selected if holding shift
    if (e.shiftKey) {
      setItems(prev =>
        prev.map(it => (it.id === item.id ? { ...it, selected: !it.selected } : it))
      );
      return;
    }

    // If wasn't selected, select this single item
    if (!item.selected) {
      setItems(prev =>
        prev.map(it => (it.id === item.id ? { ...it, selected: true } : { ...it, selected: false }))
      );
    }

    // Log offsets for dragging
    if (artboardRef.current) {
      const bounds = artboardRef.current.getBoundingClientRect();
      const clickX = e.clientX - bounds.left;
      const clickY = e.clientY - bounds.top;
      setDraggedId(item.id);
      setDragOffset({
        x: clickX - item.x,
        y: clickY - item.y
      });
    }
  };

  const handleArtboardMouseMove = (e: React.MouseEvent) => {
    if (!draggedId || selectedTool !== 'select') return;

    if (artboardRef.current) {
      const bounds = artboardRef.current.getBoundingClientRect();
      const currentX = e.clientX - bounds.left;
      const currentY = e.clientY - bounds.top;

      const newX = Math.max(0, Math.min(590, currentX - dragOffset.x));
      const newY = Math.max(0, Math.min(440, currentY - dragOffset.y));

      setItems(prev =>
        prev.map(it => (it.id === draggedId ? { ...it, x: newX, y: newY } : it))
      );
    }
  };

  const handleArtboardMouseUp = () => {
    setDraggedId(null);
    selectionAnchorRef.current = null; // reset anchor on drag end
  };

  // Helper values for guides
  const calculatedGuideCells = useMemo(() => {
    if (numSelected < 2 || !showGuides) return [];

    let minX = Infinity;
    let minY = Infinity;

    selectedItems.forEach(item => {
      if (item.x < minX) minX = item.x;
      if (item.y < minY) minY = item.y;
    });

    if (selectionAnchorRef.current === null && minX !== Infinity && minY !== Infinity) {
      selectionAnchorRef.current = { x: minX, y: minY };
    }

    const anchorX = selectionAnchorRef.current ? selectionAnchorRef.current.x : minX;
    const anchorY = selectionAnchorRef.current ? selectionAnchorRef.current.y : minY;

    const targetW = (sizingStrategy === 'average' ? averages.w : manualW) * (scale / 100);
    const targetH = (sizingStrategy === 'average' ? averages.h : manualH) * (scale / 100);

    const totalSelected = numSelected;
    const numCols = columns;
    const numRows = Math.ceil(totalSelected / numCols);

    // Visual sort order matches applyGridLayout exactly
    const sortedSelected = [...selectedItems].sort((a, b) => {
      const centerY_A = a.y + a.h / 2;
      const centerY_B = b.y + b.h / 2;
      const centerX_A = a.x + a.w / 2;
      const centerX_B = b.x + b.w / 2;
      if (Math.abs(centerY_A - centerY_B) > 30) {
        return centerY_A - centerY_B;
      }
      return centerX_A - centerX_B;
    });

    // 1. Sizing phase
    const sizedItems = sortedSelected.map((item) => {
      const originalRatio = item.initialW / item.initialH;
      let finalW = targetW;
      let finalH = targetH;

      if (lockRatio) {
        if (aspectRatioMode === 'fit') {
          const cellRatio = targetW / targetH;
          if (originalRatio > cellRatio) {
            finalW = targetW;
            finalH = Math.round(targetW / originalRatio);
          } else {
            finalH = targetH;
            finalW = Math.round(targetH * originalRatio);
          }
        } else if (aspectRatioMode === 'width') {
          finalW = targetW;
          finalH = Math.round(targetW / originalRatio);
        } else if (aspectRatioMode === 'height') {
          finalH = targetH;
          finalW = Math.round(targetH * originalRatio);
        } else if (aspectRatioMode === 'optimal_vertical') {
          if (originalRatio >= 1.0) {
            finalW = targetW;
            finalH = Math.round(targetW / originalRatio);
          } else {
            finalH = targetW;
            finalW = Math.round(targetW * originalRatio);
          }
        } else if (aspectRatioMode === 'optimal_horizontal') {
          if (originalRatio >= 1.0) {
            finalH = targetW;
            finalW = Math.round(targetW * originalRatio);
          } else {
            finalW = targetW;
            finalH = Math.round(targetW / originalRatio);
          }
        }
      }

      // Apply Dimension limit bounds
      if (lockRatio) {
        if (minWEnabled && finalW < minWVal) {
          finalW = minWVal;
          finalH = Math.round(minWVal / originalRatio);
        }
        if (minHEnabled && finalH < minHVal) {
          finalH = minHVal;
          finalW = Math.round(minHVal * originalRatio);
        }
        if (maxWEnabled && finalW > maxWVal) {
          finalW = maxWVal;
          finalH = Math.round(maxWVal / originalRatio);
        }
        if (maxHEnabled && finalH > maxHVal) {
          finalH = maxHVal;
          finalW = Math.round(maxHVal * originalRatio);
        }
      } else {
        if (minWEnabled && finalW < minWVal) finalW = minWVal;
        if (maxWEnabled && finalW > maxWVal) finalW = maxWVal;
        if (minHEnabled && finalH < minHVal) finalH = minHVal;
        if (maxHEnabled && finalH > maxHVal) finalH = maxHVal;
      }

      return {
        item,
        originalRatio,
        w: finalW,
        h: finalH
      };
    });

    const cellsCoords: any[] = [];

    // 2. Placing phase (matches applyGridLayout exactly)
    if (gridMode === 'fixed_gap_h') {
      let currentY = anchorY;
      for (let r = 0; r < numRows; r++) {
        const rowItems = sizedItems.slice(r * numCols, (r + 1) * numCols);
        if (rowItems.length === 0) continue;

        const rowTallest = Math.max(...rowItems.map(si => si.h));
        let previousLeft = anchorX;

        rowItems.forEach((si, c) => {
          let elementLeft = previousLeft;
          if (c > 0) {
            elementLeft = previousLeft + spacing;
          }

          let elementTop = currentY;
          if (vAlign === 'middle') {
            elementTop = currentY + (rowTallest - si.h) / 2;
          } else if (vAlign === 'bottom') {
            elementTop = currentY + rowTallest - si.h;
          }

          cellsCoords.push({
            id: `guide-cell-${r}-${c}`,
            left: elementLeft,
            top: elementTop,
            width: si.w,
            height: si.h,
            col: c,
            row: r
          });

          previousLeft = elementLeft + si.w;
        });

        currentY += rowTallest + spacing;
      }
    } else if (gridMode === 'fixed_gap_v') {
      const rowsPerCol = Math.ceil(sizedItems.length / columns);
      const numColsCalculated = Math.ceil(sizedItems.length / rowsPerCol);
      let currentX = anchorX;

      for (let c = 0; c < numColsCalculated; c++) {
        const colItems = sizedItems.slice(c * rowsPerCol, (c + 1) * rowsPerCol);
        if (colItems.length === 0) continue;

        const colWidest = Math.max(...colItems.map(si => si.w));
        let previousTop = anchorY;

        colItems.forEach((si, r) => {
          let elementTop = previousTop;
          if (r > 0) {
            elementTop = previousTop + spacing;
          }

          let elementLeft = currentX;
          if (hAlign === 'center') {
            elementLeft = currentX + (colWidest - si.w) / 2;
          } else if (hAlign === 'right') {
            elementLeft = currentX + colWidest - si.w;
          }

          cellsCoords.push({
            id: `guide-cell-${c}-${r}`,
            left: elementLeft,
            top: elementTop,
            width: si.w,
            height: si.h,
            col: c,
            row: r
          });

          previousTop = elementTop + si.h;
        });

        currentX += colWidest + spacing;
      }
    } else if (gridMode === 'optimal_vertical') {
      const colHeights = Array(numCols).fill(anchorY);
      const colItemsCount = Array(numCols).fill(0);

      sizedItems.forEach((si, j) => {
        let targetColIdx = 0;
        let minColY = Infinity;
        for (let c = 0; c < numCols; c++) {
          if (colHeights[c] < minColY) {
            minColY = colHeights[c];
            targetColIdx = c;
          }
        }

        const colLeft = anchorX + targetColIdx * (targetW + spacing);
        const colTop = colHeights[targetColIdx];
        const itemTop = colItemsCount[targetColIdx] > 0 ? colTop + spacing : colTop;

        cellsCoords.push({
          id: `guide-cell-${j}`,
          left: colLeft,
          top: itemTop,
          width: si.w,
          height: si.h,
          col: targetColIdx,
          row: colItemsCount[targetColIdx]
        });

        colHeights[targetColIdx] = itemTop + si.h;
        colItemsCount[targetColIdx]++;
      });
    } else if (gridMode === 'optimal_horizontal') {
      const designRows = gridModeVal;
      const rowWidths = Array(designRows).fill(anchorX);
      const rowItemsCount = Array(designRows).fill(0);

      sizedItems.forEach((si, j) => {
        let targetRowIdx = 0;
        let minRowX = Infinity;
        for (let r = 0; r < designRows; r++) {
          if (rowWidths[r] < minRowX) {
            minRowX = rowWidths[r];
            targetRowIdx = r;
          }
        }

        const rowTop = anchorY + targetRowIdx * (targetH + spacing);
        const rowLeft = rowWidths[targetRowIdx];
        const itemLeft = rowItemsCount[targetRowIdx] > 0 ? rowLeft + spacing : rowLeft;

        cellsCoords.push({
          id: `guide-cell-${j}`,
          left: itemLeft,
          top: rowTop,
          width: si.w,
          height: si.h,
          col: rowItemsCount[targetRowIdx],
          row: targetRowIdx
        });

        rowWidths[targetRowIdx] = itemLeft + si.w;
        rowItemsCount[targetRowIdx]++;
      });
    } else {
      sizedItems.forEach((si, index) => {
        let cIdx = 0;
        let rIdx = 0;

        if (flowDirection === 'horizontal') {
          cIdx = index % numCols;
          rIdx = Math.floor(index / numCols);
        } else {
          rIdx = index % numRows;
          cIdx = Math.floor(index / numRows);
        }

        const cellLeft = anchorX + cIdx * (targetW + spacing);
        const cellTop = anchorY + rIdx * (targetH + spacing);

        cellsCoords.push({
          id: `guide-cell-${index}`,
          left: cellLeft,
          top: cellTop,
          width: targetW,
          height: targetH,
          col: cIdx,
          row: rIdx
        });
      });
    }

    return cellsCoords;
  }, [numSelected, selectedItems, columns, spacing, scale, flowDirection, showGuides, sizingStrategy, averages, manualW, manualH, gridMode, gridModeVal, lockRatio, aspectRatioMode, minWEnabled, minWVal, maxWEnabled, maxWVal, minHEnabled, minHVal, maxHEnabled, maxHVal, hAlign, vAlign]);

  useEffect(() => {
    if (constrainManual && manualH > 0) {
      lastRatioRef.current = manualW / manualH;
    }
  }, [constrainManual]);

  // Handle direct custom input width/height scale adjustments
  const handleManualResize = (dimension: 'w' | 'h', val: number) => {
    if (dimension === 'w') {
      setManualW(val);
      if (constrainManual) {
        const ratio = lastRatioRef.current || 1.0;
        setManualH(Math.round(val / ratio) || 1);
      }
    } else {
      setManualH(val);
      if (constrainManual) {
        const ratio = lastRatioRef.current || 1.0;
        setManualW(Math.round(val * ratio) || 1);
      }
    }
  };

  return (
    <div className="flex flex-col h-screen w-full bg-[#1A1A1A] text-gray-200 font-sans overflow-hidden select-none" id="main-frame">
      
      {/* Toast Alert Notification */}
      {toastMessage && (
        <div className="absolute top-12 left-1/2 transform -translate-x-1/2 bg-blue-600 border border-blue-400 text-white px-4 py-2 rounded-md shadow-2xl z-50 text-xs font-semibold flex items-center gap-2 animate-bounce">
          <Sparkle className="w-4 h-4 text-yellow-300 animate-spin" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Adobe Illustrator Simulation Header */}
      <div className="h-10 bg-[#2D2D2D] border-b border-[#141414] flex items-center px-4 justify-between" id="app-header">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-[#FF9A00] rounded flex items-center justify-center text-[#1E1E1E] font-bold text-xs shadow-inner">
              Ai
            </div>
            <span className="text-xs font-bold tracking-wide text-neutral-100">Adobe Illustrator</span>
            <span className="text-[10px] bg-neutral-800 text-neutral-400 px-1.5 py-0.5 rounded-full border border-neutral-700">
              Interactive Dev Workspace
            </span>
          </div>
          
          <div className="hidden md:flex gap-4 text-[11px] text-gray-400">
            <span className="hover:text-white transition-colors cursor-pointer">File</span>
            <span className="hover:text-white transition-colors cursor-pointer text-white underline underline-offset-4 decoration-amber-500 font-medium">window</span>
            <span className="hover:text-white transition-colors cursor-pointer">Edit</span>
            <span className="hover:text-white transition-colors cursor-pointer">Object</span>
            <span className="hover:text-[#FF9A00] transition-colors cursor-pointer flex items-center gap-1 font-semibold text-neutral-300">
              Extensions <ChevronRight className="w-3 h-3" /> GridMaster Pro
            </span>
          </div>
        </div>
        
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-2 bg-neutral-800 px-3 py-1 rounded text-[10px] border border-neutral-700 text-neutral-300">
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block"></span>
            Simulator Connected
          </div>
        </div>
      </div>

      {/* Main Core Layout: Sidebar Tools, Artboard, Plugin and Code Boards */}
      <div className="flex flex-1 overflow-hidden" id="workspace-layout">
        
        {/* Left Side Illustrator Tool Dock */}
        <div className="w-12 bg-[#262626] border-r border-[#141414] flex flex-col items-center py-4 gap-3 text-neutral-400" id="illustrator-toolbar">
          <button
            onClick={() => { setSelectedTool('select'); triggerToast('Switched to Selection Tool (V)'); }}
            title="Selection Tool (V) - Click objects to select, drag to reposition."
            className={`p-2 rounded-lg transition-all ${selectedTool === 'select' ? 'bg-[#3E82F6] text-white shadow-lg' : 'hover:bg-neutral-800 hover:text-white'}`}
          >
            <MousePointer className="w-4 h-4" />
          </button>
          
          <button
            onClick={() => { setSelectedTool('direct'); triggerToast('Switched to Direct Selection Tool (A)'); }}
            title="Direct Selection Tool (A)"
            className={`p-2 rounded-lg transition-all ${selectedTool === 'direct' ? 'bg-[#3E82F6] text-white' : 'hover:bg-neutral-800 hover:text-white'}`}
          >
            <Layers className="w-4 h-4" />
          </button>

          <button
            onClick={() => { setSelectedTool('hand'); triggerToast('Switched to Hand Tool (H) - Drag Artboard view'); }}
            title="Hand Tool (H) - Drag View"
            className={`p-2 rounded-lg transition-all ${selectedTool === 'hand' ? 'bg-[#3E82F6] text-white' : 'hover:bg-neutral-800 hover:text-white'}`}
          >
            <Hand className="w-4 h-4" />
          </button>
          
          <div className="border-t border-neutral-700 w-6 my-1"></div>

          <button
            onClick={scatterItems}
            title="Scramble & Scatter Items - Breaks layout and randomizes sizes to test plugin functionality."
            className="p-2 rounded-lg hover:bg-neutral-800 hover:text-[#EF4444] transition-all flex flex-col items-center gap-0.5"
          >
            <RefreshCw className="w-4 h-4 text-amber-500 animate-spin-slow" />
            <span className="text-[7px] text-amber-400">Scramble</span>
          </button>

          <button
            onClick={selectAllItems}
            title="Select All items"
            className="p-1 px-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-[9px] font-semibold text-neutral-300 mt-2"
          >
            ALL
          </button>

          <button
            onClick={deselectAllItems}
            title="Deselect All items"
            className="p-1 px-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-[9px] font-semibold text-neutral-400"
          >
            CLR
          </button>
        </div>

        {/* Center Sandbox: Displays the Interactive Artboard Canvas + Interactive guides */}
        <div className="flex-1 bg-[#1E1E1E] relative flex flex-col overflow-hidden" id="sandbox-viewport">
          
          {/* Top Info Context Banner */}
          <div className="bg-[#242424] border-b border-[#141414] px-4 py-1.5 text-xs text-neutral-400 flex justify-between items-center select-none shrink-0">
            <div className="flex items-center gap-4">
              <span className="text-neutral-300 font-medium">Demo artboard.ai * @ 85% (RGB/Preview)</span>
              <span className="text-[10px] text-neutral-500">| Standard coordinate points measurements (pt)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[11px]">Show Guides:</span>
              <button
                onClick={() => setShowGuides(!showGuides)}
                className={`w-8 h-4 rounded-full relative transition-all ${showGuides ? 'bg-blue-600' : 'bg-neutral-700'}`}
              >
                <span className={`absolute top-0.5 left-0.5 w-3 h-3 bg-white rounded-full transition-all ${showGuides ? 'translate-x-4' : 'translate-x-0'}`}></span>
              </button>
            </div>
          </div>

          <div
            className="flex-1 overflow-auto flex items-center justify-center p-8 relative min-h-[480px]"
            id="artboard-scroll-area"
          >
            <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-5 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:16px_16px]"></div>

            {/* Simulated Desktop Artboard Frame */}
            <div className="relative">
              
              {/* Floating ruler margins indicator (X and Y axis) */}
              <div className="absolute -top-6 left-0 right-0 h-5 bg-[#262626]/80 text-[#888] rounded px-2 text-[9px] flex items-center justify-between border border-neutral-800 tracking-wider">
                <span>0pt</span>
                <span>100pt</span>
                <span>200pt</span>
                <span>300pt</span>
                <span>400pt</span>
                <span>500pt</span>
                <span>600pt</span>
              </div>
              <div className="absolute -left-7 top-0 bottom-0 w-5 bg-[#262626]/80 text-[#888] rounded py-2 text-[9px] flex flex-col justify-between items-center border border-neutral-800 tracking-wider">
                <span>0pt</span>
                <span>100pt</span>
                <span>200pt</span>
                <span>300pt</span>
                <span>400pt</span>
              </div>

              {/* The "Illustrator Artboard" Canvas container */}
              <div
                ref={artboardRef}
                onMouseMove={handleArtboardMouseMove}
                onMouseUp={handleArtboardMouseUp}
                onMouseDown={handleArtboardMouseDown}
                className="w-[600px] h-[400px] bg-white border border-neutral-300 shadow-2xl relative overflow-hidden flex transition-all duration-300"
                style={{ cursor: selectedTool === 'hand' ? 'grab' : 'default' }}
                id="adobe-artboard"
              >
                {/* Visual Artboard Background grid */}
                <div id="artboard-bg" className="absolute inset-0 bg-[#FAFAFA] transition-colors"></div>

                {/* Simulated Guideline Cells dashed rectangles */}
                {calculatedGuideCells.map(cell => (
                  <div
                    key={cell.id}
                    className="absolute border border-dashed border-blue-400 bg-blue-50/20 rounded pointer-events-none transition-all duration-300"
                    style={{
                      left: `${cell.left}px`,
                      top: `${cell.top}px`,
                      width: `${cell.width}px`,
                      height: `${cell.height}px`,
                      zIndex: 10
                    }}
                  >
                    {/* Index labels centered relative to simulated cells */}
                    <span className="absolute bottom-1 right-2 text-[8px] text-blue-500 font-mono tracking-tighter select-none">
                      Cell {cell.row + 1}-{cell.col + 1}
                    </span>
                  </div>
                ))}

                {/* Render the actual vector shapes/mock images */}
                {items.map(item => {
                  const keepAspectColor = item.selected ? 'rgba(59, 130, 246, 0.15)' : 'transparent';
                  return (
                    <div
                      key={item.id}
                      onMouseDown={(e) => handleItemMouseDown(e, item)}
                      className={`absolute select-none cursor-pointer group transition-all duration-300 ${item.selected ? 'z-30' : 'z-20'}`}
                      style={{
                        left: `${item.x}px`,
                        top: `${item.y}px`,
                        width: `${item.w}px`,
                        height: `${item.h}px`,
                        transform: `rotate(${item.rotation}deg)`,
                      }}
                      id={`item-box-${item.id}`}
                    >
                      {/* Bounding box wrapper with corner handles for selected elements */}
                      {item.selected && (
                        <>
                          <div className="absolute inset-0 border-2 border-blue-500 pointer-events-none z-10" />
                          {/* Anchor squares on vertices */}
                          <div className="absolute -top-1.5 -left-1.5 w-3 h-3 bg-white border-2 border-blue-600 rounded-sm z-20 pointer-events-none" />
                          <div className="absolute -top-1.5 -right-1.5 w-3 h-3 bg-white border-2 border-blue-600 rounded-sm z-20 pointer-events-none" />
                          <div className="absolute -bottom-1.5 -left-1.5 w-3 h-3 bg-white border-2 border-blue-600 rounded-sm z-20 pointer-events-none" />
                          <div className="absolute -bottom-1.5 -right-1.5 w-3 h-3 bg-white border-2 border-blue-600 rounded-sm z-20 pointer-events-none" />
                          {/* Anchor middle sizing handle */}
                          <div className="absolute top-1/2 -left-1.5 transform -translate-y-1/2 w-2.5 h-2.5 bg-white border border-blue-600 z-20 pointer-events-none" />
                          <div className="absolute top-1/2 -right-1.5 transform -translate-y-1/2 w-2.5 h-2.5 bg-white border border-blue-600 z-20 pointer-events-none" />
                        </>
                      )}

                      {/* Content of the Graphics Card */}
                      <div
                        className="w-full h-full relative rounded flex flex-col justify-between overflow-hidden shadow-sm hover:shadow-md transition-shadow"
                        style={{
                          background: `linear-gradient(135deg, ${item.color}30 0%, ${item.color}15 100%)`,
                          border: `1.5px solid ${item.selected ? '#3B82F6' : item.color + 'bb'}`,
                        }}
                      >
                        {/* Selected overlay indicator badge */}
                        <div className="absolute top-1 left-1.5 flex items-center gap-1 z-10">
                          <input
                            type="checkbox"
                            checked={item.selected}
                            onChange={(e) => toggleSelection(e as any, item.id)}
                            className="w-3.5 h-3.5 rounded accent-blue-600 cursor-pointer shadow border-neutral-300"
                          />
                          <span className="text-[8px] bg-black/60 text-white font-mono rounded px-1 scale-90 origin-left">
                            {item.w} x {item.h}pt
                          </span>
                        </div>

                        {/* Centered Graphic Detail depending on the vector asset type */}
                        <div className="flex-1 flex items-center justify-center p-3 relative" style={{ color: item.color }}>
                          
                          {item.type === 'star' && (
                            <div className="relative animate-pulse-slow">
                              <Shapes className="w-10 h-10 drop-shadow" />
                              <div className="absolute inset-0 flex items-center justify-center text-[10px] font-bold text-white">⭐</div>
                            </div>
                          )}

                          {item.type === 'landscape' && (
                            <svg viewBox="0 0 100 60" className="w-16 h-12 drop-shadow">
                              <path d="M10,50 L40,20 L60,40 L85,15 L95,50 Z" fill={item.color} opacity="0.6" />
                              <circle cx="75" cy="20" r="8" fill="#FBBF24" />
                            </svg>
                          )}

                          {item.type === 'flower' && (
                            <div className="text-center">
                              <span className="text-2xl drop-shadow">🌸</span>
                            </div>
                          )}

                          {item.type === 'crest' && (
                            <div className="w-12 h-14 border-2 rounded-t-xl rounded-b-3xl flex items-center justify-center relative shadow-inner" style={{ borderColor: item.color }}>
                              <span className="text-xs font-bold font-serif" style={{ color: item.secondaryColor }}>Ai</span>
                            </div>
                          )}

                          {item.type === 'badge' && (
                            <div className="w-12 h-12 rounded-full border-4 border-dashed flex items-center justify-center" style={{ borderColor: item.color }}>
                              <span className="text-[9px] font-bold tracking-tight text-amber-600 uppercase">Pro</span>
                            </div>
                          )}

                          {item.type === 'tech' && (
                            <svg viewBox="0 0 100 100" className="w-12 h-12">
                              <polygon points="50,10 90,30 90,70 50,90 10,70 10,30" fill="none" stroke={item.color} strokeWidth="6" />
                              <circle cx="50" cy="50" r="16" fill={item.secondaryColor} />
                            </svg>
                          )}

                          {item.type === 'custom_shape' && (
                            <div className="w-14 h-8 bg-current rounded-sm opacity-80 skew-x-12 flex items-center justify-center relative">
                              <span className="text-[9.5px] font-mono text-white tracking-widest text-center block skew-x-[-12deg]">VECTOR</span>
                            </div>
                          )}
                        </div>

                        {/* Bottom Asset Footer */}
                        <div className="h-4 bg-black/60 backdrop-blur-xs text-[7px] text-white/90 font-mono px-1 flex items-center justify-between z-10 select-none">
                          <span className="truncate max-w-[80%]">{item.name}</span>
                          <span className="text-blue-400 font-bold scale-90">
                            {Math.round((item.initialW / item.initialH) * 100) / 100}r
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Selection Summary Overlay below the artboard */}
              <div className="absolute -bottom-8 left-0 text-[11px] text-neutral-400 font-mono select-none flex items-center gap-2">
                <span>Selection:</span>
                <span className="text-blue-400 font-bold">{numSelected} / {items.length} elements</span>
                <span>|</span>
                <span>Avg Bounds size:</span>
                <span className="text-amber-400 font-bold">{averages.w}pt x {averages.h}pt</span>
              </div>
            </div>

          </div>

          {/* Collapsible IDE Code Board Exporter Drawer */}
          <div className="h-64 bg-[#1E1E1E] border-t border-[#141414] flex flex-col shrink-0" id="code-panel">
            <div className="h-8 bg-[#2C2C2C] border-b border-[#141414] px-4 flex items-center justify-between selection:bg-neutral-800">
              {/* Left Group containing CodeSection Selectors */}
              <div className="flex items-center gap-3 text-xs">
                <Code className="w-4 h-4 text-amber-600" />
                <div className="flex bg-[#141414] rounded p-0.5 border border-neutral-800" id="code-installer-toggles">
                  <button
                    onClick={() => setCodeSection('code')}
                    className={`px-3 py-1 text-[10px] font-bold rounded transition-colors ${codeSection === 'code' ? 'bg-[#3E3E3E] text-white shadow-sm' : 'text-neutral-500 hover:text-neutral-300'}`}
                  >
                    🔍 Raw Plugin Code
                  </button>
                  <button
                    onClick={() => {
                      setCodeSection('installer');
                      triggerToast("Opened Illustrator V2025 Auto-Installer Tab!");
                    }}
                    className={`px-3 py-1 text-[10px] font-extrabold rounded transition-colors flex items-center gap-1 ${codeSection === 'installer' ? 'bg-[#FF9A00]/20 text-[#FF9A00] border border-amber-500/30' : 'text-neutral-500 hover:text-neutral-300'}`}
                    id="installer-tab-btn"
                  >
                    ⚡ 1-Click Installer &amp; Guide
                  </button>
                </div>
              </div>

              {/* Center/Right controls depend on the chosen view */}
              {codeSection === 'code' ? (
                <>
                  {/* Code Selection Tabs */}
                  <div className="flex bg-[#141414] rounded p-0.5" id="script-types-selector">
                    <button
                      onClick={() => setScriptType('jsx')}
                      className={`px-2.5 py-1 text-[10px] font-bold rounded transition-colors ${scriptType === 'jsx' ? 'bg-[#3E3E3E] text-white shadow-sm' : 'text-neutral-500 hover:text-neutral-300'}`}
                    >
                      Traditional ExtendScript (.jsx)
                    </button>
                    <button
                      onClick={() => setScriptType('uxp')}
                      className={`px-2.5 py-1 text-[10px] font-bold rounded transition-colors ${scriptType === 'uxp' ? 'bg-[#3E3E3E] text-white shadow-sm' : 'text-neutral-500 hover:text-neutral-300'}`}
                    >
                      Modern UXP Script (.js)
                    </button>
                  </div>

                  <button
                    onClick={copyScriptToClipboard}
                    className="bg-neutral-850 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 px-3 py-1 rounded text-[11px] font-semibold flex items-center gap-1.5 transition-colors"
                    id="copy-script-btn"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5 text-amber-400" />}
                    {copied ? 'Copied!' : 'Copy Script Code'}
                  </button>
                </>
              ) : (
                <div className="flex gap-2">
                  <span className="text-[10px] text-neutral-400 self-center hidden sm:inline">Active Version: <b className="text-amber-400">Adobe Illustrator V2025 COMPATIBLE</b></span>
                  <button
                    onClick={downloadJSX}
                    className="bg-neutral-800 hover:bg-[#FF9A00] hover:text-black border border-neutral-700 px-2.5 py-1 rounded text-[11px] font-semibold flex items-center gap-1 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" /> Download .jsx
                  </button>
                </div>
              )}
            </div>

            {/* Core Box Content */}
            {codeSection === 'code' ? (
              <div className="flex-1 overflow-auto bg-[#151515] p-3 text-xs font-mono text-neutral-300 relative">
                <div className="absolute right-4 top-2 text-[10px] bg-neutral-900 text-neutral-500 px-2 py-0.5 rounded pointer-events-none border border-neutral-800">
                  {scriptType === 'jsx' ? 'ES3 JavaScript Compliant' : 'Modern UXP Framework'}
                </div>
                <pre className="whitespace-pre-scroll select-text leading-relaxed">
                  {generatedScriptCode}
                </pre>
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto bg-[#161616] p-4 text-xs select-text">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
                  {/* Left Column: Handlers */}
                  <div className="md:col-span-4 flex flex-col gap-2.5 bg-[#232323] p-3.5 rounded border border-neutral-800 h-fit">
                    <span className="font-bold text-neutral-300 text-[10px] uppercase tracking-wider block border-b border-neutral-800 pb-1.5 text-center">
                      📥 Dynamic Installers
                    </span>

                    <button
                      onClick={downloadBAT}
                      className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold py-2 px-3 rounded text-[11px] flex items-center justify-center gap-1.5 shadow transition-colors border border-emerald-500/20"
                      title="For Windows users: Auto-detects and installs plug-in instantly. No directory-searching needed!"
                      id="down-bat-btn"
                    >
                      <FileCode className="w-4 h-4 text-emerald-200" /> Windows Auto-Installer (.bat)
                    </button>

                    <button
                      onClick={downloadPython}
                      className="w-full bg-blue-600 hover:bg-blue-500 text-white font-extrabold py-2 px-3 rounded text-[11px] flex items-center justify-center gap-1.5 shadow transition-colors border border-blue-500/20"
                      title="For Windows & Mac: GUI-driven installation package written in Tkinter."
                      id="down-py-btn"
                    >
                      <FolderOpen className="w-4 h-4 text-blue-200" /> Python GUI Installer (.py)
                    </button>

                    <button
                      onClick={downloadJSX}
                      className="w-full bg-neutral-800 hover:bg-neutral-700 text-[#F5F5F5] font-bold py-2 px-3 rounded text-[11px] flex items-center justify-center gap-1.5 border border-neutral-700 transition-colors"
                      id="down-jsx-btn"
                    >
                      <Download className="w-4 h-4 text-amber-500" /> Raw Script (.jsx)
                    </button>

                    <div className="bg-neutral-900/60 p-2 text-[10px] text-neutral-400 leading-normal border border-neutral-800/80 rounded">
                      💡 <b>Windows Administrator tool (.bat):</b> Configured with variables currently live in this browser screen! Runs with a double-click to install.
                    </div>
                  </div>

                  {/* Right Column: Step by step text directions */}
                  <div className="md:col-span-8 flex flex-col gap-2">
                    <span className="font-bold text-neutral-300 text-[11px] uppercase tracking-wider border-b border-neutral-805 pb-1">
                      📖 Interactive Setup Guide for Illustrator V2025
                    </span>

                    <div className="space-y-2.5 text-neutral-300 text-[11.5px] leading-relaxed">
                      {/* Step 1 */}
                      <div className="bg-[#1C1C1C] p-2.5 rounded border border-neutral-800">
                        <div className="flex gap-2 items-start">
                          <span className="w-5 h-5 rounded-full bg-blue-900/45 text-blue-300 font-extrabold flex items-center justify-center text-[10.5px] shrink-0 mt-0.5 border border-blue-800/30">1</span>
                          <div>
                            <span className="font-bold text-neutral-100 block">Automatic Installation (Recommended)</span>
                            <p className="text-[11px] text-neutral-400 mt-0.5">
                              Download <span className="text-emerald-400 font-semibold cursor-pointer underline" onClick={downloadBAT}>Windows Auto-Installer (.bat)</span>. Right-click that file on your local computer and choose <b>"Run as administrator"</b>. It will scan, target your <b>Illustrator 2025 Scripts Folder</b> automatically, and save the plugin.
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Step 2 */}
                      <div className="bg-[#1C1C1C] p-2.5 rounded border border-neutral-800">
                        <div className="flex gap-2 items-start">
                          <span className="w-5 h-5 rounded-full bg-amber-900/40 text-amber-300 font-extrabold flex items-center justify-center text-[10.5px] shrink-0 mt-0.5 border border-amber-800/30">2</span>
                          <div>
                            <span className="font-bold text-neutral-100 block">Manual Alternative (Windows &amp; macOS)</span>
                            <p className="text-[11px] text-neutral-400 mt-0.5">
                              Download the raw <span className="text-amber-400 font-semibold cursor-pointer underline" onClick={downloadJSX}>GridMasterPro.jsx</span> file and copy it directly to your Illustrator script presets location:
                            </p>
                            <div className="mt-1.5 space-y-1 font-mono text-[9.5px]">
                              <div className="p-1.5 bg-neutral-900 rounded border border-neutral-800 text-neutral-300 font-sans">
                                <b className="text-blue-400">Windows:</b> <code className="font-mono bg-neutral-950 px-1 py-0.5 rounded text-neutral-200">C:\Program Files\Adobe\Adobe Illustrator 2025\Presets\en_US\Scripts\</code>
                              </div>
                              <div className="p-1.5 bg-neutral-900 rounded border border-neutral-800 text-neutral-300 font-sans">
                                <b className="text-purple-400">macOS:</b> <code className="font-mono bg-neutral-950 px-1 py-0.5 rounded text-neutral-200">/Applications/Adobe Illustrator 2025/Presets.localized/[Language]/Scripts/</code>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Step 3 */}
                      <div className="bg-[#1C1C1C] p-2.5 rounded border border-neutral-800">
                        <div className="flex gap-2 items-start">
                          <span className="w-5 h-5 rounded-full bg-purple-900/35 text-purple-300 font-extrabold flex items-center justify-center text-[10.5px] shrink-0 mt-0.5 border border-purple-800/30">3</span>
                          <div>
                            <span className="font-bold text-neutral-100 block">First Launch in Illustrator</span>
                            <p className="text-[11px] text-neutral-400 mt-0.5">
                              Open or restart Adobe Illustrator. Arrange any vector arts, shapes, or logos you want positioned. Go to <b>File &gt; Scripts &gt; GridMasterPro</b> in your top application bar. The plugin popup panel will appear instantly to control and align everything with high performance!
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="h-5 bg-[#1C1C1C] border-t border-[#141414] px-4 flex items-center justify-between text-[9px] text-neutral-500">
              <span>💡 Adobe Illustrator SDK v2025 Compliant Scripts</span>
              <span>Active presets: locked proportions, optimized layout alignment</span>
            </div>
          </div>
        </div>

        {/* Plugin Config Panel (The requested GUI Panel) */}
        <div className="w-72 bg-[#2D2D2D] border-l border-[#141414] flex flex-col justify-between shrink-0" id="extension-panel">
          
          <div className="flex flex-col flex-1 overflow-y-auto">
            
            {/* Panel Tab Header */}
            <div className="h-8 bg-[#373737] px-3 flex items-center justify-between border-b border-[#141414] select-none shrink-0 text-gray-200">
              <div className="flex items-center gap-1.5">
                <Grid className="w-4 h-4 text-amber-500" />
                <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#FFF]">
                  GridMaster Pro
                </span>
                <span className="text-[8px] bg-amber-500/10 text-amber-400 border border-amber-500/30 px-1 rounded">v1.0.4</span>
              </div>
              <div className="flex gap-1">
                <div className="w-2.5 h-0.5 bg-neutral-400"></div>
                <div className="w-2.5 h-2.5 border border-neutral-400 rounded-xs"></div>
              </div>
            </div>

            {/* Settings Forms container */}
            <div className="p-4 flex flex-col gap-5 text-gray-100" id="panel-controls">
              
              {/* Presets & Configurations Block */}
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] text-neutral-400 uppercase font-bold tracking-widest">
                    Layout Presets
                  </label>
                  <span className="text-[8px] bg-amber-500/10 text-amber-500 border border-amber-500/30 px-1 rounded font-bold uppercase tracking-wider">
                    Settings Manager
                  </span>
                </div>
                
                <div className="flex flex-col gap-3 bg-neutral-900 p-3 rounded border border-neutral-800">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-[9px] text-neutral-400 font-bold uppercase tracking-wider block">
                      Saved Layouts
                    </label>
                    <div className="flex gap-1.5">
                      <select
                        value={activePresetIndex}
                        onChange={(e) => {
                          const idx = parseInt(e.target.value);
                          setActivePresetIndex(idx);
                          if (allPresets[idx]) {
                            applySettingsObject(allPresets[idx].settings);
                            triggerToast(`Applied preset: ${allPresets[idx].name}`);
                          }
                        }}
                        className="flex-1 bg-neutral-950 text-[11px] text-neutral-200 border border-neutral-800 rounded p-1 mb-1 font-medium font-sans h-7"
                      >
                        {allPresets.map((preset, index) => (
                          <option key={index} value={index}>
                            {index < DEFAULT_PRESETS.length ? '📦 ' : '⭐ '} {preset.name}
                          </option>
                        ))}
                      </select>

                      {activePresetIndex >= DEFAULT_PRESETS.length && (
                        <button
                          onClick={() => {
                            const presetToDelete = allPresets[activePresetIndex];
                            if (!presetToDelete) return;
                            const confirmDelete = window.confirm(`Are you sure you want to delete custom preset "${presetToDelete.name}"?`);
                            if (confirmDelete) {
                              const customIndex = activePresetIndex - DEFAULT_PRESETS.length;
                              const updated = [...presets];
                              updated.splice(customIndex, 1);
                              setPresets(updated);
                              localStorage.setItem('gridmaster_presets', JSON.stringify(updated));
                              setActivePresetIndex(0);
                              applySettingsObject(DEFAULT_PRESETS[0].settings);
                              triggerToast('Preset deleted successfully');
                            }
                          }}
                          className="bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-red-400 hover:text-red-300 rounded p-1.5 cursor-pointer h-7 flex items-center justify-center transition-all shadow-sm"
                          title="Delete Custom Preset"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Save New Preset Row */}
                  <div className="flex flex-col gap-1 pt-1.5 border-t border-neutral-800/80">
                    <label className="text-[9px] text-neutral-400 font-bold uppercase tracking-wider block">
                      Save Current Configuration
                    </label>
                    <div className="flex gap-1.5">
                      <input
                        type="text"
                        placeholder="Preset Name..."
                        value={newPresetName}
                        onChange={(e) => setNewPresetName(e.target.value)}
                        className="flex-1 bg-neutral-950 text-[11px] text-neutral-200 border border-neutral-800 rounded px-2 h-7 font-sans outline-none focus:border-blue-500 transition-colors"
                      />
                      <button
                        onClick={() => {
                          const name = newPresetName.trim();
                          if (!name) {
                            triggerToast('Please enter a preset name');
                            return;
                          }
                          const settings: AppSettings = {
                            gridMode,
                            gridModeVal,
                            constrainManual,
                            spacing,
                            scale,
                            flowDirection,
                            aspectRatioMode,
                            lockRatio,
                            hAlign,
                            vAlign,
                            sizingStrategy,
                            manualW,
                            manualH,
                            minWEnabled,
                            minWVal,
                            maxWEnabled,
                            maxWVal,
                            minHEnabled,
                            minHVal,
                            maxHEnabled,
                            maxHVal,
                          };

                          const newPreset: SavedPreset = { name, settings };
                          const updated = [...presets];
                          
                          const existingIndex = updated.findIndex(p => p.name.toLowerCase() === name.toLowerCase());
                          if (existingIndex !== -1) {
                            updated[existingIndex] = newPreset;
                            triggerToast(`Updated preset: ${name}`);
                          } else {
                            updated.push(newPreset);
                            triggerToast(`Saved new preset: ${name}`);
                          }

                          setPresets(updated);
                          localStorage.setItem('gridmaster_presets', JSON.stringify(updated));
                          setNewPresetName('');
                          
                          setActivePresetIndex(DEFAULT_PRESETS.length + (existingIndex !== -1 ? existingIndex : updated.length - 1));
                        }}
                        className="bg-[#373737] hover:bg-[#4B4B4B] border border-neutral-800 hover:border-neutral-700 text-amber-400 py-1 px-2.5 rounded text-[10px] font-bold tracking-wide transition-all h-7 flex items-center gap-1 cursor-pointer shrink-0"
                        title="Save active layout options as preset"
                      >
                        <Save className="w-3.5 h-3.5" /> Save
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Resizing Strategy section */}
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] text-neutral-400 uppercase font-bold tracking-widest">
                    1. Dimensions Target
                  </label>
                  <span className="text-[9px] text-[#FF9A00] font-mono">Resizing Strategy</span>
                </div>
                
                <div className="grid grid-cols-2 gap-1.5 p-0.5 bg-neutral-900 rounded border border-neutral-800">
                  <button
                    onClick={() => setSizingStrategy('average')}
                    className={`text-[10.5px] py-1.5 rounded transition-all font-semibold ${sizingStrategy === 'average' ? 'bg-[#4B4B4B] text-white shadow-inner' : 'text-neutral-400 hover:text-white'}`}
                  >
                    Avg. selected ({averages.w} x {averages.h})
                  </button>
                  <button
                    onClick={() => setSizingStrategy('manual')}
                    className={`text-[10.5px] py-1.5 rounded transition-all font-semibold ${sizingStrategy === 'manual' ? 'bg-[#4B4B4B] text-white shadow-inner' : 'text-neutral-400 hover:text-white'}`}
                  >
                    Manual Input
                  </button>
                </div>

                {/* Sub-inputs if using custom manual sizes */}
                {sizingStrategy === 'manual' ? (
                  <div className="flex flex-col gap-3 mt-1.5 bg-neutral-900/60 p-2.5 rounded border border-neutral-800 animate-fadeIn">
                    <div className="grid grid-cols-2 gap-3">
                      <div
                        onWheel={(e) => handleWheelAdjust(e, manualW, (val) => handleManualResize('w', val), { min: 40, max: 250, baseStep: 5 })}
                        className="group/manualw"
                      >
                        <div className="flex justify-between text-[10px] text-neutral-400 mb-1">
                          <span 
                            className="cursor-ew-resize hover:text-amber-400 select-none border-b border-dashed border-transparent hover:border-amber-400 font-medium"
                            onMouseDown={(e) => startScrub(e, 'Target Width', manualW, (val) => handleManualResize('w', val), 40, 250, 1, false)}
                            title="Click & Drag horizontal to slide, Scroll mouse wheel to adjust"
                          >
                            ↔ Target W (pt)
                          </span>
                          <span className="text-amber-400 font-mono font-bold">{manualW}pt</span>
                        </div>
                        <input
                          type="range"
                          min="40"
                          max="250"
                          value={manualW}
                          onChange={(e) => handleManualResize('w', parseInt(e.target.value))}
                          className="w-full accent-blue-500 h-1 bg-[#0d0d0d] roundedappearance-none rounded-lg appearance-none cursor-pointer"
                        />
                      </div>
                      <div
                        onWheel={(e) => handleWheelAdjust(e, manualH, (val) => handleManualResize('h', val), { min: 40, max: 250, baseStep: 5 })}
                        className="group/manualh"
                      >
                        <div className="flex justify-between text-[10px] text-neutral-400 mb-1">
                          <span 
                            className="cursor-ew-resize hover:text-amber-400 select-none border-b border-dashed border-transparent hover:border-amber-400 font-medium"
                            onMouseDown={(e) => startScrub(e, 'Target Height', manualH, (val) => handleManualResize('h', val), 40, 250, 1, false)}
                            title="Click & Drag horizontal to slide, Scroll mouse wheel to adjust"
                          >
                            ↔ Target H (pt)
                          </span>
                          <span className="text-amber-400 font-mono font-bold">{manualH}pt</span>
                        </div>
                        <input
                          type="range"
                          min="40"
                          max="250"
                          value={manualH}
                          onChange={(e) => handleManualResize('h', parseInt(e.target.value))}
                          className="w-full accent-blue-500 h-1 bg-[#0d0d0d] roundedappearance-none rounded-lg appearance-none cursor-pointer"
                        />
                      </div>
                    </div>

                    {/* Lock manual proportion ratio checkbox */}
                    <label className="flex items-center gap-2 cursor-pointer text-[10px] select-none text-neutral-300 hover:text-white transition-colors">
                      <input
                        type="checkbox"
                        checked={constrainManual}
                        onChange={(e) => {
                          setConstrainManual(e.target.checked);
                          triggerToast(e.target.checked ? 'Manual bounds proportions locked' : 'Manual bounds proportions unlocked');
                        }}
                        className="accent-blue-500 rounded border-neutral-600 bg-neutral-800"
                      />
                      <span>Constrain width and height proportions (W/H)</span>
                    </label>
                  </div>
                ) : (
                  <div className="text-[10px] text-neutral-400 bg-neutral-900 px-3 py-1.5 rounded border border-neutral-800 flex items-center justify-between">
                    <span>Base target:</span>
                    <span className="font-mono text-neutral-200">
                      {numSelected > 0 ? `${averages.w}pt × ${averages.h}pt` : '(Select elements on artboard)'}
                    </span>
                  </div>
                )}

                {/* Scaling Factor Multiplier */}
                <div 
                  className="mt-1"
                  onWheel={(e) => handleWheelAdjust(e, scale, setScale, { min: 30, max: 220, baseStep: 5 })}
                >
                  <div className="flex justify-between text-[11px] mb-1">
                    <span
                      className="text-neutral-400 cursor-ew-resize hover:text-amber-400 select-none border-b border-dashed border-transparent hover:border-amber-400"
                      onMouseDown={(e) => startScrub(e, 'Final Scale', scale, setScale, 30, 220, 1, true)}
                      title="Click & drag horizontal, or mouse scroll wheel to adjust"
                    >
                      ↔ Final Scale Adjuster
                    </span>
                    <span className="text-blue-400 font-mono font-bold">{scale}%</span>
                  </div>
                  <input
                    type="range"
                    min="30"
                    max="220"
                    value={scale}
                    onChange={(e) => setScale(parseInt(e.target.value))}
                    className="w-full h-1 bg-neutral-950 rounded-lg appearance-none cursor-pointer accent-blue-400"
                  />
                  <div className="flex justify-between text-[8px] text-neutral-500 font-mono mt-0.5">
                    <span>30%</span>
                    <span>100% (Original)</span>
                    <span>220%</span>
                  </div>
                </div>
              </div>

              {/* Grid configuration Section */}
              <div className="flex flex-col gap-2">
                <label className="text-[10px] text-neutral-400 uppercase font-bold tracking-widest">
                  2. Grid Layout
                </label>
                
                <div className="flex flex-col gap-3 bg-neutral-900 p-3 rounded border border-neutral-800">
                  
                  {/* Grid Layout Mode Selector */}
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">Layout mode</label>
                    <select
                      value={gridMode}
                      onChange={(e) => {
                        setGridMode(e.target.value as any);
                        if (e.target.value === 'square') {
                          triggerToast('Layout mode: Keep Almost Square');
                        } else if (e.target.value === 'rows') {
                          triggerToast('Layout mode: Target Rows count');
                        } else if (e.target.value === 'optimal_vertical') {
                          triggerToast('Layout mode: Optimal Vertical (Waterfall)');
                        } else if (e.target.value === 'optimal_horizontal') {
                          triggerToast('Layout mode: Optimal Horizontal (Justified)');
                        } else if (e.target.value === 'fixed_gap_h') {
                          triggerToast('Layout mode: Fix Gap Horizontal');
                        } else if (e.target.value === 'fixed_gap_v') {
                          triggerToast('Layout mode: Fix Gap Vertical');
                        } else {
                          triggerToast('Layout mode: Target Columns count');
                        }
                      }}
                      className="w-full bg-neutral-950 text-[11px] text-neutral-200 border border-neutral-800 rounded p-1 mb-1 font-medium"
                    >
                      <option value="cols">Fixed Target Columns Count</option>
                      <option value="rows">Fixed Target Rows Count</option>
                      <option value="square">Keep Almost Square</option>
                      <option value="optimal_vertical">Optimal Vertical (Waterfall)</option>
                      <option value="optimal_horizontal">Optimal Horizontal (Justified Rows)</option>
                      <option value="fixed_gap_h">Fix Gap Horizontal</option>
                      <option value="fixed_gap_v">Fix Gap Vertical</option>
                    </select>
                  </div>

                  {/* Dynamic grid Mode Value count */}
                  {gridMode !== 'square' ? (
                    <div
                      onWheel={(e) => handleWheelAdjust(e, gridModeVal, setGridModeVal, { min: 1, max: 24, baseStep: 1, intOnly: true })}
                    >
                      <div className="flex justify-between text-[11px] mb-1">
                        <span
                          className="text-neutral-300 cursor-ew-resize hover:text-amber-400 select-none border-b border-dashed border-transparent hover:border-amber-400"
                          onMouseDown={(e) => startScrub(e, (gridMode === 'cols' || gridMode === 'optimal_vertical' || gridMode === 'fixed_gap_h') ? 'Columns' : 'Rows', gridModeVal, setGridModeVal, 1, 24, 1, true)}
                          title="Click & drag horizontal, or mouse scroll wheel to adjust"
                        >
                          ↔ {(gridMode === 'cols' || gridMode === 'optimal_vertical' || gridMode === 'fixed_gap_h') ? 'Columns' : 'Rows'} count
                        </span>
                        <span className="text-blue-400 font-mono font-bold">
                          {gridModeVal} {(gridMode === 'cols' || gridMode === 'optimal_vertical' || gridMode === 'fixed_gap_h') ? 'cols' : 'rows'}
                        </span>
                      </div>
                      <input
                        type="range"
                        min="1"
                        max="24"
                        value={gridModeVal}
                        onChange={(e) => setGridModeVal(parseInt(e.target.value))}
                        className="w-full h-1 bg-neutral-950 rounded-lg appearance-none cursor-pointer accent-blue-500"
                      />
                      <div className="flex justify-between text-[8px] text-neutral-500 font-mono mt-0.5">
                        <span>1 (Linear)</span>
                        <span>12</span>
                        <span>24</span>
                      </div>
                    </div>
                  ) : (
                    <div className="flex justify-between items-center text-[10.5px] py-1.5 bg-neutral-950 px-2 rounded border border-neutral-800">
                      <span className="text-neutral-400">Calculated Distribution:</span>
                      <span className="text-emerald-400 font-bold font-mono">
                        {columns} × {Math.ceil(numSelected / columns) || 1} Square Grid
                      </span>
                    </div>
                  )}

                  {/* Inter-item Spacing/Gap spacing */}
                  <div
                    onWheel={(e) => handleWheelAdjust(e, spacing, setSpacing, { min: 0, max: 150, baseStep: 2 })}
                  >
                    <div className="flex justify-between text-[11px] mb-1">
                      <span
                        className="text-neutral-300 cursor-ew-resize hover:text-amber-400 select-none border-b border-dashed border-transparent hover:border-amber-400"
                        onMouseDown={(e) => startScrub(e, 'Spacing', spacing, setSpacing, 0, 150, 1, false)}
                        title="Click & drag horizontal, or mouse scroll wheel to adjust"
                      >
                        ↔ Spacing / Gap
                      </span>
                      <span className="text-blue-400 font-mono font-bold">{spacing} pt</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="150"
                      value={spacing}
                      onChange={(e) => setSpacing(parseInt(e.target.value))}
                      className="w-full h-1 bg-neutral-950 rounded-lg appearance-none cursor-pointer accent-blue-500"
                    />
                    <div className="flex justify-between text-[8px] text-neutral-500 font-mono mt-0.5">
                      <span>0pt (touching)</span>
                      <span>75pt</span>
                      <span>150pt</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Proportion Rules (Critical aspect matching option requested) */}
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] text-neutral-400 uppercase font-bold tracking-widest">
                    3. Proportions &amp; Ratios
                  </label>
                  <label className="flex items-center gap-1 cursor-pointer text-[10px] text-blue-400 font-bold col-span-1">
                    <input
                      type="checkbox"
                      checked={lockRatio}
                      onChange={(e) => {
                        setLockRatio(e.target.checked);
                        triggerToast(e.target.checked ? 'Ratio constraints LOCKED' : 'Ratio constraints UNLOCKED (Stretch allowed)');
                      }}
                      className="accent-blue-500 w-3.5 h-3.5 tracking-tight rounded"
                    />
                    Lock Ratio
                  </label>
                </div>

                <div className="flex flex-col gap-1">
                  <select
                    disabled={!lockRatio}
                    value={aspectRatioMode}
                    onChange={(e) => setAspectRatioMode(e.target.value as any)}
                    className="w-full p-1.5 text-xs bg-neutral-900 text-neutral-100 rounded border border-neutral-800 focus:outline-none focus:border-blue-500 disabled:opacity-50"
                  >
                    <option value="fit">Aspect Fit (Fits inside average cell boundaries)</option>
                    <option value="width">Scale to Width (Adjust height to preserve proportion)</option>
                    <option value="height">Scale to Height (Adjust width to preserve proportion)</option>
                    <option value="stretch">Stretch Fill (Fills average coordinates exactly)</option>
                    <option value="optimal_vertical">Optimal Aspect vertical (Larger side equals size)</option>
                    <option value="optimal_horizontal">Optimal Aspect Horizontal (Shorter side equals size)</option>
                  </select>
                  <span className="text-[8.5px] text-neutral-400 leading-normal pl-1">
                    {lockRatio 
                      ? '✓ Elements scale without stretching or changing their artistic ratios.' 
                      : '⚠ Elements will stretch to filled box dimensions, ignoring creative ratios.'}
                  </span>
                </div>
              </div>

              {/* Dimension Limits (Min/Max size bounds checker requested) */}
              <div className="flex flex-col gap-2">
                <label className="text-[10px] text-neutral-400 uppercase font-bold tracking-widest">
                  4. Dimension Limits (pt)
                </label>
                <div className="bg-neutral-900 border border-neutral-800 p-3 rounded flex flex-col gap-2.5">
                  {/* Min Width */}
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <label className="flex items-center gap-2 cursor-pointer select-none text-neutral-300 hover:text-white">
                      <input
                        type="checkbox"
                        checked={minWEnabled}
                        onChange={(e) => setMinWEnabled(e.target.checked)}
                        className="accent-blue-500 w-3.5 h-3.5 rounded"
                      />
                      <span>Min Width images</span>
                    </label>
                    <input
                      type="number"
                      value={minWVal}
                      disabled={!minWEnabled}
                      onChange={(e) => setMinWVal(Math.max(1, parseInt(e.target.value) || 0))}
                      className="w-20 bg-neutral-950 border border-neutral-800 rounded px-1.5 py-0.5 text-right text-blue-400 font-mono font-bold disabled:opacity-40"
                    />
                  </div>

                  {/* Max Width */}
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <label className="flex items-center gap-2 cursor-pointer select-none text-neutral-300 hover:text-white">
                      <input
                        type="checkbox"
                        checked={maxWEnabled}
                        onChange={(e) => setMaxWEnabled(e.target.checked)}
                        className="accent-blue-500 w-3.5 h-3.5 rounded"
                      />
                      <span>Max Width images</span>
                    </label>
                    <input
                      type="number"
                      value={maxWVal}
                      disabled={!maxWEnabled}
                      onChange={(e) => setMaxWVal(Math.max(1, parseInt(e.target.value) || 0))}
                      className="w-20 bg-neutral-950 border border-neutral-800 rounded px-1.5 py-0.5 text-right text-blue-400 font-mono font-bold disabled:opacity-40"
                    />
                  </div>

                  {/* Min Height */}
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <label className="flex items-center gap-2 cursor-pointer select-none text-neutral-300 hover:text-white">
                      <input
                        type="checkbox"
                        checked={minHEnabled}
                        onChange={(e) => setMinHEnabled(e.target.checked)}
                        className="accent-blue-500 w-3.5 h-3.5 rounded"
                      />
                      <span>Min Height images</span>
                    </label>
                    <input
                      type="number"
                      value={minHVal}
                      disabled={!minHEnabled}
                      onChange={(e) => setMinHVal(Math.max(1, parseInt(e.target.value) || 0))}
                      className="w-20 bg-neutral-950 border border-neutral-800 rounded px-1.5 py-0.5 text-right text-blue-400 font-mono font-bold disabled:opacity-40"
                    />
                  </div>

                  {/* Max Height */}
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <label className="flex items-center gap-2 cursor-pointer select-none text-neutral-300 hover:text-white">
                      <input
                        type="checkbox"
                        checked={maxHEnabled}
                        onChange={(e) => setMaxHEnabled(e.target.checked)}
                        className="accent-blue-500 w-3.5 h-3.5 rounded"
                      />
                      <span>Max Height images</span>
                    </label>
                    <input
                      type="number"
                      value={maxHVal}
                      disabled={!maxHEnabled}
                      onChange={(e) => setMaxHVal(Math.max(1, parseInt(e.target.value) || 0))}
                      className="w-20 bg-neutral-950 border border-neutral-800 rounded px-1.5 py-0.5 text-right text-blue-400 font-mono font-bold disabled:opacity-40"
                    />
                  </div>
                </div>
              </div>

              {/* Alignment Controls visually matching Adobe's Layout panels */}
              <div className="flex flex-col gap-2">
                <label className="text-[10px] text-neutral-400 uppercase font-bold tracking-widest">
                  5. Flow &amp; Alignments
                </label>
                
                {/* Horizontal / Vertical grid construction flow */}
                <div className="grid grid-cols-2 gap-1 p-0.5 bg-neutral-950 rounded" id="flow-directions">
                  <button
                    onClick={() => { setFlowDirection('horizontal'); triggerToast('Flow direction set to Horizontal first'); }}
                    className={`py-1.5 rounded text-[10px] tracking-wide font-extrabold uppercase transition-all ${flowDirection === 'horizontal' ? 'bg-[#4B4B4B] text-neutral-100 shadow-sm' : 'text-neutral-500 hover:text-neutral-300'}`}
                  >
                    Horizontal flow
                  </button>
                  <button
                    onClick={() => { setFlowDirection('vertical'); triggerToast('Flow direction set to Vertical first'); }}
                    className={`py-1.5 rounded text-[10px] tracking-wide font-extrabold uppercase transition-all ${flowDirection === 'vertical' ? 'bg-[#4B4B4B] text-neutral-100 shadow-sm' : 'text-neutral-500 hover:text-neutral-300'}`}
                  >
                    Vertical flow
                  </button>
                </div>

                {/* Sub Alignments */}
                <div className="bg-neutral-900 border border-neutral-800 p-2.5 rounded flex flex-col gap-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-400 text-[11px]">H-Alignment in Cell:</span>
                    <div className="flex bg-neutral-950 rounded p-0.5">
                      <button
                        onClick={() => { setHAlign('left'); triggerToast('H-Align: Left'); }}
                        className={`px-2 py-1.5 rounded text-[10px] font-bold ${hAlign === 'left' ? 'bg-[#4B4B4B] text-white' : 'text-neutral-500 hover:text-neutral-300'}`}
                        title="Align Left inside grid cell"
                      >
                        Left
                      </button>
                      <button
                        onClick={() => { setHAlign('center'); triggerToast('H-Align: Center'); }}
                        className={`px-2 py-1.5 rounded text-[10px] font-bold ${hAlign === 'center' ? 'bg-[#4B4B4B] text-white' : 'text-neutral-500 hover:text-neutral-300'}`}
                        title="Align Center inside grid cell"
                      >
                        Center
                      </button>
                      <button
                        onClick={() => { setHAlign('right'); triggerToast('H-Align: Right'); }}
                        className={`px-2 py-1.5 rounded text-[10px] font-bold ${hAlign === 'right' ? 'bg-[#4B4B4B] text-white' : 'text-neutral-500 hover:text-neutral-300'}`}
                        title="Align Right inside grid cell"
                      >
                        Right
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-neutral-400 text-[11px]">V-Alignment in Cell:</span>
                    <div className="flex bg-neutral-950 rounded p-0.5">
                      <button
                        onClick={() => { setVAlign('top'); triggerToast('V-Align: Top'); }}
                        className={`px-2 py-1.5 rounded text-[10px] font-bold ${vAlign === 'top' ? 'bg-[#4B4B4B] text-white' : 'text-neutral-500 hover:text-neutral-300'}`}
                        title="Align Top inside grid cell"
                      >
                        Top
                      </button>
                      <button
                        onClick={() => { setVAlign('middle'); triggerToast('V-Align: Middle'); }}
                        className={`px-2 py-1.5 rounded text-[10px] font-bold ${vAlign === 'middle' ? 'bg-[#4B4B4B] text-white' : 'text-neutral-500 hover:text-neutral-300'}`}
                        title="Align Middle inside grid cell"
                      >
                        Mid
                      </button>
                      <button
                        onClick={() => { setVAlign('bottom'); triggerToast('V-Align: Bottom'); }}
                        className={`px-2 py-1.5 rounded text-[10px] font-bold ${vAlign === 'bottom' ? 'bg-[#4B4B4B] text-white' : 'text-neutral-500 hover:text-neutral-300'}`}
                        title="Align Bottom inside grid cell"
                      >
                        Bot
                      </button>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* Sizing Action Buttons fixed at bottom under Panel */}
          <div className="border-t border-[#141414] bg-[#232323] p-4 flex flex-col gap-2 shrink-0 select-none">
            
            {/* Realtime Live Preview Checkbox Toggle */}
            <div className="flex items-center justify-between bg-[#1f1f1f] border border-neutral-800 rounded p-2.5 mb-1 text-xs">
              <span className="text-neutral-400 font-semibold text-[10.5px]">Realtime Preview</span>
              <label className="flex items-center gap-1.5 cursor-pointer text-emerald-400 font-extrabold">
                <input
                  type="checkbox"
                  checked={realtime}
                  onChange={(e) => {
                    setRealtime(e.target.checked);
                    triggerToast(e.target.checked ? 'Realtime Preview ENABLED' : 'Realtime Preview DISABLED');
                  }}
                  className="accent-emerald-500 w-3.5 h-3.5 tracking-tight rounded cursor-pointer"
                  id="realtime-checkbox"
                />
                <span className="text-[9.5px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded flex items-center gap-1">
                  <span className={`w-1.5 h-1.5 rounded-full ${realtime ? 'bg-emerald-400 animate-pulse' : 'bg-neutral-600'}`}></span>
                  {realtime ? 'LIVE' : 'OFF'}
                </span>
              </label>
            </div>

            <button
              onClick={() => applyGridLayout(false)}
              className="w-full bg-[#2563EB] hover:bg-blue-500 active:bg-blue-700 text-white font-extrabold py-3 px-4 rounded shadow-lg text-[13px] tracking-wider transition-all duration-150 flex items-center justify-center gap-2 border border-blue-400/20 uppercase"
              id="generate-grid-btn"
            >
              <Sparkles className="w-4 h-4 text-yellow-300 animate-pulse" />
              Generate Grid Layout
            </button>
            
            <button
              onClick={scatterItems}
              className="w-full bg-transparent hover:bg-neutral-800 text-neutral-400 border border-neutral-700 py-1.5 rounded text-[11px] transition-colors"
              id="scramble-btn"
            >
              Scramble Artboard Assets
            </button>

            <div className="flex items-center justify-between text-[9px] text-neutral-500 pt-1 mt-1 border-t border-neutral-800">
              <span className="flex items-center gap-1">
                <InfoIcon className="w-3 h-3 text-neutral-500" />
                Live sandbox simulation
              </span>
              <span>v1.0.4</span>
            </div>
          </div>

        </div>

        {/* Right side helper small anchor tabs representing closed panels */}
        <div className="w-12 bg-[#2D2D2D] border-l border-[#141414] hidden md:flex flex-col items-center py-4 gap-4 text-xs text-neutral-500" id="adobe-dock-panels">
          <div className="w-8 h-8 bg-neutral-800 rounded flex flex-col items-center justify-center cursor-pointer border border-neutral-700 text-[#FF9A00] font-bold text-[9px]" title="Layers Panel">
            <Layers className="w-4 h-4" />
            <span>LAY</span>
          </div>

          <div className="w-8 h-8 hover:bg-neutral-800 rounded flex flex-col items-center justify-center cursor-pointer text-neutral-400 text-[9px]" title="Grid Layout Info">
            <Grid className="w-4 h-4" />
            <span>GRD</span>
          </div>

          <div className="w-8 h-8 hover:bg-neutral-800 rounded flex flex-col items-center justify-center cursor-pointer text-neutral-400 text-[9px]" title="Config Sliders">
            <Sliders className="w-4 h-4" />
            <span>SLI</span>
          </div>

          <div className="w-8 h-8 hover:bg-neutral-800 rounded flex flex-col items-center justify-center cursor-pointer text-neutral-400 text-[9px]" title="Scripts Settings">
            <Settings className="w-4 h-4" />
            <span>SET</span>
          </div>
        </div>

      </div>

      {/* Footer / Status Information Bar */}
      <div className="h-6 bg-[#2D2D2D] border-t border-[#141414] flex items-center px-4 justify-between text-[10px] text-neutral-500 shrink-0 select-none" id="app-footer">
        <div className="flex gap-4">
          <span className="text-neutral-400">Zoom: <b className="text-neutral-300">85%</b></span>
          <span>Selection type: <b className="text-neutral-300">Multiple Objects Group</b></span>
          <span>Target bounds: <b className="text-[#FF9A00] font-mono">{sizingStrategy === 'average' ? 'Average' : 'Manual'} [{averages.w}pt x {averages.h}pt]</b></span>
        </div>
        <div className="flex gap-4 items-center">
          <span className="hidden sm:inline">Use mouse left-click on objects to toggle selection | Drag elements to reposition</span>
          <span className="text-blue-500 font-bold uppercase tracking-widest text-[9.5px]">GridMaster Engine Loaded</span>
        </div>
      </div>

    </div>
  );
}
