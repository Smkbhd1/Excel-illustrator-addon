/*
======================================================================================
GridMaster Pro - Host ExtendScript File for CEP Panel Integration
======================================================================================
*/

function arrangeGridMaster(gridMode, gridVal, spacing, isHoriz, useAvg, targetW, targetH, aspectOption, alignH, alignV, minWEnabled, minWVal, maxWEnabled, maxWVal, minHEnabled, minHVal, maxHEnabled, maxHVal, sortBy, sortDir) {
    if (app.documents.length === 0) {
        return "Error: No active document found. Please open an Illustrator document first.";
    }

    var doc = app.activeDocument;
    var selection = doc.selection;

    if (!selection || selection.length < 2) {
        return "Error: Please select 2 or more objects on your artboard to arrange.";
    }

    var items = [];
    var totalW = 0;
    var totalH = 0;

    // Stable anchor based on visual coordinates produced vs manual repositioning
    var currentCoordsSig = "";
    for (var i = 0; i < selection.length; i++) {
        currentCoordsSig += Math.round(selection[i].left) + "_" + Math.round(selection[i].top) + ",";
    }

    $.global.gridmasterLastOutputSig = $.global.gridmasterLastOutputSig || "";
    $.global.gridmasterAnchorLeft = $.global.gridmasterAnchorLeft || 0;
    $.global.gridmasterAnchorTop = $.global.gridmasterAnchorTop || 0;
    $.global.gridmasterLastCount = $.global.gridmasterLastCount || 0;

    var selectionChanged = false;
    if (!$.global.gridmasterLastOutputSig || selection.length !== $.global.gridmasterLastCount) {
        selectionChanged = true;
    } else {
        if (currentCoordsSig !== $.global.gridmasterLastOutputSig) {
            selectionChanged = true;
        }
    }

    var minLeft, maxTop;
    if (selectionChanged) {
        minLeft = selection[0].left;
        maxTop = selection[0].top;
        for (var i = 1; i < selection.length; i++) {
            if (selection[i].left < minLeft) minLeft = selection[i].left;
            if (selection[i].top > maxTop) maxTop = selection[i].top;
        }
        $.global.gridmasterAnchorLeft = minLeft;
        $.global.gridmasterAnchorTop = maxTop;
        $.global.gridmasterLastCount = selection.length;
    } else {
        minLeft = $.global.gridmasterAnchorLeft;
        maxTop = $.global.gridmasterAnchorTop;
    }

    for (var i = 0; i < selection.length; i++) {
        var item = selection[i];
        items.push(item);
        totalW += item.width;
        totalH += item.height;
    }

    var count = items.length;
    var avgW = Math.round(totalW / count);
    var avgH = Math.round(totalH / count);

    var finalTargetW = useAvg ? avgW : (parseFloat(targetW) || avgW);
    var finalTargetH = useAvg ? avgH : (parseFloat(targetH) || avgH);

    // ---- Sort items by user-chosen criterion ----
    var sortByIdx  = sortBy  || 0;  // 0=position,1=name,2=filename,3=created,4=modified,5=filesize,6=area
    var sortDirIdx = sortDir || 0;  // 0=ascending, 1=descending

    // Safely get the File object for a placed/raster item
    function getFileObj(item) {
        try {
            if (item.typename === "PlacedItem" || item.typename === "RasterItem") {
                var f = item.file;
                if (f && f.exists) return f;
            }
        } catch(e) {}
        return null;
    }

    // Convert ExtendScript Date to numeric timestamp
    function dateToNum(d) {
        try { return d ? d.getTime() : 0; } catch(e) { return 0; }
    }

    // Extract the sort key for a given criterion
    function getSortKey(item, idx) {
        switch (idx) {
            case 1: // Object name
                try { return (item.name || "").toLowerCase(); } catch(e) { return ""; }
            case 2: // File name on disk
                var f2 = getFileObj(item);
                return f2 ? f2.name.toLowerCase() : "";
            case 3: // Created date
                var f3 = getFileObj(item);
                return f3 ? dateToNum(f3.created) : 0;
            case 4: // Modified date
                var f4 = getFileObj(item);
                return f4 ? dateToNum(f4.modified) : 0;
            case 5: // File size in bytes
                var f5 = getFileObj(item);
                return f5 ? (f5.length || 0) : 0;
            case 6: // Area in points (width × height)
                try { return item.width * item.height; } catch(e) { return 0; }
            default:
                return 0;
        }
    }

    var descMult = (sortDirIdx === 1) ? -1 : 1;

    if (sortByIdx === 0) {
        // Default: top-to-bottom, left-to-right positional sort
        items.sort(function(a, b) {
            var diffY = Math.round(b.top) - Math.round(a.top);
            if (Math.abs(diffY) > 25) return diffY * descMult;
            return (Math.round(a.left) - Math.round(b.left)) * descMult;
        });
    } else {
        items.sort(function(a, b) {
            var ka = getSortKey(a, sortByIdx);
            var kb = getSortKey(b, sortByIdx);
            var result = 0;
            if (typeof ka === "string" && typeof kb === "string") {
                if (ka < kb) result = -1;
                else if (ka > kb) result = 1;
            } else {
                result = ka - kb;
            }
            return result * descMult;
        });
    }

    // Resolve column layout count based on gridMode
    // gridMode: 0 = cols, 1 = rows, 2 = square, 3 = optimal_vertical, 4 = optimal_horizontal, 5 = fix_gap_h, 6 = fix_gap_v
    var columns = 4;
    if (gridMode === 0 || gridMode === 3 || gridMode === 5) {
        columns = gridVal;
    } else if (gridMode === 1 || gridMode === 4 || gridMode === 6) {
        columns = Math.ceil(count / gridVal);
    } else if (gridMode === 2) {
        columns = Math.ceil(Math.sqrt(count));
    }
    if (columns < 1) columns = 1;

    var numRows = Math.ceil(count / columns);

    // Pre-calculate sizing for each selected item
    var sizedList = [];
    for (var j = 0; j < count; j++) {
        var el = items[j];
        var origW = el.width;
        var origH = el.height;
        var origRatio = origW / origH;

        var newW = finalTargetW;
        var newH = finalTargetH;

        if (aspectOption === 0) { // Aspect Fit
            var cellRatio = finalTargetW / finalTargetH;
            if (origRatio > cellRatio) {
                newW = finalTargetW;
                newH = finalTargetW / origRatio;
            } else {
                newH = finalTargetH;
                newW = finalTargetH * origRatio;
            }
        } else if (aspectOption === 1) { // Fit Width
            newW = finalTargetW;
            newH = finalTargetW / origRatio;
        } else if (aspectOption === 2) { // Fit Height
            newH = finalTargetH;
            newW = finalTargetH * origRatio;
        } else if (aspectOption === 4) { // Optimal Aspect vertical
            if (origRatio >= 1.0) {
                newW = finalTargetW;
                newH = finalTargetW / origRatio;
            } else {
                newH = finalTargetW;
                newW = finalTargetW * origRatio;
            }
        } else if (aspectOption === 5) { // Optimal Aspect Horizontal
            if (origRatio >= 1.0) {
                newH = finalTargetW;
                newW = finalTargetW * origRatio;
            } else {
                newW = finalTargetW;
                newH = finalTargetW / origRatio;
            }
        } // Else 3 is stretch fill

        var lockAspect = (aspectOption !== 3);
        if (lockAspect) {
            if (minWEnabled && newW < minWVal) { newW = minWVal; newH = minWVal / origRatio; }
            if (minHEnabled && newH < minHVal) { newH = minHVal; newW = minHVal * origRatio; }
            if (maxWEnabled && newW > maxWVal) { newW = maxWVal; newH = maxWVal / origRatio; }
            if (maxHEnabled && newH > maxHVal) { newH = maxHVal; newW = maxHVal * origRatio; }
        } else {
            if (minWEnabled && newW < minWVal) newW = minWVal;
            if (maxWEnabled && newW > maxWVal) newW = maxWVal;
            if (minHEnabled && newH < minHVal) newH = minHVal;
            if (maxHEnabled && newH > maxHVal) newH = maxHVal;
        }
        
        el.width = newW;
        el.height = newH;

        sizedList.push({ el: el, w: newW, h: newH });
    }

    var colHeights = [];
    var colItemsCount = [];
    if (gridMode === 3) {
        for (var c = 0; c < columns; c++) {
            colHeights.push(maxTop);
            colItemsCount.push(0);
        }
    }

    var rowWidths = [];
    var rowItemsCount = [];
    if (gridMode === 4) {
        var designRows = gridVal;
        if (designRows < 1) designRows = 1;
        for (var r = 0; r < designRows; r++) {
            rowWidths.push(minLeft);
            rowItemsCount.push(0);
        }
    }

    if (gridMode === 5) { 
        var currentY = maxTop;
        for (var r = 0; r < numRows; r++) {
            var rowItems = [];
            for (var i = r * columns; i < Math.min((r + 1) * columns, count); i++) {
                rowItems.push(sizedList[i]);
            }
            if (rowItems.length === 0) continue;

            var rowTallest = 0;
            for (var i = 0; i < rowItems.length; i++) {
                if (rowItems[i].h > rowTallest) rowTallest = rowItems[i].h;
            }

            var previousLeft = minLeft;
            for (var i = 0; i < rowItems.length; i++) {
                var si = rowItems[i];
                var elementLeft = previousLeft;
                if (i > 0) elementLeft = previousLeft + spacing;

                var elementTop = currentY; 
                if (alignV === 1) elementTop = currentY - (rowTallest - si.h) / 2;
                else if (alignV === 2) elementTop = currentY - (rowTallest - si.h);

                si.el.position = [elementLeft, elementTop];
                previousLeft = elementLeft + si.w;
            }
            currentY -= (rowTallest + spacing);
        }
    } else if (gridMode === 6) { 
        var rowsPerCol = Math.ceil(count / columns);
        var numColsCalculated = Math.ceil(count / rowsPerCol);
        var currentX = minLeft;

        for (var c = 0; c < numColsCalculated; c++) {
            var colItems = [];
            for (var i = c * rowsPerCol; i < Math.min((c + 1) * rowsPerCol, count); i++) {
                colItems.push(sizedList[i]);
            }
            if (colItems.length === 0) continue;

            var colWidest = 0;
            for (var i = 0; i < colItems.length; i++) {
                if (colItems[i].w > colWidest) colWidest = colItems[i].w;
            }

            var previousTop = maxTop;
            for (var i = 0; i < colItems.length; i++) {
                var si = colItems[i];
                var elementTop = previousTop;
                if (i > 0) elementTop = previousTop - spacing;

                var elementLeft = currentX;
                if (alignH === 1) elementLeft = currentX + (colWidest - si.w) / 2;
                else if (alignH === 2) elementLeft = currentX + (colWidest - si.w);

                si.el.position = [elementLeft, elementTop];
                previousTop = elementTop - si.h;
            }
            currentX += colWidest + spacing;
        }
    } else {
        for (var j = 0; j < count; j++) {
            var si = sizedList[j];

            if (gridMode === 3) {
                var targetColIdx = 0;
                var maxColY = -Infinity;
                for (var c = 0; c < columns; c++) {
                    if (colHeights[c] > maxColY) {
                        maxColY = colHeights[c];
                        targetColIdx = c;
                    }
                }

                var cellLeft = minLeft + targetColIdx * (finalTargetW + spacing);
                var cellTop = colHeights[targetColIdx];
                if (colItemsCount[targetColIdx] > 0) cellTop = cellTop - spacing;

                var finalLeft = cellLeft;
                if (alignH === 1) finalLeft = cellLeft + (finalTargetW - si.w) / 2;
                else if (alignH === 2) finalLeft = cellLeft + finalTargetW - si.w;

                var finalTop = cellTop;
                si.el.position = [finalLeft, finalTop];

                colHeights[targetColIdx] = cellTop - si.h;
                colItemsCount[targetColIdx]++;

            } else if (gridMode === 4) {
                var designRows = gridVal;
                if (designRows < 1) designRows = 1;

                var targetRowIdx = 0;
                var minRowX = Infinity;
                for (var r = 0; r < designRows; r++) {
                    if (rowWidths[r] < minRowX) {
                        minRowX = rowWidths[r];
                        targetRowIdx = r;
                    }
                }

                var cellTop = maxTop - targetRowIdx * (finalTargetH + spacing);
                var cellLeft = rowWidths[targetRowIdx];
                if (rowItemsCount[targetRowIdx] > 0) cellLeft = cellLeft + spacing;

                var finalLeft = cellLeft;
                var finalTop = cellTop;
                if (alignV === 1) finalTop = cellTop - (finalTargetH - si.h) / 2;
                else if (alignV === 2) finalTop = cellTop - (finalTargetH - si.h);

                si.el.position = [finalLeft, finalTop];

                rowWidths[targetRowIdx] = cellLeft + si.w;
                rowItemsCount[targetRowIdx]++;

            } else {
                var colIdx, rowIdx;
                if (isHoriz) {
                    colIdx = j % columns;
                    rowIdx = Math.floor(j / columns);
                } else {
                    rowIdx = j % numRows;
                    colIdx = Math.floor(j / numRows);
                }

                var cellLeft = minLeft + colIdx * (finalTargetW + spacing);
                var cellTop = maxTop - rowIdx * (finalTargetH + spacing);

                var finalLeft = cellLeft;
                if (alignH === 1) finalLeft = cellLeft + (finalTargetW - si.w) / 2;
                else if (alignH === 2) finalLeft = cellLeft + finalTargetW - si.w;

                var finalTop = cellTop;
                if (alignV === 1) finalTop = cellTop - (finalTargetH - si.h) / 2;
                else if (alignV === 2) finalTop = cellTop - (finalTargetH - si.h);

                si.el.position = [finalLeft, finalTop];
            }
        }
    }

    var newCoordsSig = "";
    for (var i = 0; i < selection.length; i++) {
        newCoordsSig += Math.round(selection[i].left) + "_" + Math.round(selection[i].top) + ",";
    }
    $.global.gridmasterLastOutputSig = newCoordsSig;

    app.redraw();
    return "Success: Resized and arranged " + count + " items in a grid!";
}
