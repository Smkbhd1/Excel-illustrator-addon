import os
import sys
import glob
import shutil
import subprocess
import tkinter as tk
from tkinter import messagebox, filedialog

# GridMaster Pro Python Cross-Platform Auto-Installer
# Installs both:
# 1. Traditional Script (.jsx) under File -> Scripts
# 2. Dockable Workspace Panel (CEP) under Window -> Extensions (V2025/2026 Compatible!)

class GridMasterInstallerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("GridMaster Pro - Adobe Illustrator V2025 Installer Bundle")
        self.root.geometry("660x520")
        self.root.resizable(False, False)
        self.root.configure(bg="#1E1E1E")
        
        # Style Definitions
        self.accent_color = "#FF9A00"
        self.bg_dark = "#1E1E1E"
        self.bg_panel = "#2D2D2D"
        self.text_light = "#F3F4F6"
        self.text_dim = "#9CA3AF"
        
        self.setup_ui()
        self.detect_paths()

    def setup_ui(self):
        # Header Logotype
        header = tk.Frame(self.root, bg=self.bg_panel, height=65, borderwidth=1, relief="flat")
        header.pack(fill="x", side="top")
        
        logo = tk.Label(header, text="Ai", bg=self.accent_color, fg="#121212", font=("Helvetica", 16, "bold"), width=3, height=1)
        logo.pack(side="left", padx=15, pady=10)
        
        title_lbl = tk.Label(header, text="GridMaster Pro Workspace Panel Installer", bg=self.bg_panel, fg=self.text_light, font=("Helvetica", 13, "bold"))
        title_lbl.pack(side="left", pady=10)
        
        ver_lbl = tk.Label(header, text="V1.0.4", bg=self.bg_panel, fg=self.accent_color, font=("Helvetica", 9, "bold"))
        ver_lbl.pack(side="right", padx=15, pady=10)

        # Body Frame
        body = tk.Frame(self.root, bg=self.bg_dark)
        body.pack(fill="both", expand=True, padx=20, pady=20)

        # Description text
        desc = tk.Label(body, text="Automatically configures professional tools for Adobe Illustrator.\nInstalls Dockable Panel UI (Window > Extensions) and traditional JSX Scripts.", bg=self.bg_dark, fg=self.text_dim, font=("Helvetica", 10), justify="left", anchor="w")
        desc.pack(fill="x", pady=(0, 15))

        # Config paths sections
        # Section A: Script (.jsx)
        pnl_script = tk.LabelFrame(body, text=" Traditional Script Installation Path ", bg=self.bg_dark, fg=self.accent_color, font=("Helvetica", 9, "bold"), bd=1, relief="solid", padx=10, pady=10)
        pnl_script.pack(fill="x", pady=(0, 10))

        self.script_path_var = tk.StringVar()
        entry_script = tk.Entry(pnl_script, textvariable=self.script_path_var, bg="#2D2D2D", fg="white", bd=1, relief="flat", font=("Helvetica", 9))
        entry_script.pack(side="left", fill="x", expand=True, padx=(0, 10), ipady=3)
        
        btn_browse_script = tk.Button(pnl_script, text="Browse...", bg="#373737", fg="white", activebackground="#4B4B4B", bd=0, font=("Helvetica", 9, "bold"), command=self.browse_script_folder, padx=10)
        btn_browse_script.pack(side="right")

        # Section B: CEP Panel Extension Folder
        pnl_cep = tk.LabelFrame(body, text=" Dockable Extension Panel Directory (CEP) ", bg=self.bg_dark, fg=self.accent_color, font=("Helvetica", 9, "bold"), bd=1, relief="solid", padx=10, pady=10)
        pnl_cep.pack(fill="x", pady=(0, 15))

        self.cep_path_var = tk.StringVar()
        entry_cep = tk.Entry(pnl_cep, textvariable=self.cep_path_var, bg="#2D2D2D", fg="white", bd=1, relief="flat", font=("Helvetica", 9))
        entry_cep.pack(side="left", fill="x", expand=True, padx=(0, 10), ipady=3)
        
        btn_browse_cep = tk.Button(pnl_cep, text="Browse...", bg="#373737", fg="white", activebackground="#4B4B4B", bd=0, font=("Helvetica", 9, "bold"), command=self.browse_cep_folder, padx=10)
        btn_browse_cep.pack(side="right")

        # Info Box Frame
        info_frame = tk.Frame(body, bg="#151515", bd=1, relief="solid", padx=12, pady=12)
        info_frame.pack(fill="both", expand=True, pady=(0, 15))
        
        self.info_lbl = tk.Label(info_frame, text="[*] Ready to verify connections...\n[*] Installer will set PlayerDebugMode registry keys so the extension panel runs unsigned without certificate issues.", bg="#151515", fg="#A7F3D0", font=("Courier New", 9.5), justify="left", anchor="w")
        self.info_lbl.pack(fill="both", expand=True)

        # Installation Button Trigger
        self.install_btn = tk.Button(body, text="⚡ AUTO-INSTALL EXTENSION BUNDLE", bg="#10B981", fg="white", activebackground="#059669", activeforeground="white", bd=0, relief="flat", font=("Helvetica", 11, "bold"), command=self.run_full_installation, pady=10)
        self.install_btn.pack(fill="x")

    def detect_paths(self):
        scripts_dir = ""
        cep_dir = ""

        # A. Resolve scripts location
        if sys.platform == "win32":
            # Windows Paths
            base_script = r"C:\Program Files\Adobe"
            if os.path.exists(base_script):
                for folder in os.listdir(base_script):
                    if "Adobe Illustrator" in folder:
                        patterns = os.path.join(base_script, folder, "Presets", "*", "Scripts")
                        matches = glob.glob(patterns)
                        if matches:
                            scripts_dir = matches[0]
                            break
            # CEP extension directory
            cep_dir = os.path.join(os.getenv("APPDATA", ""), "Adobe", "CEP", "extensions")
        
        elif sys.platform == "darwin":
            # macOS Paths
            base_script = "/Applications"
            if os.path.exists(base_script):
                for folder in os.listdir(base_script):
                    if "Adobe Illustrator" in folder:
                        for sub in ["Presets", "Presets.localized"]:
                            patterns = os.path.join(base_script, folder, sub, "*", "Scripts")
                            matches = glob.glob(patterns)
                            if matches:
                                scripts_dir = matches[0]
                                break
            # CEP extension directory
            cep_dir = os.path.expanduser("~/Library/Application Support/Adobe/CEP/extensions")

        self.script_path_var.set(scripts_dir if scripts_dir else "Scripts folder not autodetected. Locate manually.")
        self.cep_path_var.set(cep_dir if cep_dir else "CEP folder not autodetected. Locate manually.")

    def browse_script_folder(self):
        chosen = filedialog.askdirectory(title="Locate Adobe Illustrator 'Scripts' Folder")
        if chosen:
            self.script_path_var.set(chosen)

    def browse_cep_folder(self):
        chosen = filedialog.askdirectory(title="Locate Adobe 'CEP/extensions' Folder")
        if chosen:
            self.cep_path_var.set(chosen)

    def write_debug_modes(self):
        try:
            if sys.platform == "win32":
                # Write to Windows registry keys
                import winreg
                for suffix in range(7, 15):
                    key_path = f"Software\\Adobe\\CSXS.{suffix}"
                    try:
                        key = winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE)
                        winreg.SetValueEx(key, "PlayerDebugMode", 0, winreg.REG_SZ, "1")
                        winreg.CloseKey(key)
                    except Exception:
                        pass
                return True
            elif sys.platform == "darwin":
                # Execute macOS defaults writes
                for suffix in range(7, 15):
                    cmd = f"defaults write com.adobe.CSXS.{suffix} PlayerDebugMode 1"
                    subprocess.call(cmd, shell=True)
                return True
        except Exception as e:
            print("Failed to enable PlayerDebugMode keys: ", e)
            return False

    def run_full_installation(self):
        script_target = self.script_path_var.get().strip()
        cep_target = self.cep_path_var.get().strip()
        
        current_dir = os.path.dirname(os.path.abspath(__file__))
        source_jsx = os.path.join(current_dir, "GridMasterPro.jsx")
        source_cep = os.path.join(current_dir, "com.gridmaster.panel")

        report = []
        errors = []

        # 1. Traditional JSX Installation
        if os.path.exists(script_target) and os.path.exists(source_jsx):
            try:
                dest_jsx = os.path.join(script_target, "GridMasterPro.jsx")
                shutil.copy2(source_jsx, dest_jsx)
                report.append("✓ Traditional Script: Installed successfully!")
            except Exception as ex:
                errors.append(f"Could not copy script file to Scripts path: {str(ex)}")
        else:
            report.append("⚠ Traditional Script: Target/Source not found, script copy skipped.")

        # 2. Dockable CEP Extension Panel Installation
        if os.path.exists(source_cep):
            try:
                # Ensure CEP directory parent structures exist
                os.makedirs(cep_target, exist_ok=True)
                dest_cep = os.path.join(cep_target, "com.gridmaster.panel")
                
                # Delete older versions if present
                if os.path.exists(dest_cep):
                    shutil.rmtree(dest_cep)
                
                shutil.copytree(source_cep, dest_cep)
                report.append("✓ Dockable Workspace Panel: Configured and registration complete!")
            except Exception as ex:
                errors.append(f"Could not copy CEP panel structure to Destination: {str(ex)}")
        else:
            errors.append("⚠️ GridMaster Panel directory folder source code is missing!")

        # 3. Configure PlayerDebugMode setting
        debug_confs = self.write_debug_modes()
        if debug_confs:
            report.append("✓ Adobe Developer mode (PlayerDebugMode) configuration: Success!")
        else:
            report.append("✖ Adobe Developer mode registry edit: Failed to configure keys automatically.")

        # Final message alerts
        if errors:
            err_msg = "\n".join(errors)
            messagebox.showerror("Installation Segment Alerts", f"Completed with errors:\n\n{err_msg}")
        
        info_summary = "\n".join(report)
        self.info_lbl.config(text=info_summary, fg="#F3F4F6")

        success_message = (
            "Congratulations! GridMaster Pro features have been deployed!\n\n"
            "To use your Dockable Workspace Panel UI:\n"
            "1. Launch/Restart Adobe Illustrator (including V2025)\n"
            "2. Navigate to: Window -> Extensions -> GridMaster Pro Panel\n"
            "3. Dock the beautiful panel anywhere alongside Layers or Color Swatches!\n\n"
            "Traditional JSX fallback script is also ready under: File -> Scripts -> GridMasterPro"
        )
        messagebox.showinfo("Success!", success_message)

if __name__ == "__main__":
    app_root = tk.Tk()
    app = GridMasterInstallerApp(app_root)
    app_root.mainloop()
