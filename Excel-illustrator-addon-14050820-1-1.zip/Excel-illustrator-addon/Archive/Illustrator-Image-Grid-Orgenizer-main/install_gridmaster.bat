@echo off
:: Title
title GridMaster Pro - Modern Auto-Installer for Adobe Illustrator
echo =======================================================================
echo     GRIDMASTER PRO - ADOBE ILLUSTRATOR AUTO-INSTALLER (V2025 COMPATIBLE)
echo =======================================================================
echo.

:: Check Admin Rights (highly recommended for registry updates and program writing)
openfiles >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] WARNING: This script does not have Administrator privileges.
    echo     Please right-click this 'install_gridmaster.bat' and select
    echo     "Run as administrator" to write settings and folder configurations.
    echo.
    pause
    exit /b
)

echo [*] Administrator privileges confirmed. Proceeding with installation...
echo.

:: Set paths to resources
set "SOURCE_JSX=GridMasterPro.jsx"
set "SOURCE_PANEL_FOLDER=com.gridmaster.panel"

:: 1. INSTALL TRADITIONAL EXTENDSCRIPT (.jsx)
echo [*] Step 1: Installing Traditional ExtendScript ...
set "FOUND_SCRIPT_PATH="
set "COPIED_SCRIPTS_COUNT=0"

for /d %%i in ("C:\Program Files\Adobe\Adobe Illustrator *") do (
    if exist "%%i\Presets" (
        for /d %%j in ("%%i\Presets\*") do (
            if exist "%%j\Scripts" (
                set "FOUND_SCRIPT_PATH=%%j\Scripts"
                
                :: Copy JSX file to Scripts directory
                if exist "%~dp0\%SOURCE_JSX%" (
                    copy /y "%~dp0\%SOURCE_JSX%" "%%j\Scripts\GridMasterPro.jsx" >nul
                    if %errorlevel% equ 0 (
                        echo     [+] Installed script to: "%%j\Scripts\GridMasterPro.jsx"
                        set /a COPIED_SCRIPTS_COUNT+=1
                    )
                )
            )
        )
    )
)

if "%FOUND_SCRIPT_PATH%"=="" (
    echo     [!] Illustrator scripts default directory could not be resolved.
    echo     We will attempt manual input if necessary.
)

:: 2. INSTALL DOCKABLE CEP EXTENSION PANEL (The Docket Tab Option)
echo.
echo [*] Step 2: Installing Dockable CEP Extension Panel ...
set "CEP_DIR=%APPDATA%\Adobe\CEP\extensions"

if exist "%~dp0\%SOURCE_PANEL_FOLDER%" (
    :: Build CEP directory if it doesn't exist
    if not exist "%CEP_DIR%" (
        mkdir "%CEP_DIR%" >nul 2>&1
    )
    
    :: Copy extension panel files
    echo     [*] Copying panel files to: "%CEP_DIR%\com.gridmaster.panel"
    xcopy /s /e /y /i "%~dp0\%SOURCE_PANEL_FOLDER%" "%CEP_DIR%\com.gridmaster.panel" >nul
    
    if %errorlevel% equ 0 (
        echo     [+] Panel files successfully registered to %CEP_DIR%
        set "PANEL_INSTALLED=1"
    ) else (
        echo     [FAILED] Could not copy GridMaster Panel files. Check write permissions.
        set "PANEL_INSTALLED=0"
    )
) else (
    echo     [!] Source folder 'com.gridmaster.panel' not found in this folder.
    echo     Skipping extension panel copying segment.
    set "PANEL_INSTALLED=0"
)

:: 3. ENABLE SYSTEM CEP DEBUG MODE (Allows loading of unsigned local extensions)
echo.
echo [*] Step 3: Configuring Adobe Debug Registry Modes ...
echo     Enabling developer-mode signatures to allow dockable panel loading...
reg add "HKCU\Software\Adobe\CSXS.7" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.8" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.9" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.13" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.14" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
echo     [+] Registry PlayerDebugMode keys enabled for CSXS.7 through CSXS.14!

echo.
echo =======================================================================
echo                      INSTALLATION PROCESS COMPLETE!
echo =======================================================================
echo.
if "%PANEL_INSTALLED%"=="1" (
    echo    ⚡ DOCKABLE EXTENSION PANEL:
    echo       - Launch or Restart Adobe Illustrator.
    echo       - Go to: Window -^> Extensions -^> GridMaster Pro Panel
    echo       - Drag/Dock this panel anywhere inside your workspace layout
    echo         and use it at any time with high-speed performance!
    echo.
)
if %COPIED_SCRIPTS_COUNT% gt 0 (
    echo    📁 TRADITIONAL SCRIPT BACKUP:
    echo       - File -^> Scripts -^> GridMasterPro is ready as fallback!
    echo.
)
echo =======================================================================
pause
exit /b
