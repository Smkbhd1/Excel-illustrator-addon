/*
======================================================================================
GridMaster Pro - Adobe Illustrator Resizer & Layout Script
======================================================================================
Description:
An automation script for Adobe Illustrator V2025 (and older versions) to resize
selected elements based on their average dimensions (or manual input) and arrange
them in a customizable grid array while keeping individual aspect ratios intact.

Author: extendscript-core-automator
Version: 1.0.5
======================================================================================
*/

(function() {
    if (app.documents.length === 0) {
        alert("GridMaster Error:\nNo active document found. Please open an Illustrator document first.");
        return;
    }

    var doc = app.activeDocument;
    var selection = doc.selection;

    if (!selection || selection.length < 2) {
        alert("GridMaster Info:\nPlease select 2 or more objects on your artboard to apply the grid resizing automation.");
        return;
    }

    // 1. Calculate selection coordinates and averages
    var items = [];
    var totalW = 0;
    var totalH = 0;
    var minLeft = selection[0].left;
    var maxTop = selection[0].top;

    for (var i = 0; i < selection.length; i++) {
        var item = selection[i];
        items.push(item);
        totalW += item.width;
        totalH += item.height;
        if (item.left < minLeft) minLeft = item.left;
        if (item.top > maxTop) maxTop = item.top;
    }

    var count = items.length;
    var avgW = Math.round(totalW / count);
    var avgH = Math.round(totalH / count);

    // Read and Parse config/presets from local flat config
    function parseKVs(kvStr) {
        var obj = {};
        var pairs = kvStr.split(",");
        for (var i = 0; i < pairs.length; i++) {
            var kv = pairs[i].split(":");
            if (kv.length < 2) continue;
            var k = kv[0];
            var v = kv[1];
            if (v === "true") obj[k] = true;
            else if (v === "false") obj[k] = false;
            else if (!isNaN(Number(v))) obj[k] = Number(v);
            else obj[k] = v;
        }
        return obj;
    }

    function serializeKVs(obj) {
        var parts = [];
        for (var k in obj) {
            if (obj.hasOwnProperty(k)) {
                parts.push(k + ":" + obj[k]);
            }
        }
        return parts.join(",");
    }

    function readConfigFile() {
        var presets = [
            { name: "Default 4xGrid", data: { gridMode: 0, gridModeVal: 4, spacing: 14, rbHoriz: true, rbAverage: true, txtW: 120, txtH: 120, chkConstrain: false, chkMinW: false, txtMinW: 60, chkMaxW: false, txtMaxW: 300, chkMinH: false, txtMinH: 60, chkMaxH: false, txtMaxH: 300, ddlAspect: 0, ddlH: 1, ddlV: 1, sortBy: 0, sortDir: 0 } },
            { name: "3-Col Pinterest Waterfall", data: { gridMode: 3, gridModeVal: 3, spacing: 14, rbHoriz: true, rbAverage: true, txtW: 120, txtH: 120, chkConstrain: false, chkMinW: false, txtMinW: 60, chkMaxW: false, txtMaxW: 300, chkMinH: false, txtMinH: 60, chkMaxH: false, txtMaxH: 300, ddlAspect: 1, ddlH: 1, ddlV: 1, sortBy: 0, sortDir: 0 } },
            { name: "Dynamic Banner Row", data: { gridMode: 5, gridModeVal: 1, spacing: 18, rbHoriz: true, rbAverage: true, txtW: 120, txtH: 120, chkConstrain: false, chkMinW: false, txtMinW: 60, chkMaxW: false, txtMaxW: 300, chkMinH: false, txtMinH: 60, chkMaxH: false, txtMaxH: 300, ddlAspect: 0, ddlH: 1, ddlV: 1, sortBy: 0, sortDir: 0 } },
            { name: "Dense Compact Grid", data: { gridMode: 0, gridModeVal: 6, spacing: 8, rbHoriz: true, rbAverage: true, txtW: 80, txtH: 80, chkConstrain: false, chkMinW: false, txtMinW: 40, chkMaxW: false, txtMaxW: 200, chkMinH: false, txtMinH: 40, chkMaxH: false, txtMaxH: 200, ddlAspect: 0, ddlH: 1, ddlV: 1, sortBy: 0, sortDir: 0 } }
        ];
        var lastUsed = null;

        try {
            var presetsFile = new File(Folder.userData + "/GridMasterPro_Presets.txt");
            if (presetsFile.exists) {
                presetsFile.open("r");
                while (!presetsFile.eof) {
                    var line = presetsFile.readLine();
                    if (!line) continue;
                    
                    if (line.indexOf("LAST_USED:") === 0) {
                        var kvStr = line.substring(10);
                        lastUsed = parseKVs(kvStr);
                    } else if (line.indexOf("PRESET:") === 0) {
                        var eqIdx = line.indexOf("=");
                        if (eqIdx !== -1) {
                            var presetName = line.substring(7, eqIdx);
                            var kvStr = line.substring(eqIdx + 1);
                            var data = parseKVs(kvStr);
                            
                            var found = false;
                            for (var p = 0; p < presets.length; p++) {
                                if (presets[p].name === presetName) {
                                    presets[p].data = data;
                                    found = true;
                                    break;
                                }
                            }
                            if (!found) {
                                presets.push({ name: presetName, data: data });
                            }
                        }
                    }
                }
                presetsFile.close();
            }
        } catch (e) {
            // Fail gracefully
        }
        return { presets: presets, lastUsed: lastUsed };
    }

    function saveConfigFile(lastUsed, presets) {
        try {
            var presetsFile = new File(Folder.userData + "/GridMasterPro_Presets.txt");
            presetsFile.open("w");
            if (lastUsed) {
                presetsFile.write("LAST_USED:" + serializeKVs(lastUsed) + "\n");
            }
            for (var i = 0; i < presets.length; i++) {
                presetsFile.write("PRESET:" + presets[i].name + "=" + serializeKVs(presets[i].data) + "\n");
            }
            presetsFile.close();
        } catch (e) {
            // Fail gracefully
        }
    }

    var config = readConfigFile();
    var lastUsedObj = config.lastUsed;

    // 2. Build Dialog Panel UI
    var dialog = new Window("dialog", "GridMaster Pro - Layout Panel");
    dialog.alignChildren = "fill";
    dialog.margins = 16;

    // Header Frame
    var titleGrp = dialog.add("group");
    titleGrp.orientation = "column";
    titleGrp.alignChildren = "center";
    var titleLbl = titleGrp.add("statictext", undefined, "GRIDMASTER PRO");
    titleLbl.graphics.font = ScriptUI.newFont("sans", "BOLD", 16);
    var subLbl = titleGrp.add("statictext", undefined, "V2025 Automator Extension");
    subLbl.graphics.font = ScriptUI.newFont("sans", "REGULAR", 10);

    // PANEL 0: Presets Manager (New requested feature)
    var pnlPresets = dialog.add("panel", undefined, "Saved Presets");
    pnlPresets.alignChildren = "fill";
    pnlPresets.margins = 12;

    var rowPresetSel = pnlPresets.add("group");
    rowPresetSel.add("statictext", undefined, "Select Preset:");
    var presetNames = [];
    for (var p = 0; p < config.presets.length; p++) {
        presetNames.push(config.presets[p].name);
    }
    var ddlPresets = rowPresetSel.add("dropdownlist", undefined, presetNames);
    ddlPresets.selection = 0;

    var rowPresetBtns = pnlPresets.add("group");
    rowPresetBtns.alignment = "right";
    var btnSavePreset = rowPresetBtns.add("button", undefined, "Save Preset");
    var btnDeletePreset = rowPresetBtns.add("button", undefined, "Delete");

    // Panel: Sort Order
    var pnlSort = dialog.add("panel", undefined, "Sort Order");
    pnlSort.alignChildren = "fill";
    pnlSort.margins = 12;

    var rowSortBy = pnlSort.add("group");
    rowSortBy.add("statictext", undefined, "Sort By:");
    var ddlSortBy = rowSortBy.add("dropdownlist", undefined, [
        "Position (Top\u2192Bottom, Left\u2192Right)",
        "Name (A\u2192Z)",
        "File Name (A\u2192Z)",
        "Created Date (Oldest\u2192Newest)",
        "Modified Date (Oldest\u2192Newest)",
        "File Size (Smallest\u2192Largest)",
        "Size in Points / Area (Smallest\u2192Largest)"
    ]);
    ddlSortBy.selection = lastUsedObj && lastUsedObj.sortBy !== undefined ? lastUsedObj.sortBy : 0;

    var rowSortDir = pnlSort.add("group");
    rowSortDir.add("statictext", undefined, "Direction:");
    var ddlSortDir = rowSortDir.add("dropdownlist", undefined, [
        "\u2191 Ascending",
        "\u2193 Descending"
    ]);
    ddlSortDir.selection = lastUsedObj && lastUsedObj.sortDir !== undefined ? lastUsedObj.sortDir : 0;

    // Panel 1: Grid Configs
    var pnlGrid = dialog.add("panel", undefined, "Grid Configuration");
    pnlGrid.alignChildren = "fill";
    pnlGrid.margins = 12;

    var rowDist = pnlGrid.add("group");
    rowDist.add("statictext", undefined, "Grid Layout Mode:");
    var ddlGridMode = rowDist.add("dropdownlist", undefined, [
        "Fixed Columns Count",
        "Fixed Rows Count",
        "Keep Almost Square",
        "Optimal Vertical (Waterfall)",
        "Optimal Horizontal (Justified Rows)",
        "Fix Gap Horizontal",
        "Fix Gap Vertical"
    ]);
    ddlGridMode.selection = lastUsedObj && lastUsedObj.gridMode !== undefined ? lastUsedObj.gridMode : 0;

    var rowCols = pnlGrid.add("group");
    var lblGridVal = rowCols.add("statictext", undefined, "Columns Count:");
    var txtCols = rowCols.add("edittext", undefined, lastUsedObj && lastUsedObj.gridModeVal !== undefined ? String(lastUsedObj.gridModeVal) : "4");
    txtCols.characters = 6;

    rowCols.add("statictext", undefined, "Spacing (pt):");
    var txtSpacing = rowCols.add("edittext", undefined, lastUsedObj && lastUsedObj.spacing !== undefined ? String(lastUsedObj.spacing) : "14");
    txtSpacing.characters = 6;

    ddlGridMode.onChange = function() {
        var idx = ddlGridMode.selection.index;
        if (idx === 0 || idx === 3 || idx === 5) {
            lblGridVal.text = idx === 0 ? "Columns Count:" : idx === 3 ? "Columns Count (Waterfall):" : "Columns Count (Fixed Gap):";
            txtCols.enabled = true;
        } else if (idx === 1 || idx === 4 || idx === 6) {
            lblGridVal.text = idx === 1 ? "Rows Count:" : idx === 4 ? "Rows Count (Justified):" : "Rows Count (Fixed Gap):";
            txtCols.enabled = true;
        } else {
            lblGridVal.text = "Auto calculated";
            txtCols.enabled = false;
        }
    };

    var rowFlow = pnlGrid.add("group");
    rowFlow.add("statictext", undefined, "Flow Direction:");
    var rbHoriz = rowFlow.add("radiobutton", undefined, "Horizontal");
    var rbVert = rowFlow.add("radiobutton", undefined, "Vertical");
    if (lastUsedObj && lastUsedObj.rbHoriz !== undefined) {
        rbHoriz.value = lastUsedObj.rbHoriz;
        rbVert.value = !lastUsedObj.rbHoriz;
    } else {
        rbHoriz.value = true;
    }

    // Panel 2: Resizing Options
    var pnlSize = dialog.add("panel", undefined, "Sizing Strategy");
    pnlSize.alignChildren = "fill";
    pnlSize.margins = 12;

    var rbAverage = pnlSize.add("radiobutton", undefined, "Use Average of Selection (" + avgW + " x " + avgH + " pt)");
    var rbManual = pnlSize.add("radiobutton", undefined, "Use Custom Target Size");
    if (lastUsedObj && lastUsedObj.rbAverage !== undefined) {
        rbAverage.value = lastUsedObj.rbAverage;
        rbManual.value = !lastUsedObj.rbAverage;
    } else {
        rbAverage.value = true;
    }

    var manualGrp = pnlSize.add("group");
    manualGrp.add("statictext", undefined, "Width (pt):");
    var txtW = manualGrp.add("edittext", undefined, lastUsedObj && lastUsedObj.txtW !== undefined ? String(lastUsedObj.txtW) : String(avgW));
    txtW.characters = 5;
    manualGrp.add("statictext", undefined, "Height (pt):");
    var txtH = manualGrp.add("edittext", undefined, lastUsedObj && lastUsedObj.txtH !== undefined ? String(lastUsedObj.txtH) : String(avgH));
    txtH.characters = 5;
    
    txtW.enabled = rbManual.value;
    txtH.enabled = rbManual.value;

    var rowConstrain = pnlSize.add("group");
    var chkConstrain = rowConstrain.add("checkbox", undefined, "Constrain manual proportions (W & H ratio)");
    chkConstrain.value = lastUsedObj && lastUsedObj.chkConstrain !== undefined ? lastUsedObj.chkConstrain : false;
    chkConstrain.enabled = rbManual.value;

    var manualRatio = 1.0;
    try {
        var wVal = parseFloat(txtW.text) || 120;
        var hVal = parseFloat(txtH.text) || 120;
        if (hVal > 0) manualRatio = wVal / hVal;
    } catch(e) {}

    chkConstrain.onClick = function() {
        if (chkConstrain.value) {
            var w = parseFloat(txtW.text) || 120;
            var h = parseFloat(txtH.text) || 120;
            if (h > 0) {
                manualRatio = w / h;
            }
        }
    };

    txtW.onChange = function() {
        if (chkConstrain.value) {
            var w = parseFloat(txtW.text) || 0;
            if (manualRatio > 0) {
                var h = w / manualRatio;
                txtH.text = String(Math.round(h * 10) / 10);
            }
        } else {
            var w = parseFloat(txtW.text) || 0;
            var h = parseFloat(txtH.text) || 120;
            if (h > 0) {
                manualRatio = w / h;
            }
        }
    };

    txtH.onChange = function() {
        if (chkConstrain.value) {
            var h = parseFloat(txtH.text) || 0;
            var w = h * manualRatio;
            txtW.text = String(Math.round(w * 10) / 10);
        } else {
            var h = parseFloat(txtH.text) || 0;
            var w = parseFloat(txtW.text) || 120;
            if (h > 0) {
                manualRatio = w / h;
            }
        }
    };

    // Toggle active inputs
    rbAverage.onClick = function() { 
        txtW.enabled = false; 
        txtH.enabled = false; 
        chkConstrain.enabled = false;
    };
    rbManual.onClick = function() { 
        txtW.enabled = true; 
        txtH.enabled = true; 
        chkConstrain.enabled = true;
    };

    // Panel Dimension Limits (Optional parameters requested by user)
    var pnlLimits = dialog.add("panel", undefined, "Optional Dimension Limits");
    pnlLimits.alignChildren = "left";
    pnlLimits.orientation = "column";
    pnlLimits.margins = 12;

    // Min Width Group
    var gpMinW = pnlLimits.add("group");
    var chkMinW = gpMinW.add("checkbox", undefined, "Min Width images: ");
    chkMinW.value = lastUsedObj && lastUsedObj.chkMinW !== undefined ? lastUsedObj.chkMinW : false;
    var txtMinW = gpMinW.add("edittext", undefined, lastUsedObj && lastUsedObj.txtMinW !== undefined ? String(lastUsedObj.txtMinW) : "60");
    txtMinW.characters = 5;
    txtMinW.enabled = chkMinW.value;
    chkMinW.onClick = function() { txtMinW.enabled = chkMinW.value; };

    // Max Width Group
    var gpMaxW = pnlLimits.add("group");
    var chkMaxW = gpMaxW.add("checkbox", undefined, "Max Width images: ");
    chkMaxW.value = lastUsedObj && lastUsedObj.chkMaxW !== undefined ? lastUsedObj.chkMaxW : false;
    var txtMaxW = gpMaxW.add("edittext", undefined, lastUsedObj && lastUsedObj.txtMaxW !== undefined ? String(lastUsedObj.txtMaxW) : "300");
    txtMaxW.characters = 5;
    txtMaxW.enabled = chkMaxW.value;
    chkMaxW.onClick = function() { txtMaxW.enabled = chkMaxW.value; };

    // Min Height Group
    var gpMinH = pnlLimits.add("group");
    var chkMinH = gpMinH.add("checkbox", undefined, "Min Height images: ");
    chkMinH.value = lastUsedObj && lastUsedObj.chkMinH !== undefined ? lastUsedObj.chkMinH : false;
    var txtMinH = gpMinH.add("edittext", undefined, lastUsedObj && lastUsedObj.txtMinH !== undefined ? String(lastUsedObj.txtMinH) : "60");
    txtMinH.characters = 5;
    txtMinH.enabled = chkMinH.value;
    chkMinH.onClick = function() { txtMinH.enabled = chkMinH.value; };

    // Max Height Group
    var gpMaxH = pnlLimits.add("group");
    var chkMaxH = gpMaxH.add("checkbox", undefined, "Max Height images: ");
    chkMaxH.value = lastUsedObj && lastUsedObj.chkMaxH !== undefined ? lastUsedObj.chkMaxH : false;
    var txtMaxH = gpMaxH.add("edittext", undefined, lastUsedObj && lastUsedObj.txtMaxH !== undefined ? String(lastUsedObj.txtMaxH) : "300");
    txtMaxH.characters = 5;
    txtMaxH.enabled = chkMaxH.value;
    chkMaxH.onClick = function() { txtMaxH.enabled = chkMaxH.value; };

    // Panel 3: Aspect Scaling rule
    var pnlAspect = dialog.add("panel", undefined, "Aspect Ratio Constraints & Alignment");
    pnlAspect.alignChildren = "left";
    pnlAspect.margins = 12;

    var ddlAspect = pnlAspect.add("dropdownlist", undefined, [
        "Aspect Fit (Keep Ratio, Fit Inside Box)",
        "Fit Width (Keep Ratio, Auto Scale Height)",
        "Fit Height (Keep Ratio, Auto Scale Width)",
        "Stretch Fill (Ignore Proportions)",
        "Optimal Aspect vertical (Larger side equals size)",
        "Optimal Aspect Horizontal (Shorter side equals size)"
    ]);
    ddlAspect.selection = lastUsedObj && lastUsedObj.ddlAspect !== undefined ? lastUsedObj.ddlAspect : 0;

    var rowAlign = pnlAspect.add("group");
    rowAlign.add("statictext", undefined, "H-Align:");
    var ddlH = rowAlign.add("dropdownlist", undefined, ["Left", "Center", "Right"]);
    ddlH.selection = lastUsedObj && lastUsedObj.ddlH !== undefined ? lastUsedObj.ddlH : 1;

    rowAlign.add("statictext", undefined, "V-Align:");
    var ddlV = rowAlign.add("dropdownlist", undefined, ["Top", "Middle", "Bottom"]);
    ddlV.selection = lastUsedObj && lastUsedObj.ddlV !== undefined ? lastUsedObj.ddlV : 1;

    // Presets event listener logic
    function applyPresetToUI(presetData) {
        if (!presetData) return;
        if (presetData.gridMode !== undefined) ddlGridMode.selection = presetData.gridMode;
        if (presetData.gridModeVal !== undefined) txtCols.text = String(presetData.gridModeVal);
        if (presetData.spacing !== undefined) txtSpacing.text = String(presetData.spacing);
        
        if (presetData.rbHoriz !== undefined) {
            rbHoriz.value = presetData.rbHoriz;
            rbVert.value = !presetData.rbHoriz;
        }
        
        if (presetData.rbAverage !== undefined) {
            rbAverage.value = presetData.rbAverage;
            rbManual.value = !presetData.rbAverage;
            txtW.enabled = !presetData.rbAverage;
            txtH.enabled = !presetData.rbAverage;
            chkConstrain.enabled = !presetData.rbAverage;
        }
        
        if (presetData.txtW !== undefined) txtW.text = String(presetData.txtW);
        if (presetData.txtH !== undefined) txtH.text = String(presetData.txtH);
        if (presetData.chkConstrain !== undefined) chkConstrain.value = presetData.chkConstrain;
        
        if (presetData.chkMinW !== undefined) {
            chkMinW.value = presetData.chkMinW;
            txtMinW.enabled = presetData.chkMinW;
        }
        if (presetData.txtMinW !== undefined) txtMinW.text = String(presetData.txtMinW);
        
        if (presetData.chkMaxW !== undefined) {
            chkMaxW.value = presetData.chkMaxW;
            txtMaxW.enabled = presetData.chkMaxW;
        }
        if (presetData.txtMaxW !== undefined) txtMaxW.text = String(presetData.txtMaxW);
        
        if (presetData.chkMinH !== undefined) {
            chkMinH.value = presetData.chkMinH;
            txtMinH.enabled = presetData.chkMinH;
        }
        if (presetData.txtMinH !== undefined) txtMinH.text = String(presetData.txtMinH);
        
        if (presetData.chkMaxH !== undefined) {
            chkMaxH.value = presetData.chkMaxH;
            txtMaxH.enabled = presetData.chkMaxH;
        }
        if (presetData.txtMaxH !== undefined) txtMaxH.text = String(presetData.txtMaxH);
        
        if (presetData.ddlAspect !== undefined) ddlAspect.selection = presetData.ddlAspect;
        if (presetData.ddlH !== undefined) ddlH.selection = presetData.ddlH;
        if (presetData.ddlV !== undefined) ddlV.selection = presetData.ddlV;

        if (presetData.sortBy !== undefined) ddlSortBy.selection = presetData.sortBy;
        if (presetData.sortDir !== undefined) ddlSortDir.selection = presetData.sortDir;
        
        txtCols.enabled = (ddlGridMode.selection.index !== 2); // refresh column layout enabled
    }

    ddlPresets.onChange = function() {
        var idx = ddlPresets.selection.index;
        if (idx !== -1 && config.presets[idx]) {
            applyPresetToUI(config.presets[idx].data);
        }
    };

    btnSavePreset.onClick = function() {
        var name = prompt("Enter a name for this custom layout preset:", "My Custom Preset");
        if (name) {
            name = name.replace(/=/g, "").replace(/:/g, ""); // sanitation
            var uiData = {
                gridMode: ddlGridMode.selection.index,
                gridModeVal: parseInt(txtCols.text, 10) || 4,
                spacing: parseFloat(txtSpacing.text) || 12,
                rbHoriz: rbHoriz.value,
                rbAverage: rbAverage.value,
                txtW: parseFloat(txtW.text) || avgW,
                txtH: parseFloat(txtH.text) || avgH,
                chkConstrain: chkConstrain.value,
                chkMinW: chkMinW.value,
                txtMinW: parseFloat(txtMinW.text) || 60,
                chkMaxW: chkMaxW.value,
                txtMaxW: parseFloat(txtMaxW.text) || 300,
                chkMinH: chkMinH.value,
                txtMinH: parseFloat(txtMinH.text) || 60,
                chkMaxH: chkMaxH.value,
                txtMaxH: parseFloat(txtMaxH.text) || 300,
                ddlAspect: ddlAspect.selection.index,
                ddlH: ddlH.selection.index,
                ddlV: ddlV.selection.index,
                sortBy: ddlSortBy.selection.index,
                sortDir: ddlSortDir.selection.index
            };
            
            var existsIdx = -1;
            for (var i = 0; i < config.presets.length; i++) {
                if (config.presets[i].name.toLowerCase() === name.toLowerCase()) {
                    existsIdx = i;
                    break;
                }
            }
            if (existsIdx !== -1) {
                config.presets[existsIdx].data = uiData;
            } else {
                config.presets.push({ name: name, data: uiData });
            }
            
            saveConfigFile(uiData, config.presets);
            
            ddlPresets.removeAll();
            for (var i = 0; i < config.presets.length; i++) {
                ddlPresets.add("item", config.presets[i].name);
            }
            
            for (var i = 0; i < config.presets.length; i++) {
                if (config.presets[i].name === name) {
                    ddlPresets.selection = i;
                    break;
                }
            }
            alert("Preset '" + name + "' saved successfully!");
        }
    };

    btnDeletePreset.onClick = function() {
        var selIdx = ddlPresets.selection.index;
        if (selIdx < 4) {
            alert("Cannot delete default core presets!");
            return;
        }
        var nameToDelete = config.presets[selIdx].name;
        if (confirm("Are you sure you want to delete preset '" + nameToDelete + "'?")) {
            config.presets.splice(selIdx, 1);
            
            var currentUIData = {
                gridMode: ddlGridMode.selection.index,
                gridModeVal: parseInt(txtCols.text, 10) || 4,
                spacing: parseFloat(txtSpacing.text) || 12,
                rbHoriz: rbHoriz.value,
                rbAverage: rbAverage.value,
                txtW: parseFloat(txtW.text) || avgW,
                txtH: parseFloat(txtH.text) || avgH,
                chkConstrain: chkConstrain.value,
                chkMinW: chkMinW.value,
                txtMinW: parseFloat(txtMinW.text) || 60,
                chkMaxW: chkMaxW.value,
                txtMaxW: parseFloat(txtMaxW.text) || 300,
                chkMinH: chkMinH.value,
                txtMinH: parseFloat(txtMinH.text) || 60,
                chkMaxH: chkMaxH.value,
                txtMaxH: parseFloat(txtMaxH.text) || 300,
                ddlAspect: ddlAspect.selection.index,
                ddlH: ddlH.selection.index,
                ddlV: ddlV.selection.index,
                sortBy: ddlSortBy.selection.index,
                sortDir: ddlSortDir.selection.index
            };
            
            saveConfigFile(currentUIData, config.presets);
            
            ddlPresets.removeAll();
            for (var i = 0; i < config.presets.length; i++) {
                ddlPresets.add("item", config.presets[i].name);
            }
            ddlPresets.selection = 0;
            applyPresetToUI(config.presets[0].data);
            alert("Preset deleted successfully.");
        }
    };

    // Action buttons
    var btnGrp = dialog.add("group");
    btnGrp.alignment = "center";
    btnGrp.margins = [0, 8, 0, 0];
    btnGrp.add("button", undefined, "Cancel", {name: "cancel"});
    var btnOk = btnGrp.add("button", undefined, "Arrange Grid", {name: "ok"});

    // On submit
    if (dialog.show() === 1) {
        var gridMode = ddlGridMode.selection.index; 
        var gridVal = parseInt(txtCols.text, 10) || 4;
        var spacing = parseFloat(txtSpacing.text) || 14;
        var isHoriz = rbHoriz.value;

        var targetW = rbAverage.value ? avgW : (parseFloat(txtW.text) || avgW);
        var targetH = rbAverage.value ? avgH : (parseFloat(txtH.text) || avgH);

        var aspectOption = ddlAspect.selection.index;
        var alignH = ddlH.selection.index; // 0 = Left, 1 = Center, 2 = Right
        var alignV = ddlV.selection.index; // 0 = Top, 1 = Middle, 2 = Bottom

        var minWEnabled = chkMinW.value;
        var minWVal = parseFloat(txtMinW.text) || 60;
        var maxWEnabled = chkMaxW.value;
        var maxWVal = parseFloat(txtMaxW.text) || 300;
        var minHEnabled = chkMinH.value;
        var minHVal = parseFloat(txtMinH.text) || 60;
        var maxHEnabled = chkMaxH.value;
        var maxHVal = parseFloat(txtMaxH.text) || 300;

        var sortByIdx  = ddlSortBy.selection.index;   // 0-6
        var sortDirIdx = ddlSortDir.selection.index;   // 0=asc, 1=desc

        // Auto save LAST_USED settings on execution
        var latestSettings = {
            gridMode: gridMode,
            gridModeVal: gridVal,
            spacing: spacing,
            rbHoriz: isHoriz,
            rbAverage: rbAverage.value,
            txtW: rbAverage.value ? avgW : (parseFloat(txtW.text) || avgW),
            txtH: rbAverage.value ? avgH : (parseFloat(txtH.text) || avgH),
            chkConstrain: chkConstrain.value,
            chkMinW: minWEnabled,
            txtMinW: minWVal,
            chkMaxW: maxWEnabled,
            txtMaxW: maxWVal,
            chkMinH: minHEnabled,
            txtMinH: minHVal,
            chkMaxH: maxHEnabled,
            txtMaxH: maxHVal,
            ddlAspect: aspectOption,
            ddlH: alignH,
            ddlV: alignV,
            sortBy: sortByIdx,
            sortDir: sortDirIdx
        };
        saveConfigFile(latestSettings, config.presets);

        // ---- Sort items by user-chosen criterion ----
        //
        // Helper: safely get a File object from an item.
        // Returns null if the item is not a linked PlacedItem or file is missing.
        function getFileObj(item) {
            try {
                if (item.typename === "PlacedItem" || item.typename === "RasterItem") {
                    var f = item.file;
                    if (f && f.exists) return f;
                }
            } catch(e) {}
            return null;
        }

        // Helper: convert an ExtendScript Date to a numeric timestamp for comparison.
        function dateToNum(d) {
            try { return d ? d.getTime() : 0; } catch(e) { return 0; }
        }

        // Helper: extract the sort key for a given item and criterion index.
        function getSortKey(item, criterionIdx) {
            switch (criterionIdx) {
                case 0: // Position (Top→Bottom, Left→Right) — composite, handled separately
                    return 0;
                case 1: // Object name
                    try { return (item.name || "").toLowerCase(); } catch(e) { return ""; }
                case 2: // File name on disk
                    var fObj2 = getFileObj(item);
                    return fObj2 ? fObj2.name.toLowerCase() : "";
                case 3: // Created date
                    var fObj3 = getFileObj(item);
                    return fObj3 ? dateToNum(fObj3.created) : 0;
                case 4: // Modified date
                    var fObj4 = getFileObj(item);
                    return fObj4 ? dateToNum(fObj4.modified) : 0;
                case 5: // File size in bytes
                    var fObj5 = getFileObj(item);
                    return fObj5 ? (fObj5.length || 0) : 0;
                case 6: // Size in points (area = width × height)
                    try { return item.width * item.height; } catch(e) { return 0; }
                default:
                    return 0;
            }
        }

        var descMult = (sortDirIdx === 1) ? -1 : 1;

        if (sortByIdx === 0) {
            // Default positional sort: top-to-bottom, left-to-right
            // (descending Illustrator Y = visually top, then ascending X)
            items.sort(function(a, b) {
                var diffY = Math.round(b.top) - Math.round(a.top);
                if (Math.abs(diffY) > 25) return diffY * descMult;
                return (Math.round(a.left) - Math.round(b.left)) * descMult;
            });
        } else {
            // Criterion-based sort
            items.sort(function(a, b) {
                var ka = getSortKey(a, sortByIdx);
                var kb = getSortKey(b, sortByIdx);
                var result = 0;
                if (typeof ka === "string" && typeof kb === "string") {
                    if (ka < kb) result = -1;
                    else if (ka > kb) result = 1;
                } else {
                    result = ka - kb;
                }
                return result * descMult;
            });
        }

        var columns = 4;
        if (gridMode === 0 || gridMode === 3 || gridMode === 5) {
            columns = gridVal;
        } else if (gridMode === 1 || gridMode === 4 || gridMode === 6) {
            columns = Math.ceil(count / gridVal);
        } else if (gridMode === 2) {
            columns = Math.ceil(Math.sqrt(count));
        }
        if (columns < 1) columns = 1;

        var numRows = Math.ceil(count / columns);

        // Pre-calculate sizing for each selected item
        var sizedList = [];
        for (var j = 0; j < count; j++) {
            var el = items[j];
            var origW = el.width;
            var origH = el.height;
            var origRatio = origW / origH;

            var newW = targetW;
            var newH = targetH;

            // Compute constrained dimensions based on selected options
            if (aspectOption === 0) { // Aspect Fit inside cell boundingbox
                var cellRatio = targetW / targetH;
                if (origRatio > cellRatio) {
                    newW = targetW;
                    newH = targetW / origRatio;
                } else {
                    newH = targetH;
                    newW = targetH * origRatio;
                }
            } else if (aspectOption === 1) { // Fit Width
                newW = targetW;
                newH = targetW / origRatio;
            } else if (aspectOption === 2) { // Fit Height
                newH = targetH;
                newW = targetH * origRatio;
            } else if (aspectOption === 4) { // Optimal Aspect vertical (Larger side equals size)
                if (origRatio >= 1.0) { // horizontal or square
                    newW = targetW;
                    newH = targetW / origRatio;
                } else { // vertical
                    newH = targetW;
                    newW = targetW * origRatio;
                }
            } else if (aspectOption === 5) { // Optimal Aspect Horizontal (Shorter side equals size)
                if (origRatio >= 1.0) { // horizontal or square
                    newH = targetW;
                    newW = targetW * origRatio;
                } else { // vertical
                    newW = targetW;
                    newH = targetW / origRatio;
                }
            }

            // Apply dimension limit bounds restrictions
            var lockAspect = (aspectOption !== 3);
            if (lockAspect) {
                if (minWEnabled && newW < minWVal) {
                    newW = minWVal;
                    newH = minWVal / origRatio;
                }
                if (minHEnabled && newH < minHVal) {
                    newH = minHVal;
                    newW = minHVal * origRatio;
                }
                if (maxWEnabled && newW > maxWVal) {
                    newW = maxWVal;
                    newH = maxWVal / origRatio;
                }
                if (maxHEnabled && newH > maxHVal) {
                    newH = maxHVal;
                    newW = maxHVal * origRatio;
                }
            } else {
                if (minWEnabled && newW < minWVal) newW = minWVal;
                if (maxWEnabled && newW > maxWVal) newW = maxWVal;
                if (minHEnabled && newH < minHVal) newH = minHVal;
                if (maxHEnabled && newH > maxHVal) maxH = maxHVal;
            }

            sizedList.push({
                el: el,
                w: newW,
                h: newH
            });
        }

        // Trackers for waterfall columns / justified rows
        var colHeights = [];
        var colItemsCount = [];
        if (gridMode === 3) {
            for (var c = 0; c < columns; c++) {
                colHeights.push(maxTop);
                colItemsCount.push(0);
            }
        }

        var rowWidths = [];
        var rowItemsCount = [];
        if (gridMode === 4) {
            var designRows = gridVal;
            if (designRows < 1) designRows = 1;
            for (var r = 0; r < designRows; r++) {
                rowWidths.push(minLeft);
                rowItemsCount.push(0);
            }
        }

        if (gridMode === 5) { // Fix Gap Horizontal (Y grows upwards to the top)
            var currentY = maxTop;
            for (var r = 0; r < numRows; r++) {
                var rowItems = [];
                for (var i = r * columns; i < Math.min((r + 1) * columns, count); i++) {
                    rowItems.push(sizedList[i]);
                }
                if (rowItems.length === 0) continue;

                var rowTallest = 0;
                for (var i = 0; i < rowItems.length; i++) {
                    if (rowItems[i].h > rowTallest) rowTallest = rowItems[i].h;
                }

                var previousLeft = minLeft;
                for (var i = 0; i < rowItems.length; i++) {
                    var si = rowItems[i];
                    var elementLeft = previousLeft;
                    if (i > 0) {
                        elementLeft = previousLeft + spacing;
                    }

                    var elementTop = currentY; 
                    if (alignV === 1) { // middle
                        elementTop = currentY - (rowTallest - si.h) / 2;
                    } else if (alignV === 2) { // bottom
                        elementTop = currentY - (rowTallest - si.h);
                    }

                    si.el.width = si.w;
                    si.el.height = si.h;
                    si.el.position = [elementLeft, elementTop];

                    previousLeft = elementLeft + si.w;
                }

                currentY -= (rowTallest + spacing);
            }
        } else if (gridMode === 6) { // Fix Gap Vertical (Y grows upwards)
            var rowsPerCol = Math.ceil(count / columns);
            var numColsCalculated = Math.ceil(count / rowsPerCol);
            var currentX = minLeft;

            for (var c = 0; c < numColsCalculated; c++) {
                var colItems = [];
                for (var i = c * rowsPerCol; i < Math.min((c + 1) * rowsPerCol, count); i++) {
                    colItems.push(sizedList[i]);
                }
                if (colItems.length === 0) continue;

                var colWidest = 0;
                for (var i = 0; i < colItems.length; i++) {
                    if (colItems[i].w > colWidest) colWidest = colItems[i].w;
                }

                var previousTop = maxTop;
                for (var i = 0; i < colItems.length; i++) {
                    var si = colItems[i];
                    var elementTop = previousTop;
                    if (i > 0) {
                        elementTop = previousTop - spacing;
                    }

                    var elementLeft = currentX;
                    if (alignH === 1) { // center
                        elementLeft = currentX + (colWidest - si.w) / 2;
                    } else if (alignH === 2) { // right
                        elementLeft = currentX + (colWidest - si.w);
                    }

                    si.el.width = si.w;
                    si.el.height = si.h;
                    si.el.position = [elementLeft, elementTop];

                    previousTop = elementTop - si.h;
                }

                currentX += colWidest + spacing;
            }
        } else {
            for (var j = 0; j < count; j++) {
                var si = sizedList[j];

                if (gridMode === 3) { // Optimal Vertical (Waterfall)
                    var targetColIdx = 0;
                    var maxColY = -Infinity;
                    for (var c = 0; c < columns; c++) {
                        if (colHeights[c] > maxColY) {
                            maxColY = colHeights[c];
                            targetColIdx = c;
                        }
                    }

                    var cellLeft = minLeft + targetColIdx * (targetW + spacing);
                    var cellTop = colHeights[targetColIdx];
                    if (colItemsCount[targetColIdx] > 0) {
                        cellTop = cellTop - spacing;
                    }

                    var finalLeft = cellLeft;
                    if (alignH === 1) {
                        finalLeft = cellLeft + (targetW - si.w) / 2;
                    } else if (alignH === 2) {
                        finalLeft = cellLeft + targetW - si.w;
                    }

                    var finalTop = cellTop; // Top boundary of element
                    si.el.width = si.w;
                    si.el.height = si.h;
                    si.el.position = [finalLeft, finalTop];

                    // Update column height
                    colHeights[targetColIdx] = cellTop - si.h;
                    colItemsCount[targetColIdx]++;

                } else if (gridMode === 4) { // Optimal Horizontal (Justified Rows)
                    var designRows = gridVal;
                    if (designRows < 1) designRows = 1;

                    var targetRowIdx = 0;
                    var minRowX = Infinity;
                    for (var r = 0; r < designRows; r++) {
                        if (rowWidths[r] < minRowX) {
                            minRowX = rowWidths[r];
                            targetRowIdx = r;
                        }
                    }

                    var cellTop = maxTop - targetRowIdx * (targetH + spacing);
                    var cellLeft = rowWidths[targetRowIdx];
                    if (rowItemsCount[targetRowIdx] > 0) {
                        cellLeft = cellLeft + spacing;
                    }

                    var finalLeft = cellLeft;
                    var finalTop = cellTop;
                    if (alignV === 1) {
                        finalTop = cellTop - (targetH - si.h) / 2;
                    } else if (alignV === 2) {
                        finalTop = cellTop - (targetH - si.h);
                    }

                    si.el.width = si.w;
                    si.el.height = si.h;
                    si.el.position = [finalLeft, finalTop];

                    // Update row width
                    rowWidths[targetRowIdx] = cellLeft + si.w;
                    rowItemsCount[targetRowIdx]++;

                } else { // Standard Grid
                    var colIdx, rowIdx;
                    if (isHoriz) {
                        colIdx = j % columns;
                        rowIdx = Math.floor(j / columns);
                    } else {
                        rowIdx = j % numRows;
                        colIdx = Math.floor(j / numRows);
                    }

                    var cellLeft = minLeft + colIdx * (targetW + spacing);
                    var cellTop = maxTop - rowIdx * (targetH + spacing);

                    var finalLeft = cellLeft;
                    if (alignH === 1) { // Center
                        finalLeft = cellLeft + (targetW - si.w) / 2;
                    } else if (alignH === 2) { // Right
                        finalLeft = cellLeft + targetW - si.w;
                    }

                    var finalTop = cellTop; // Top boundary
                    if (alignV === 1) { // Middle
                        finalTop = cellTop - (targetH - si.h) / 2;
                    } else if (alignV === 2) { // Bottom
                        finalTop = cellTop - (targetH - si.h);
                    }

                    si.el.width = si.w;
                    si.el.height = si.h;
                    si.el.position = [finalLeft, finalTop];
                }
            }
        }

        // Redraw
        app.redraw();
        alert("Completed Successfully!\nResized and ordered " + count + " assets in a grid layout.");
    }
})();
